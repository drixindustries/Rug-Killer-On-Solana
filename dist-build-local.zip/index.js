var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  analysisRuns: () => analysisRuns,
  analyzeTokenSchema: () => analyzeTokenSchema,
  badActorLabels: () => badActorLabels,
  botConfig: () => botConfig,
  codeRedemptions: () => codeRedemptions,
  commentVotes: () => commentVotes,
  communityVoteSummaries: () => communityVoteSummaries,
  communityVotes: () => communityVotes,
  cryptoAddresses: () => cryptoAddresses,
  insertCommentVoteSchema: () => insertCommentVoteSchema,
  insertCommunityVoteSchema: () => insertCommunityVoteSchema,
  insertPortfolioPositionSchema: () => insertPortfolioPositionSchema,
  insertPortfolioTransactionSchema: () => insertPortfolioTransactionSchema,
  insertPriceAlertSchema: () => insertPriceAlertSchema,
  insertRiskStatisticSchema: () => insertRiskStatisticSchema,
  insertSharedWatchlistSchema: () => insertSharedWatchlistSchema,
  insertTokenCommentSchema: () => insertTokenCommentSchema,
  insertTokenReportSchema: () => insertTokenReportSchema,
  insertTokenSnapshotSchema: () => insertTokenSnapshotSchema,
  insertTrendingTokenSchema: () => insertTrendingTokenSchema,
  insertUserActivitySchema: () => insertUserActivitySchema,
  insertUserProfileSchema: () => insertUserProfileSchema,
  insertWatchlistSchema: () => insertWatchlistSchema,
  kolWallets: () => kolWallets,
  paymentAudit: () => paymentAudit,
  payments: () => payments,
  portfolioPositions: () => portfolioPositions,
  portfolioTransactions: () => portfolioTransactions,
  priceAlerts: () => priceAlerts,
  riskStatistics: () => riskStatistics,
  sessions: () => sessions,
  sharedWatchlists: () => sharedWatchlists,
  subscriptionCodes: () => subscriptionCodes,
  subscriptions: () => subscriptions,
  tokenAnalysisSchema: () => tokenAnalysisSchema,
  tokenComments: () => tokenComments,
  tokenReports: () => tokenReports,
  tokenSnapshots: () => tokenSnapshots,
  trendingTokens: () => trendingTokens,
  userActivities: () => userActivities,
  userProfiles: () => userProfiles,
  users: () => users,
  walletChallenges: () => walletChallenges,
  walletConnections: () => walletConnections,
  watchlistEntries: () => watchlistEntries,
  watchlistFollowers: () => watchlistFollowers
});
import { z } from "zod";
import { sql } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  boolean,
  integer,
  bigint,
  uniqueIndex,
  serial,
  decimal,
  text
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var analyzeTokenSchema, tokenAnalysisSchema, sessions, users, subscriptions, subscriptionCodes, codeRedemptions, walletConnections, walletChallenges, kolWallets, cryptoAddresses, payments, paymentAudit, analysisRuns, badActorLabels, botConfig, watchlistEntries, portfolioPositions, portfolioTransactions, priceAlerts, insertWatchlistSchema, insertPortfolioPositionSchema, insertPortfolioTransactionSchema, insertPriceAlertSchema, tokenSnapshots, trendingTokens, riskStatistics, insertTokenSnapshotSchema, insertTrendingTokenSchema, insertRiskStatisticSchema, userProfiles, tokenComments, commentVotes, communityVotes, communityVoteSummaries, sharedWatchlists, watchlistFollowers, tokenReports, userActivities, insertUserProfileSchema, insertTokenCommentSchema, insertCommentVoteSchema, insertCommunityVoteSchema, insertSharedWatchlistSchema, insertTokenReportSchema, insertUserActivitySchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    analyzeTokenSchema = z.object({
      tokenAddress: z.string().min(32).max(44)
    });
    tokenAnalysisSchema = z.object({
      tokenAddress: z.string(),
      riskScore: z.number(),
      riskLevel: z.enum(["LOW", "MODERATE", "HIGH", "EXTREME"]),
      analyzedAt: z.number()
    });
    sessions = pgTable(
      "sessions",
      {
        sid: varchar("sid").primaryKey(),
        sess: jsonb("sess").notNull(),
        expire: timestamp("expire").notNull()
      },
      (table) => [index("IDX_session_expire").on(table.expire)]
    );
    users = pgTable("users", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      email: varchar("email").unique(),
      firstName: varchar("first_name"),
      lastName: varchar("last_name"),
      profileImageUrl: varchar("profile_image_url"),
      whopUserId: varchar("whop_user_id").unique(),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    subscriptions = pgTable("subscriptions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      tier: varchar("tier").notNull(),
      // "free_trial", "individual", "group"
      status: varchar("status").notNull(),
      // Whop states: "valid", "past_due", "cancelled", "expired", "trialing"
      whopMembershipId: varchar("whop_membership_id").unique(),
      // Canonical Whop membership reference (nullable for free trials)
      whopPlanId: varchar("whop_plan_id"),
      // Whop plan ID (nullable for free trials)
      trialEndsAt: timestamp("trial_ends_at"),
      // For free trial tracking
      currentPeriodEnd: timestamp("current_period_end").notNull(),
      // Maps to Whop's valid_until
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_subscriptions_user_id").on(table.userId),
      index("idx_subscriptions_status").on(table.status),
      index("idx_subscriptions_whop_membership").on(table.whopMembershipId)
    ]);
    subscriptionCodes = pgTable("subscription_codes", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      code: varchar("code").notNull().unique(),
      tier: varchar("tier").notNull(),
      // "lifetime", "individual", "group"
      maxUses: integer("max_uses").default(1),
      // null for unlimited
      usedCount: integer("used_count").notNull().default(0),
      isActive: boolean("is_active").notNull().default(true),
      expiresAt: timestamp("expires_at"),
      // null for no expiration
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_code").on(table.code),
      index("idx_code_active").on(table.isActive)
    ]);
    codeRedemptions = pgTable("code_redemptions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      codeId: varchar("code_id").notNull().references(() => subscriptionCodes.id),
      code: varchar("code").notNull(),
      // Denormalized for easier lookups
      redeemedAt: timestamp("redeemed_at").defaultNow()
    }, (table) => [
      index("idx_redemption_user").on(table.userId),
      index("idx_redemption_code").on(table.codeId)
    ]);
    walletConnections = pgTable("wallet_connections", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      walletAddress: varchar("wallet_address").notNull().unique(),
      tokenBalance: bigint("token_balance", { mode: "number" }).notNull().default(0),
      lastVerifiedAt: timestamp("last_verified_at").defaultNow(),
      isEligible: boolean("is_eligible").notNull().default(false),
      // true if balance >= 10M tokens
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_wallet_user_id").on(table.userId),
      index("idx_wallet_eligible").on(table.isEligible)
    ]);
    walletChallenges = pgTable("wallet_challenges", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      challenge: varchar("challenge").notNull().unique(),
      // Random nonce
      expiresAt: timestamp("expires_at").notNull(),
      // Expires after 5 minutes
      usedAt: timestamp("used_at"),
      // null if unused, timestamp if consumed
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_challenge_user").on(table.userId),
      index("idx_challenge_expires").on(table.expiresAt)
    ]);
    kolWallets = pgTable("kol_wallets", {
      id: serial("id").primaryKey(),
      walletAddress: varchar("wallet_address", { length: 255 }).notNull().unique(),
      displayName: varchar("display_name", { length: 255 }),
      twitterHandle: varchar("twitter_handle", { length: 255 }),
      telegramHandle: varchar("telegram_handle", { length: 255 }),
      rank: integer("rank"),
      profitSol: decimal("profit_sol", { precision: 20, scale: 9 }),
      wins: integer("wins").default(0),
      losses: integer("losses").default(0),
      influenceScore: integer("influence_score").default(50),
      // 0-100, higher = more influential
      isVerified: boolean("is_verified").default(false),
      source: varchar("source", { length: 50 }).default("kolscan"),
      // kolscan, manual, etc
      notes: text("notes"),
      lastActiveAt: timestamp("last_active_at"),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    }, (table) => [
      index("idx_kol_wallet_address").on(table.walletAddress),
      index("idx_kol_rank").on(table.rank),
      index("idx_kol_influence").on(table.influenceScore)
    ]);
    cryptoAddresses = pgTable("crypto_addresses", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      chain: varchar("chain").notNull(),
      // "SOL", "ETH", "BTC"
      address: varchar("address").notNull().unique(),
      // UNIQUE: Each blockchain address can only be used once
      tier: varchar("tier").notNull(),
      // "basic", "premium"
      expiresAt: timestamp("expires_at").notNull(),
      // Payment address expires after 1 hour
      isPaid: boolean("is_paid").notNull().default(false),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_crypto_addresses_user").on(table.userId),
      index("idx_crypto_addresses_chain").on(table.chain)
    ]);
    payments = pgTable("payments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      cryptoAddressId: varchar("crypto_address_id").notNull().unique().references(() => cryptoAddresses.id),
      // UNIQUE: One payment per address
      chain: varchar("chain").notNull(),
      // "SOL", "ETH", "BTC"
      tier: varchar("tier").notNull(),
      // "basic", "premium"
      amountExpected: varchar("amount_expected").notNull(),
      // Expected amount in crypto (as string for precision)
      amountReceived: varchar("amount_received"),
      // Actual amount received
      txHash: varchar("tx_hash").unique(),
      // UNIQUE: Prevent duplicate blockchain transaction processing
      fromAddress: varchar("from_address"),
      // Sender address
      status: varchar("status").notNull().default("pending"),
      // "pending", "confirmed", "failed", "expired"
      confirmations: integer("confirmations").notNull().default(0),
      confirmedAt: timestamp("confirmed_at"),
      subscriptionActivatedAt: timestamp("subscription_activated_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_payments_user").on(table.userId),
      index("idx_payments_status").on(table.status)
    ]);
    paymentAudit = pgTable("payment_audit", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      paymentId: varchar("payment_id").notNull().references(() => payments.id, { onDelete: "cascade" }),
      checkType: varchar("check_type").notNull(),
      // "blockchain_scan", "confirmation_update", "status_change"
      details: jsonb("details"),
      // Store check results
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_payment_audit_payment").on(table.paymentId)
    ]);
    analysisRuns = pgTable("analysis_runs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      tokenAddress: varchar("token_address").notNull(),
      userId: varchar("user_id").references(() => users.id),
      riskScore: integer("risk_score").notNull(),
      // 0-100
      riskLevel: varchar("risk_level").notNull(),
      // "LOW", "MODERATE", "HIGH", "EXTREME"
      analysisData: jsonb("analysis_data").notNull(),
      // Full TokenAnalysisResponse
      rugDetected: boolean("rug_detected").default(false),
      // Manual flag for confirmed rugs
      userReported: boolean("user_reported").default(false),
      // User reported as rug
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_analysis_token").on(table.tokenAddress),
      index("idx_analysis_rug").on(table.rugDetected),
      index("idx_analysis_created").on(table.createdAt)
    ]);
    badActorLabels = pgTable("bad_actor_labels", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      walletAddress: varchar("wallet_address").notNull().unique(),
      labelType: varchar("label_type").notNull(),
      // "rugger_dev", "scammer", "honeypot_creator", "wash_trader", "serial_rugger"
      severity: integer("severity").notNull(),
      // 0-100 (higher = more dangerous)
      rugCount: integer("rug_count").notNull().default(0),
      // Number of confirmed rugs
      totalVictims: integer("total_victims").default(0),
      // Estimated victims
      totalLosses: varchar("total_losses"),
      // Estimated SOL lost by victims
      evidenceData: jsonb("evidence_data"),
      // Store evidence/patterns
      detectionMethod: varchar("detection_method").notNull(),
      // "rules_engine", "ml_model", "manual_report", "community_vote"
      confidence: integer("confidence").notNull(),
      // 0-100 confidence score
      isActive: boolean("is_active").notNull().default(true),
      // Can be deactivated if false positive
      reviewedBy: varchar("reviewed_by"),
      // Admin user ID who reviewed
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_bad_actors_wallet").on(table.walletAddress),
      index("idx_bad_actors_severity").on(table.severity),
      index("idx_bad_actors_active").on(table.isActive),
      index("idx_bad_actors_label_type").on(table.labelType)
    ]);
    botConfig = pgTable("bot_config", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      platform: varchar("platform").notNull(),
      // "telegram", "discord"
      platformUserId: varchar("platform_user_id").notNull(),
      // Telegram chat ID or Discord user ID
      platformUsername: varchar("platform_username"),
      isActive: boolean("is_active").notNull().default(true),
      alertsEnabled: boolean("alerts_enabled").notNull().default(true),
      minRiskLevel: varchar("min_risk_level").default("MODERATE"),
      // Only alert for HIGH and EXTREME by default
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_bot_config_user").on(table.userId),
      index("idx_bot_config_platform").on(table.platform),
      uniqueIndex("unique_bot_platform_user").on(table.platform, table.platformUserId)
      // UNIQUE: Prevent duplicate bot registrations
    ]);
    watchlistEntries = pgTable("watchlist_entries", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      label: varchar("label", { length: 120 }),
      // Optional user label/note
      metadata: jsonb("metadata"),
      // Cached token name, symbol for quick display
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_watchlist_user").on(table.userId),
      uniqueIndex("unique_watchlist_user_token").on(table.userId, table.tokenAddress)
    ]);
    portfolioPositions = pgTable("portfolio_positions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      quantity: decimal("quantity", { precision: 38, scale: 12 }).notNull(),
      avgCostUsd: decimal("avg_cost_usd", { precision: 24, scale: 8 }),
      // Average purchase price
      realizedPnlUsd: decimal("realized_pnl_usd", { precision: 24, scale: 8 }).default("0"),
      latestPriceUsd: decimal("latest_price_usd", { precision: 24, scale: 8 }),
      // Cached from price worker
      unrealizedPnlUsd: decimal("unrealized_pnl_usd", { precision: 24, scale: 8 }),
      // Cached calculation
      pnlPct: decimal("pnl_pct", { precision: 10, scale: 4 }),
      // Percentage gain/loss
      lastRebalancedAt: timestamp("last_rebalanced_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_portfolio_user").on(table.userId),
      uniqueIndex("unique_portfolio_user_token").on(table.userId, table.tokenAddress)
    ]);
    portfolioTransactions = pgTable("portfolio_transactions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      positionId: varchar("position_id").notNull().references(() => portfolioPositions.id, { onDelete: "cascade" }),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      // Redundant for filtering
      txType: varchar("tx_type").notNull(),
      // "buy", "sell", "airdrop", "manual_adjust"
      quantity: decimal("quantity", { precision: 38, scale: 12 }).notNull(),
      priceUsd: decimal("price_usd", { precision: 24, scale: 8 }),
      feeUsd: decimal("fee_usd", { precision: 24, scale: 8 }).default("0"),
      note: text("note"),
      // User notes
      executedAt: timestamp("executed_at").notNull(),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_transaction_user_date").on(table.userId, table.executedAt),
      index("idx_transaction_position_date").on(table.positionId, table.executedAt)
    ]);
    priceAlerts = pgTable("price_alerts", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      alertType: varchar("alert_type").notNull(),
      // "price_above", "price_below", "percent_change", "percent_drop"
      targetValue: decimal("target_value", { precision: 24, scale: 8 }).notNull(),
      // Price threshold or percentage
      lookbackWindowMinutes: integer("lookback_window_minutes"),
      // For percent_change/percent_drop
      isActive: boolean("is_active").notNull().default(true),
      lastPrice: decimal("last_price", { precision: 24, scale: 8 }),
      // Last checked price
      triggeredAt: timestamp("triggered_at"),
      // When alert fired
      cancelledAt: timestamp("cancelled_at"),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_alerts_active_scan").on(table.isActive, table.alertType, table.tokenAddress),
      index("idx_alerts_user_status").on(table.userId, table.isActive),
      uniqueIndex("unique_alert_config").on(table.userId, table.tokenAddress, table.alertType, table.targetValue)
    ]);
    insertWatchlistSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      label: z.string().max(120).optional()
    });
    insertPortfolioPositionSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      quantity: z.string().or(z.number()),
      avgCostUsd: z.string().or(z.number()).optional()
    });
    insertPortfolioTransactionSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      // Will be used to find position
      txType: z.enum(["buy", "sell", "airdrop", "manual_adjust"]),
      quantity: z.string().or(z.number()),
      priceUsd: z.string().or(z.number()).optional(),
      feeUsd: z.string().or(z.number()).optional(),
      note: z.string().optional(),
      executedAt: z.string().or(z.date()).optional()
      // ISO string or Date
    });
    insertPriceAlertSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      alertType: z.enum(["price_above", "price_below", "percent_change", "percent_drop"]),
      targetValue: z.string().or(z.number()),
      lookbackWindowMinutes: z.number().int().positive().optional()
    });
    tokenSnapshots = pgTable("token_snapshots", {
      id: serial("id").primaryKey(),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      capturedAt: timestamp("captured_at").notNull().defaultNow(),
      priceUsd: decimal("price_usd", { precision: 20, scale: 8 }),
      riskScore: integer("risk_score").notNull(),
      holderCount: integer("holder_count"),
      volume24h: decimal("volume_24h", { precision: 20, scale: 2 }),
      liquidityUsd: decimal("liquidity_usd", { precision: 20, scale: 2 }),
      riskFlags: jsonb("risk_flags").$type(),
      // Array of risk flag types
      txCount24h: integer("tx_count_24h"),
      analyzerVersion: varchar("analyzer_version", { length: 10 }).default("1.0")
    }, (table) => [
      index("idx_snapshots_token").on(table.tokenAddress),
      index("idx_snapshots_captured").on(table.capturedAt),
      index("idx_snapshots_token_time").on(table.tokenAddress, table.capturedAt)
    ]);
    trendingTokens = pgTable("trending_tokens", {
      tokenAddress: varchar("token_address", { length: 44 }).primaryKey(),
      score: decimal("score", { precision: 10, scale: 2 }).notNull(),
      scoreBreakdown: jsonb("score_breakdown").$type().notNull(),
      rank: integer("rank").notNull(),
      volume24h: decimal("volume_24h", { precision: 20, scale: 2 }),
      velocity: decimal("velocity", { precision: 10, scale: 2 }),
      // Rate of change
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    }, (table) => [
      index("idx_trending_rank").on(table.rank),
      index("idx_trending_score").on(table.score),
      index("idx_trending_updated").on(table.updatedAt)
    ]);
    riskStatistics = pgTable("risk_statistics", {
      id: serial("id").primaryKey(),
      windowStart: timestamp("window_start").notNull(),
      windowEnd: timestamp("window_end").notNull(),
      totalAnalyzed: integer("total_analyzed").notNull().default(0),
      rugDetected: integer("rug_detected").notNull().default(0),
      falsePositives: integer("false_positives").notNull().default(0),
      commonFlags: jsonb("common_flags").$type().notNull(),
      // { "mint_authority": 42, ... }
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    }, (table) => [
      index("idx_risk_stats_window").on(table.windowStart, table.windowEnd),
      index("idx_risk_stats_updated").on(table.updatedAt)
    ]);
    insertTokenSnapshotSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      priceUsd: z.string().or(z.number()).optional(),
      riskScore: z.number().int().min(0).max(100),
      holderCount: z.number().int().optional(),
      volume24h: z.string().or(z.number()).optional(),
      liquidityUsd: z.string().or(z.number()).optional(),
      riskFlags: z.array(z.string()).optional(),
      txCount24h: z.number().int().optional(),
      analyzerVersion: z.string().max(10).optional()
    });
    insertTrendingTokenSchema = z.object({
      tokenAddress: z.string().min(32).max(44),
      score: z.string().or(z.number()),
      scoreBreakdown: z.object({
        volumeScore: z.number(),
        velocityScore: z.number(),
        analysisScore: z.number()
      }),
      rank: z.number().int(),
      volume24h: z.string().or(z.number()).optional(),
      velocity: z.string().or(z.number()).optional()
    });
    insertRiskStatisticSchema = z.object({
      windowStart: z.string().or(z.date()),
      windowEnd: z.string().or(z.date()),
      totalAnalyzed: z.number().int(),
      rugDetected: z.number().int(),
      falsePositives: z.number().int(),
      commonFlags: z.record(z.number())
    });
    userProfiles = pgTable("user_profiles", {
      userId: varchar("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
      username: varchar("username", { length: 50 }).unique(),
      bio: text("bio"),
      avatarUrl: text("avatar_url"),
      reputationScore: integer("reputation_score").notNull().default(0),
      contributionCount: integer("contribution_count").notNull().default(0),
      visibility: varchar("visibility", { length: 20 }).notNull().default("public"),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_user_profiles_reputation").on(table.reputationScore),
      index("idx_user_profiles_username").on(table.username)
    ]);
    tokenComments = pgTable("token_comments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      commentText: text("comment_text").notNull(),
      rating: integer("rating"),
      // 1-5 stars, nullable
      upvoteCount: integer("upvote_count").notNull().default(0),
      downvoteCount: integer("downvote_count").notNull().default(0),
      flagged: boolean("flagged").notNull().default(false),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_token_comments_token").on(table.tokenAddress),
      index("idx_token_comments_user").on(table.userId),
      index("idx_token_comments_created").on(table.createdAt)
    ]);
    commentVotes = pgTable("comment_votes", {
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      commentId: varchar("comment_id").notNull().references(() => tokenComments.id, { onDelete: "cascade" }),
      voteType: varchar("vote_type", { length: 10 }).notNull(),
      // 'up' or 'down'
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      uniqueIndex("unique_comment_vote").on(table.userId, table.commentId),
      index("idx_comment_votes_comment").on(table.commentId)
    ]);
    communityVotes = pgTable("community_votes", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      voteType: varchar("vote_type", { length: 10 }).notNull(),
      // 'safe', 'risky', 'scam'
      confidence: integer("confidence").notNull(),
      // 1-5
      reason: text("reason"),
      weight: decimal("weight", { precision: 10, scale: 2 }).notNull().default("1.0"),
      // Reputation-based weighting
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      uniqueIndex("unique_community_vote").on(table.tokenAddress, table.userId),
      index("idx_community_votes_token").on(table.tokenAddress),
      index("idx_community_votes_user").on(table.userId)
    ]);
    communityVoteSummaries = pgTable("community_vote_summaries", {
      tokenAddress: varchar("token_address", { length: 44 }).primaryKey(),
      safeWeight: decimal("safe_weight", { precision: 20, scale: 2 }).notNull().default("0"),
      riskyWeight: decimal("risky_weight", { precision: 20, scale: 2 }).notNull().default("0"),
      scamWeight: decimal("scam_weight", { precision: 20, scale: 2 }).notNull().default("0"),
      totalVotes: integer("total_votes").notNull().default(0),
      consensus: varchar("consensus", { length: 10 }),
      // 'safe', 'risky', 'scam', 'mixed'
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_community_vote_summaries_consensus").on(table.consensus)
    ]);
    sharedWatchlists = pgTable("shared_watchlists", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      ownerId: varchar("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      name: varchar("name", { length: 120 }).notNull(),
      description: text("description"),
      isPublic: boolean("is_public").notNull().default(false),
      shareSlug: varchar("share_slug", { length: 20 }).notNull().unique(),
      followersCount: integer("followers_count").notNull().default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_shared_watchlists_owner").on(table.ownerId),
      index("idx_shared_watchlists_public").on(table.isPublic),
      index("idx_shared_watchlists_slug").on(table.shareSlug)
    ]);
    watchlistFollowers = pgTable("watchlist_followers", {
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      watchlistId: varchar("watchlist_id").notNull().references(() => sharedWatchlists.id, { onDelete: "cascade" }),
      followedAt: timestamp("followed_at").defaultNow()
    }, (table) => [
      uniqueIndex("unique_watchlist_follower").on(table.userId, table.watchlistId),
      index("idx_watchlist_followers_user").on(table.userId),
      index("idx_watchlist_followers_watchlist").on(table.watchlistId)
    ]);
    tokenReports = pgTable("token_reports", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      tokenAddress: varchar("token_address", { length: 44 }).notNull(),
      reporterId: varchar("reporter_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      reportType: varchar("report_type", { length: 20 }).notNull(),
      // 'scam', 'honeypot', 'soft_rug', 'other'
      evidence: text("evidence").notNull(),
      status: varchar("status", { length: 20 }).notNull().default("pending"),
      // 'pending', 'under_review', 'verified', 'dismissed'
      reviewerId: varchar("reviewer_id").references(() => users.id),
      resolutionNotes: text("resolution_notes"),
      severityScore: integer("severity_score"),
      // 1-5
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_token_reports_token").on(table.tokenAddress),
      index("idx_token_reports_reporter").on(table.reporterId),
      index("idx_token_reports_status").on(table.status)
    ]);
    userActivities = pgTable("user_activities", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      activityType: varchar("activity_type", { length: 20 }).notNull(),
      // 'comment', 'vote', 'report', 'helpful_vote', 'watchlist_share', 'follow'
      targetToken: varchar("target_token", { length: 44 }),
      targetWatchlist: varchar("target_watchlist"),
      points: integer("points").notNull(),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_user_activities_user").on(table.userId),
      index("idx_user_activities_created").on(table.createdAt),
      index("idx_user_activities_type").on(table.activityType)
    ]);
    insertUserProfileSchema = createInsertSchema(userProfiles).omit({
      createdAt: true
    }).extend({
      username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, underscores, and hyphens"),
      bio: z.string().max(500).optional(),
      visibility: z.enum(["public", "private"]).default("public")
    });
    insertTokenCommentSchema = createInsertSchema(tokenComments).omit({
      id: true,
      createdAt: true,
      upvoteCount: true,
      downvoteCount: true,
      flagged: true
    }).extend({
      tokenAddress: z.string().min(32).max(44),
      commentText: z.string().min(1).max(2e3),
      rating: z.number().int().min(1).max(5).optional()
    });
    insertCommentVoteSchema = createInsertSchema(commentVotes).omit({
      createdAt: true
    }).extend({
      voteType: z.enum(["up", "down"])
    });
    insertCommunityVoteSchema = createInsertSchema(communityVotes).omit({
      id: true,
      createdAt: true,
      weight: true
    }).extend({
      tokenAddress: z.string().min(32).max(44),
      voteType: z.enum(["safe", "risky", "scam"]),
      confidence: z.number().int().min(1).max(5),
      reason: z.string().max(1e3).optional()
    });
    insertSharedWatchlistSchema = createInsertSchema(sharedWatchlists).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      shareSlug: true,
      followersCount: true
    }).extend({
      name: z.string().min(1).max(120),
      description: z.string().max(500).optional()
    });
    insertTokenReportSchema = createInsertSchema(tokenReports).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      status: true,
      reviewerId: true,
      resolutionNotes: true
    }).extend({
      tokenAddress: z.string().min(32).max(44),
      reportType: z.enum(["scam", "honeypot", "soft_rug", "other"]),
      evidence: z.string().min(10).max(5e3),
      severityScore: z.number().int().min(1).max(5).optional()
    });
    insertUserActivitySchema = createInsertSchema(userActivities).omit({
      id: true,
      createdAt: true
    }).extend({
      activityType: z.enum(["comment", "vote", "report", "helpful_vote", "watchlist_share", "follow"]),
      points: z.number().int()
    });
  }
});

// server/rugcheck-service.ts
var RUGCHECK_API_URL, RUGCHECK_API_KEY, RugcheckService;
var init_rugcheck_service = __esm({
  "server/rugcheck-service.ts"() {
    "use strict";
    RUGCHECK_API_URL = "https://api.rugcheck.xyz/v1";
    RUGCHECK_API_KEY = process.env.RUGCHECK_API_KEY;
    RugcheckService = class {
      async getTokenReport(mintAddress) {
        try {
          const headers = {
            "Content-Type": "application/json"
          };
          if (RUGCHECK_API_KEY) {
            headers["X-API-KEY"] = RUGCHECK_API_KEY;
          }
          const response = await fetch(
            `${RUGCHECK_API_URL}/tokens/${mintAddress}/report`,
            {
              headers,
              signal: AbortSignal.timeout(1e4)
            }
          );
          if (!response.ok) {
            if (response.status === 404) {
              console.log(`Rugcheck: Token ${mintAddress} not found`);
              return null;
            }
            console.error(`Rugcheck API error: ${response.status} ${response.statusText}`);
            return null;
          }
          const data = await response.json();
          return this.parseRugcheckResponse(data);
        } catch (error) {
          console.error("Rugcheck API error:", error);
          return null;
        }
      }
      parseRugcheckResponse(data) {
        const risks = [];
        if (data.risks) {
          Object.keys(data.risks).forEach((key) => {
            if (data.risks[key]?.level === "danger" || data.risks[key]?.level === "warn") {
              risks.push(data.risks[key]?.name || key);
            }
          });
        }
        const markets = (data.markets || []).map((market) => ({
          name: market.name || "Unknown",
          marketType: market.marketType || null,
          pubkey: market.pubkey || null,
          // Pair/program address
          liquidityA: market.liquidityA || null,
          // Token account for base token
          liquidityB: market.liquidityB || null,
          // Token account for quote token (SOL)
          liquidity: market.lp?.lpLockedUSD || market.lp?.lpUSD || 0,
          lpBurn: market.lp?.lpBurn || 0,
          lp: market.lp || null
          // Preserve full LP data for Pump.fun tokens
        }));
        const topHolders = (data.topHolders || []).map((holder) => ({
          address: holder.owner || "",
          // Map 'owner' to 'address' for consistency
          pct: holder.pct || 0
        }));
        return {
          score: data.score || 0,
          risks,
          markets,
          topHolders,
          fileMeta: data.fileMeta
        };
      }
      async getTokenSummary(mintAddress) {
        try {
          const headers = {
            "Content-Type": "application/json"
          };
          if (RUGCHECK_API_KEY) {
            headers["X-API-KEY"] = RUGCHECK_API_KEY;
          }
          const response = await fetch(
            `${RUGCHECK_API_URL}/tokens/${mintAddress}/report/summary`,
            {
              headers,
              signal: AbortSignal.timeout(5e3)
            }
          );
          if (!response.ok) {
            return null;
          }
          return await response.json();
        } catch (error) {
          console.error("Rugcheck summary API error:", error);
          return null;
        }
      }
    };
  }
});

// server/goplus-service.ts
var GOPLUS_API_URL, GoPlusSecurityService;
var init_goplus_service = __esm({
  "server/goplus-service.ts"() {
    "use strict";
    GOPLUS_API_URL = "https://api.gopluslabs.io/api/v1";
    GoPlusSecurityService = class {
      async getTokenSecurity(tokenAddress) {
        try {
          const response = await fetch(
            `${GOPLUS_API_URL}/token_security/solana?contract_addresses=${tokenAddress}`,
            {
              signal: AbortSignal.timeout(1e4)
            }
          );
          if (!response.ok) {
            console.error(`GoPlus API error: ${response.status} ${response.statusText}`);
            return null;
          }
          const data = await response.json();
          if (data.code !== 1) {
            console.error("GoPlus API returned error:", data.message);
            return null;
          }
          if (!data.result || data.result === null) {
            console.log(`GoPlus: No security data available for token ${tokenAddress}`);
            return null;
          }
          let tokenData = data.result[tokenAddress];
          if (!tokenData) {
            console.log(`GoPlus: Token ${tokenAddress} not found in result map`);
            return null;
          }
          if (Array.isArray(tokenData)) {
            tokenData = tokenData[0];
          }
          if (!tokenData) {
            console.error("GoPlus: Token data array is empty");
            return null;
          }
          return this.parseGoPlusResponse(tokenData);
        } catch (error) {
          console.error("GoPlus API error:", error);
          return null;
        }
      }
      parseGoPlusResponse(result) {
        const securityRisks = [];
        if (result.is_mintable === "1") {
          securityRisks.push(`Mintable - Authority can create unlimited tokens (${result.mint_authority || "Unknown"})`);
        }
        if (result.is_freezable === "1") {
          securityRisks.push(`Freezable - Accounts can be frozen (${result.freeze_authority || "Unknown"})`);
        }
        if (result.is_scam === "1") {
          securityRisks.push("SCAM - Flagged as malicious by GoPlus");
        }
        const buyTax = parseFloat(result.buy_tax || "0");
        const sellTax = parseFloat(result.sell_tax || "0");
        if (buyTax > 10) {
          securityRisks.push(`High buy tax: ${buyTax}%`);
        }
        if (sellTax > 10) {
          securityRisks.push(`High sell tax: ${sellTax}% (possible honeypot)`);
        }
        if (result.can_take_back_ownership === "1") {
          securityRisks.push("Owner can reclaim ownership after renouncement");
        }
        if (result.is_open_source === "0") {
          securityRisks.push("Contract not verified/open source");
        }
        if (result.is_true_token === "0") {
          securityRisks.push("Not recognized as a legitimate token");
        }
        if (result.transfer_fee_enable === "1") {
          securityRisks.push("Transfer fees enabled");
        }
        return {
          is_mintable: result.is_mintable || "0",
          is_freezable: result.is_freezable || "0",
          is_scam: result.is_scam || "0",
          buy_tax: result.buy_tax || "0",
          sell_tax: result.sell_tax || "0",
          transfer_fee_enable: result.transfer_fee_enable || "0",
          can_take_back_ownership: result.can_take_back_ownership || "0",
          is_open_source: result.is_open_source || "0",
          is_true_token: result.is_true_token || "0",
          holder_count: result.holder_count || "0",
          total_supply: result.total_supply || "0",
          liquidity: result.liquidity || "0",
          securityRisks
        };
      }
    };
  }
});

// server/dexscreener-service.ts
var DEXSCREENER_API_URL, DexScreenerService;
var init_dexscreener_service = __esm({
  "server/dexscreener-service.ts"() {
    "use strict";
    DEXSCREENER_API_URL = "https://api.dexscreener.com";
    DexScreenerService = class {
      async getTokenData(tokenAddress) {
        try {
          const response = await fetch(
            `${DEXSCREENER_API_URL}/latest/dex/tokens/${tokenAddress}`,
            {
              signal: AbortSignal.timeout(1e4)
            }
          );
          if (!response.ok) {
            console.error(`DexScreener API error: ${response.status} ${response.statusText}`);
            return null;
          }
          const data = await response.json();
          if (!data.pairs || data.pairs.length === 0) {
            console.log(`DexScreener: No trading pairs found for token ${tokenAddress}`);
            return null;
          }
          const solanaPairs = data.pairs.filter((pair) => pair.chainId === "solana");
          if (solanaPairs.length === 0) {
            console.log(`DexScreener: No Solana pairs found for token ${tokenAddress}`);
            return null;
          }
          return {
            pairs: solanaPairs.map((pair) => ({
              chainId: pair.chainId,
              dexId: pair.dexId,
              pairAddress: pair.pairAddress,
              baseToken: {
                address: pair.baseToken.address,
                name: pair.baseToken.name || "",
                symbol: pair.baseToken.symbol || ""
              },
              quoteToken: {
                address: pair.quoteToken.address,
                name: pair.quoteToken.name || "",
                symbol: pair.quoteToken.symbol || ""
              },
              priceUsd: pair.priceUsd || "0",
              priceNative: pair.priceNative || "0",
              txns: {
                m5: pair.txns?.m5 || { buys: 0, sells: 0 },
                h1: pair.txns?.h1 || { buys: 0, sells: 0 },
                h6: pair.txns?.h6 || { buys: 0, sells: 0 },
                h24: pair.txns?.h24 || { buys: 0, sells: 0 }
              },
              volume: {
                h24: parseFloat(pair.volume?.h24 || "0"),
                h6: parseFloat(pair.volume?.h6 || "0"),
                h1: parseFloat(pair.volume?.h1 || "0"),
                m5: parseFloat(pair.volume?.m5 || "0")
              },
              priceChange: {
                m5: parseFloat(pair.priceChange?.m5 || "0"),
                h1: parseFloat(pair.priceChange?.h1 || "0"),
                h6: parseFloat(pair.priceChange?.h6 || "0"),
                h24: parseFloat(pair.priceChange?.h24 || "0")
              },
              liquidity: pair.liquidity ? {
                usd: parseFloat(pair.liquidity.usd || "0"),
                base: parseFloat(pair.liquidity.base || "0"),
                quote: parseFloat(pair.liquidity.quote || "0")
              } : void 0,
              fdv: pair.fdv ? parseFloat(pair.fdv) : void 0,
              marketCap: pair.marketCap ? parseFloat(pair.marketCap) : void 0,
              pairCreatedAt: pair.pairCreatedAt || void 0
            })),
            schemaVersion: data.schemaVersion || "1.0.0"
          };
        } catch (error) {
          console.error("DexScreener API error:", error);
          return null;
        }
      }
      getMostLiquidPair(data) {
        if (!data.pairs || data.pairs.length === 0) return null;
        return data.pairs.reduce((prev, current) => {
          const prevLiq = prev.liquidity?.usd || 0;
          const currentLiq = current.liquidity?.usd || 0;
          return currentLiq > prevLiq ? current : prev;
        });
      }
      getSOLPair(data) {
        const solAddress = "So11111111111111111111111111111111111111112";
        return data.pairs.find(
          (pair) => pair.quoteToken.address === solAddress
        ) || this.getMostLiquidPair(data);
      }
    };
  }
});

// server/jupiter-service.ts
var JUPITER_PRICE_API_URL, JupiterPriceService;
var init_jupiter_service = __esm({
  "server/jupiter-service.ts"() {
    "use strict";
    JUPITER_PRICE_API_URL = "https://api.jup.ag/price/v2";
    JupiterPriceService = class {
      async getTokenPrice(tokenAddress) {
        try {
          const response = await fetch(
            `${JUPITER_PRICE_API_URL}?ids=${tokenAddress}`,
            {
              signal: AbortSignal.timeout(1e4)
            }
          );
          if (!response.ok) {
            console.error(`Jupiter API error: ${response.status} ${response.statusText}`);
            return null;
          }
          const data = await response.json();
          if (!data.data || !data.data[tokenAddress]) {
            console.log(`Jupiter: No price data available for token ${tokenAddress}`);
            return null;
          }
          const priceData = data.data[tokenAddress];
          return {
            id: priceData.id,
            type: priceData.type,
            price: priceData.price,
            extraInfo: priceData.extraInfo
          };
        } catch (error) {
          console.error("Jupiter API error:", error);
          return null;
        }
      }
    };
  }
});

// server/known-addresses.ts
import { PublicKey } from "@solana/web3.js";
import { TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID } from "@solana/spl-token";
function isKnownAddress(address) {
  return KNOWN_ADDRESS_SET.has(address);
}
function getKnownAddressInfo(address) {
  return ALL_KNOWN_ADDRESSES.find((a) => a.address === address);
}
function getPumpFunBondingCurveAddress(mintAddress) {
  if (bondingCurveCache.has(mintAddress)) {
    return bondingCurveCache.get(mintAddress);
  }
  try {
    const mint = new PublicKey(mintAddress);
    const pumpProgram = new PublicKey(PUMPFUN_PROGRAM_ID);
    const [bondingCurve] = PublicKey.findProgramAddressSync(
      [
        Buffer.from("bonding-curve"),
        mint.toBuffer()
      ],
      pumpProgram
    );
    const address = bondingCurve.toString();
    bondingCurveCache.set(mintAddress, address);
    return address;
  } catch (error) {
    console.error("Error calculating pump.fun bonding curve address:", error);
    return null;
  }
}
function getPumpFunAssociatedBondingCurveAddress(mintAddress) {
  if (associatedBondingCurveCache.has(mintAddress)) {
    return associatedBondingCurveCache.get(mintAddress);
  }
  try {
    const mint = new PublicKey(mintAddress);
    const pumpProgram = new PublicKey(PUMPFUN_PROGRAM_ID);
    const [bondingCurve] = PublicKey.findProgramAddressSync(
      [
        Buffer.from("bonding-curve"),
        mint.toBuffer()
      ],
      pumpProgram
    );
    const [associatedBondingCurve] = PublicKey.findProgramAddressSync(
      [
        bondingCurve.toBuffer(),
        TOKEN_PROGRAM_ID.toBuffer(),
        mint.toBuffer()
      ],
      ASSOCIATED_TOKEN_PROGRAM_ID
    );
    const address = associatedBondingCurve.toString();
    associatedBondingCurveCache.set(mintAddress, address);
    return address;
  } catch (error) {
    console.error("Error calculating pump.fun associated bonding curve address:", error);
    return null;
  }
}
function detectBundledWallets(holders, transactionData) {
  const bundledAddresses = [];
  if (!transactionData) {
    const percentageGroups = /* @__PURE__ */ new Map();
    holders.forEach((holder) => {
      const roundedPct = holder.percentage.toFixed(2);
      if (!percentageGroups.has(roundedPct)) {
        percentageGroups.set(roundedPct, []);
      }
      percentageGroups.get(roundedPct).push(holder.address);
    });
    percentageGroups.forEach((addresses) => {
      if (addresses.length >= 3) {
        bundledAddresses.push(...addresses);
      }
    });
    return bundledAddresses;
  }
  const blockGroups = /* @__PURE__ */ new Map();
  transactionData.forEach((tx) => {
    if (!blockGroups.has(tx.blockHeight)) {
      blockGroups.set(tx.blockHeight, []);
    }
    blockGroups.get(tx.blockHeight).push(tx.address);
  });
  blockGroups.forEach((addresses) => {
    if (addresses.length >= 10) {
      bundledAddresses.push(...addresses);
    }
  });
  return bundledAddresses;
}
var KNOWN_EXCHANGES, KNOWN_PROTOCOLS, PUMPFUN_ADDRESSES, PUMPFUN_PROGRAM_ID, KNOWN_BUNDLERS, ALL_KNOWN_ADDRESSES, KNOWN_ADDRESS_SET, bondingCurveCache, associatedBondingCurveCache;
var init_known_addresses = __esm({
  "server/known-addresses.ts"() {
    "use strict";
    KNOWN_EXCHANGES = [
      // Binance
      {
        address: "5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9",
        label: "Binance 2",
        type: "exchange",
        source: "Solscan labeled"
      },
      {
        address: "5tzL3DfsF8i36KeUCjtzWP9zqS6zWjYhR76VA4Y5CzzJ",
        label: "Binance 1",
        type: "exchange",
        source: "Solscan labeled"
      },
      {
        address: "H8sMJSCQxfKiFTCfDR3DUYexta7Kxymr2gF3LceH44uR",
        label: "Binance 3",
        type: "exchange",
        source: "Solscan labeled"
      },
      // Coinbase
      {
        address: "GJRs4FwHtemZ5ZE9x3FNvJ8TMwitKTh21yxdRPqn7npE",
        label: "Coinbase Hot Wallet 2",
        type: "exchange",
        source: "Solscan labeled"
      },
      // OKX
      {
        address: "is6MTRHEgyFLNTfYcuV4QBWLjrZBfmhVNYR6ccgr8KV",
        label: "OKX Hot Wallet",
        type: "exchange",
        source: "Solscan labeled"
      },
      // Bybit
      {
        address: "AC5RDfQFmDS1deWZos921JfqscXdByf8BKHs5ACWjtW2",
        label: "Bybit Hot Wallet",
        type: "exchange",
        source: "Solscan labeled"
      },
      // Gate.io
      {
        address: "u6PJ8DtQuPFnfmwHbGFULQ4u4EgjDiyYKjVEsynXq2w",
        label: "Gate.io",
        type: "exchange",
        source: "Solscan labeled"
      },
      // MEXC
      {
        address: "ASTyfSima4LLAdDgoFGkgqoKowG1LZFDr9fAQrg7iaJZ",
        label: "MEXC",
        type: "exchange",
        source: "Solscan labeled"
      },
      // FTX (defunct, historical holdings)
      {
        address: "6ZRCB7AAqGre6c72PRz3MHLC73VMYvJ8bi9KHf1HFpNk",
        label: "FTX Cold Storage",
        type: "exchange",
        source: "Solscan labeled"
      },
      // User verified exchange
      {
        address: "4xJLmpojrDeXEnfDoeG9UdHXozY2Qn48ZyiPyRhabAN3",
        label: "Exchange Wallet",
        type: "exchange",
        source: "User verified"
      }
      // Add more as they become publicly known
    ];
    KNOWN_PROTOCOLS = [
      // Raydium
      {
        address: "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1",
        label: "Raydium Authority V4",
        type: "protocol",
        source: "Solscan labeled"
      },
      // Orca
      {
        address: "3xQ5vZfpcjLhFWKHNFzJP8SJmBLqpN9Sq5q5K2JmvPuG",
        label: "Orca Whirlpool",
        type: "protocol",
        source: "Solscan labeled"
      },
      // Meteora
      {
        address: "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo",
        label: "Meteora Pool",
        type: "protocol",
        source: "Solscan labeled"
      }
    ];
    PUMPFUN_ADDRESSES = [
      {
        address: "Ce6TQqeHC9p8KetsN6JsjHK7UTZk7nasjjnr7XxXp9F1",
        label: "Pump.fun Fee Receiver",
        type: "protocol",
        source: "Pump.fun documentation"
      },
      {
        address: "CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM",
        label: "Pump.fun Program Authority",
        type: "protocol",
        source: "Pump.fun documentation"
      }
    ];
    PUMPFUN_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";
    KNOWN_BUNDLERS = [
      // Common bundling service addresses will be added as discovered
      // Typically identified by wash trading patterns and same-block purchases
    ];
    ALL_KNOWN_ADDRESSES = [
      ...KNOWN_EXCHANGES,
      ...KNOWN_PROTOCOLS,
      ...PUMPFUN_ADDRESSES,
      ...KNOWN_BUNDLERS
    ];
    KNOWN_ADDRESS_SET = new Set(
      ALL_KNOWN_ADDRESSES.map((a) => a.address)
    );
    bondingCurveCache = /* @__PURE__ */ new Map();
    associatedBondingCurveCache = /* @__PURE__ */ new Map();
  }
});

// server/services/birdeye-api.ts
import axios from "axios";
async function getBirdeyeOverview(tokenAddress) {
  if (!API_KEY) {
    return null;
  }
  try {
    const response = await axios.get(`${BIRDEYE_API}/defi/overview`, {
      params: { address: tokenAddress },
      headers: { "X-API-KEY": API_KEY },
      timeout: 1e4
    });
    return response.data?.data || null;
  } catch (error) {
    if (error.response?.status === 401) {
      console.error("[Birdeye] Invalid API key");
    }
    return null;
  }
}
var BIRDEYE_API, API_KEY;
var init_birdeye_api = __esm({
  "server/services/birdeye-api.ts"() {
    "use strict";
    BIRDEYE_API = "https://public-api.birdeye.so";
    API_KEY = process.env.BIRDEYE_API_KEY || "";
  }
});

// server/services/pumpfun-api.ts
import axios2 from "axios";
async function checkPumpFun(tokenAddress) {
  try {
    const response = await axios2.get(`https://pump.fun/api/token/${tokenAddress}`, {
      timeout: 5e3
    });
    if (response.status === 200 && response.data) {
      return {
        isPumpFun: true,
        devBought: response.data.dev_bought || 0,
        bondingCurve: response.data.progress || 0
      };
    }
  } catch (error) {
  }
  return { isPumpFun: false, devBought: 0, bondingCurve: 0 };
}
var init_pumpfun_api = __esm({
  "server/services/pumpfun-api.ts"() {
    "use strict";
  }
});

// server/services/rpc-balancer.ts
import { Connection } from "@solana/web3.js";
var RPC_PROVIDERS, SolanaRpcBalancer, rpcBalancer;
var init_rpc_balancer = __esm({
  "server/services/rpc-balancer.ts"() {
    "use strict";
    RPC_PROVIDERS = [
      {
        getUrl: () => `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_KEY || ""}`,
        weight: 40,
        name: "Helius"
      },
      {
        getUrl: () => `https://solana-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_KEY || ""}`,
        weight: 35,
        name: "Alchemy"
      },
      {
        getUrl: () => "https://rpc.ankr.com/solana",
        weight: 15,
        name: "Ankr"
      },
      {
        getUrl: () => "https://solana-api.projectserum.com",
        weight: 10,
        name: "Serum"
      },
      {
        getUrl: () => "https://api.mainnet-beta.solana.com",
        weight: 5,
        name: "Public"
      }
    ];
    SolanaRpcBalancer = class {
      providers;
      totalWeight;
      constructor(providers) {
        this.providers = providers.map((p) => ({
          ...p,
          score: 100,
          fails: 0
        }));
        this.totalWeight = providers.reduce((s, p) => s + p.weight, 0);
      }
      select() {
        const healthy = this.providers.filter((p) => p.score > 50);
        if (healthy.length === 0) {
          console.log("[RPC Balancer] All providers unhealthy, resetting scores");
          this.providers.forEach((p) => p.score = 100);
          return this.select();
        }
        const weighted = [];
        for (const p of healthy) {
          for (let i = 0; i < p.weight; i++) {
            weighted.push(p);
          }
        }
        const selected = weighted[Math.floor(Math.random() * weighted.length)];
        console.log(`[RPC Balancer] Selected provider: ${selected.name} (score: ${selected.score})`);
        return selected;
      }
      getConnection() {
        const provider = this.select();
        const url = provider.getUrl();
        return new Connection(url, { commitment: "confirmed" });
      }
      getHealthStats() {
        return this.providers.map((p) => ({
          name: p.name,
          score: p.score,
          fails: p.fails,
          weight: p.weight
        }));
      }
    };
    rpcBalancer = new SolanaRpcBalancer(RPC_PROVIDERS);
    setInterval(() => {
      rpcBalancer.providers.forEach(async (p) => {
        try {
          const url = p.getUrl();
          const conn = new Connection(url, { commitment: "confirmed" });
          await conn.getSlot();
          p.score = Math.min(100, p.score + 5);
        } catch (error) {
          p.score = Math.max(0, p.score - 10);
          p.fails++;
        }
      });
    }, 3e4);
  }
});

// server/services/lp-checker.ts
import { PublicKey as PublicKey2 } from "@solana/web3.js";
import { TOKEN_PROGRAM_ID as TOKEN_PROGRAM_ID2 } from "@solana/spl-token";
var LPChecker;
var init_lp_checker = __esm({
  "server/services/lp-checker.ts"() {
    "use strict";
    LPChecker = class {
      connection;
      constructor(connection) {
        this.connection = connection;
      }
      async isLPBurned(poolAddress) {
        try {
          const poolPubkey = new PublicKey2(poolAddress);
          const accounts = await this.connection.getTokenLargestAccounts(poolPubkey);
          if (!accounts || !accounts.value || accounts.value.length === 0) {
            return false;
          }
          return accounts.value.every((acc) => acc.uiAmount === 0 || acc.uiAmount === null);
        } catch (error) {
          console.error(`[LP Checker] Error checking LP burn for ${poolAddress}:`, error);
          return false;
        }
      }
      async isMintRenounced(mintAddress) {
        try {
          const mintPubkey = new PublicKey2(mintAddress);
          const mintInfo = await this.connection.getAccountInfo(mintPubkey);
          if (!mintInfo) {
            console.error(`[LP Checker] Mint account not found: ${mintAddress}`);
            return false;
          }
          const ownerIsTokenProgram = mintInfo.owner.equals(TOKEN_PROGRAM_ID2);
          return ownerIsTokenProgram;
        } catch (error) {
          console.error(`[LP Checker] Error checking mint renounced for ${mintAddress}:`, error);
          return false;
        }
      }
      async checkLPStatus(poolAddress, mintAddress) {
        const lpBurned = await this.isLPBurned(poolAddress);
        const mintRenounced = await this.isMintRenounced(mintAddress);
        let rugScore = 0;
        const warnings = [];
        if (!lpBurned) {
          rugScore += 40;
          warnings.push("LP NOT BURNED");
        }
        if (!mintRenounced) {
          rugScore += 30;
          warnings.push("MINT NOT RENOUNCED");
        }
        return {
          lpBurned,
          mintRenounced,
          rugScore,
          warnings
        };
      }
    };
  }
});

// server/solana-analyzer.ts
import { PublicKey as PublicKey3 } from "@solana/web3.js";
import { getMint } from "@solana/spl-token";
var SolanaTokenAnalyzer, tokenAnalyzer;
var init_solana_analyzer = __esm({
  "server/solana-analyzer.ts"() {
    "use strict";
    init_rugcheck_service();
    init_goplus_service();
    init_dexscreener_service();
    init_jupiter_service();
    init_known_addresses();
    init_birdeye_api();
    init_pumpfun_api();
    init_rpc_balancer();
    init_lp_checker();
    SolanaTokenAnalyzer = class {
      rugcheckService;
      goplusService;
      dexscreenerService;
      jupiterPriceService;
      constructor() {
        this.rugcheckService = new RugcheckService();
        this.goplusService = new GoPlusSecurityService();
        this.dexscreenerService = new DexScreenerService();
        this.jupiterPriceService = new JupiterPriceService();
      }
      getConnection() {
        return rpcBalancer.getConnection();
      }
      async analyzeToken(tokenAddress) {
        try {
          let mintPubkey;
          try {
            mintPubkey = new PublicKey3(tokenAddress);
          } catch (error) {
            throw new Error(`Invalid Solana address format: ${tokenAddress}`);
          }
          const connection = this.getConnection();
          const mintInfo = await getMint(connection, mintPubkey);
          const mintAuthority = this.analyzeMintAuthority(mintInfo.mintAuthority);
          const freezeAuthority = this.analyzeFreezeAuthority(mintInfo.freezeAuthority);
          const [onChainHolders, totalHolderCount, recentTransactions, rugcheckData, goplusData, dexscreenerData, jupiterPriceData, birdeyeData, pumpFunData] = await Promise.all([
            this.fetchTopHolders(mintPubkey, mintInfo.decimals, mintInfo.supply),
            this.getTotalHolderCount(mintPubkey).catch(() => null),
            this.fetchRecentTransactions(mintPubkey),
            this.rugcheckService.getTokenReport(tokenAddress).catch(() => null),
            this.goplusService.getTokenSecurity(tokenAddress).catch(() => null),
            this.dexscreenerService.getTokenData(tokenAddress).catch(() => null),
            this.jupiterPriceService.getTokenPrice(tokenAddress).catch(() => null),
            getBirdeyeOverview(tokenAddress).catch(() => null),
            checkPumpFun(tokenAddress).catch(() => ({ isPumpFun: false, devBought: 0, bondingCurve: 0 }))
          ]);
          const holders = onChainHolders.length > 0 ? onChainHolders : (rugcheckData?.topHolders || []).map((h, index2) => ({
            rank: index2 + 1,
            address: h.address || "",
            balance: h.pct || 0,
            percentage: h.pct || 0
          }));
          const holderCount = totalHolderCount || holders.length;
          const liquidityPool = this.analyzeLiquidity(0);
          const enrichedLiquidity = await this.enrichLiquidityWithMarketData(
            liquidityPool,
            rugcheckData,
            dexscreenerData,
            tokenAddress
          );
          const lpAddresses = enrichedLiquidity.lpAddresses || [];
          const bundledWallets = detectBundledWallets(holders);
          const pumpFunExclusions = [];
          if (pumpFunData?.isPumpFun) {
            const bondingCurve = getPumpFunBondingCurveAddress(tokenAddress);
            const associatedBondingCurve = getPumpFunAssociatedBondingCurveAddress(tokenAddress);
            if (bondingCurve) pumpFunExclusions.push(bondingCurve);
            if (associatedBondingCurve) pumpFunExclusions.push(associatedBondingCurve);
          }
          const addressesToExclude = /* @__PURE__ */ new Set([
            ...lpAddresses,
            ...bundledWallets,
            ...pumpFunExclusions
          ]);
          const filteredHolders = holders.filter((h) => {
            if (addressesToExclude.has(h.address)) return false;
            if (isKnownAddress(h.address)) return false;
            return true;
          });
          const topHolderConcentration = Math.min(100, Math.max(
            0,
            filteredHolders.slice(0, 10).reduce((sum, h) => sum + (h.percentage || 0), 0)
          ));
          const excludedAddresses = [];
          lpAddresses.forEach((addr) => {
            excludedAddresses.push({
              address: addr,
              type: "lp",
              reason: "Liquidity pool or token account"
            });
          });
          holders.forEach((h) => {
            if (isKnownAddress(h.address)) {
              const info = getKnownAddressInfo(h.address);
              excludedAddresses.push({
                address: h.address,
                type: info?.type === "exchange" ? "exchange" : "protocol",
                label: info?.label,
                reason: info?.label || "Known exchange/protocol"
              });
            }
          });
          bundledWallets.forEach((addr) => {
            excludedAddresses.push({
              address: addr,
              type: "bundled",
              reason: "Suspected bundled wallet (same purchase pattern)"
            });
          });
          pumpFunExclusions.forEach((addr) => {
            excludedAddresses.push({
              address: addr,
              type: "protocol",
              label: "Pump.fun Bonding Curve",
              reason: "Pump.fun bonding curve contract (not a real holder)"
            });
          });
          const bundledHolders = holders.filter((h) => bundledWallets.includes(h.address));
          const bundleSupplyPct = bundledHolders.reduce((sum, h) => sum + (h.percentage || 0), 0);
          const bundledSupplyAmount = onChainHolders.length > 0 ? bundledHolders.reduce((sum, h) => sum + (h.balance || 0), 0) : void 0;
          let bundleConfidence = "low";
          if (bundledWallets.length >= 5 || bundleSupplyPct >= 15) {
            bundleConfidence = "high";
          } else if (bundledWallets.length >= 3 || bundleSupplyPct >= 5) {
            bundleConfidence = "medium";
          }
          const holderFiltering = {
            totals: {
              lp: lpAddresses.length,
              exchanges: excludedAddresses.filter((a) => a.type === "exchange").length,
              protocols: excludedAddresses.filter((a) => a.type === "protocol").length,
              bundled: bundledWallets.length,
              total: excludedAddresses.length
            },
            excluded: excludedAddresses,
            bundledDetection: bundledWallets.length > 0 ? {
              strategy: "percentageMatch",
              confidence: bundleConfidence,
              details: `Detected ${bundledWallets.length} wallets with suspicious patterns`,
              bundleSupplyPct: Math.min(100, Math.max(0, bundleSupplyPct)),
              bundledSupplyAmount
            } : void 0
          };
          const supply = Number(mintInfo.supply);
          const safeSupply = isNaN(supply) || !isFinite(supply) ? 0 : supply;
          const dexService = new DexScreenerService();
          const primaryPair = dexscreenerData ? dexService.getMostLiquidPair(dexscreenerData) : null;
          const metadata = {
            name: primaryPair?.baseToken?.name || "Unknown Token",
            symbol: primaryPair?.baseToken?.symbol || tokenAddress.slice(0, 6),
            decimals: mintInfo.decimals || 0,
            supply: safeSupply,
            hasMetadata: !!primaryPair?.baseToken?.name,
            isMutable: mintAuthority.hasAuthority
          };
          const marketData = this.buildMarketData(primaryPair, rugcheckData);
          const redFlags = this.calculateRiskFlags(
            mintAuthority,
            freezeAuthority,
            enrichedLiquidity,
            topHolderConcentration,
            holderCount
          );
          const riskScore = this.calculateRiskScore(redFlags);
          const safeRiskScore = isNaN(riskScore) || !isFinite(riskScore) ? 100 : Math.min(100, Math.max(0, riskScore));
          const riskLevel = this.getRiskLevel(safeRiskScore);
          const now = Date.now();
          const safeAnalyzedAt = isNaN(now) || !isFinite(now) ? Date.now() : now;
          const aiVerdict = this.calculateAIVerdict({
            riskScore: safeRiskScore,
            mintAuthority,
            freezeAuthority,
            liquidityPool: enrichedLiquidity,
            marketData
          });
          return {
            tokenAddress,
            riskScore: safeRiskScore,
            riskLevel,
            analyzedAt: safeAnalyzedAt,
            mintAuthority,
            freezeAuthority,
            metadata,
            holderCount,
            topHolders: filteredHolders,
            // Return filtered holders (excluding LP, exchanges, bundles)
            topHolderConcentration: isNaN(topHolderConcentration) ? 0 : topHolderConcentration,
            holderFiltering,
            liquidityPool: enrichedLiquidity,
            marketData,
            recentTransactions,
            suspiciousActivityDetected: recentTransactions.some((tx) => tx.suspicious),
            redFlags,
            creationDate: void 0,
            aiVerdict,
            pumpFunData: pumpFunData || void 0,
            birdeyeData: birdeyeData || void 0,
            rugcheckData: rugcheckData || void 0,
            goplusData: goplusData || void 0,
            dexscreenerData: dexscreenerData || void 0,
            jupiterPriceData: jupiterPriceData || void 0
          };
        } catch (error) {
          console.error("Token analysis error:", error);
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          const isRateLimitError = errorMessage.includes("429") || errorMessage.toLowerCase().includes("rate limit") || errorMessage.toLowerCase().includes("too many requests");
          const isInvalidAddress = errorMessage.toLowerCase().includes("invalid") || errorMessage.toLowerCase().includes("not found");
          let errorDescription = "Unable to complete token analysis: ";
          if (isRateLimitError) {
            errorDescription += "Solana RPC rate limit reached. Please try again in a few moments.";
          } else if (isInvalidAddress) {
            errorDescription += "Invalid token address or token does not exist on-chain.";
          } else {
            errorDescription += `${errorMessage}. This may be due to network issues or an invalid token address.`;
          }
          return {
            tokenAddress,
            riskScore: 0,
            riskLevel: "EXTREME",
            analyzedAt: Date.now(),
            mintAuthority: { hasAuthority: true, authorityAddress: null, isRevoked: false },
            freezeAuthority: { hasAuthority: true, authorityAddress: null, isRevoked: false },
            metadata: {
              name: "Unknown Token",
              symbol: "???",
              decimals: 0,
              supply: 0,
              hasMetadata: false,
              isMutable: true
            },
            holderCount: 0,
            topHolders: [],
            topHolderConcentration: 0,
            holderFiltering: {
              totals: { lp: 0, exchanges: 0, protocols: 0, bundled: 0, total: 0 },
              excluded: []
            },
            liquidityPool: {
              exists: false,
              isLocked: false,
              isBurned: false,
              status: "UNKNOWN"
            },
            recentTransactions: [],
            suspiciousActivityDetected: false,
            redFlags: [{
              type: "mint_authority",
              severity: "critical",
              title: isRateLimitError ? "Rate Limit Reached" : "Analysis Failed",
              description: errorDescription
            }],
            creationDate: void 0
          };
        }
      }
      analyzeMintAuthority(authority) {
        return {
          hasAuthority: authority !== null,
          authorityAddress: authority?.toBase58() || null,
          isRevoked: authority === null
        };
      }
      analyzeFreezeAuthority(authority) {
        return {
          hasAuthority: authority !== null,
          authorityAddress: authority?.toBase58() || null,
          isRevoked: authority === null
        };
      }
      async fetchTopHolders(mintPubkey, decimals, totalSupply) {
        let attempts = 0;
        const maxAttempts = 3;
        while (attempts < maxAttempts) {
          try {
            const connection = this.getConnection();
            const tokenAccounts = await connection.getTokenLargestAccounts(mintPubkey);
            const holders = tokenAccounts.value.map((account, index2) => {
              const balance = Number(account.amount);
              const percentage = balance / Number(totalSupply) * 100;
              return {
                rank: index2 + 1,
                address: account.address.toBase58(),
                balance,
                percentage
              };
            }).filter((h) => h.balance > 0).sort((a, b) => b.balance - a.balance).slice(0, 20);
            return holders;
          } catch (error) {
            attempts++;
            const isRateLimit = error.message?.includes("429") || error.message?.includes("Too Many Requests");
            const isUnsupported = error.code === -32600 || error.message?.includes("not supported") || error.message?.includes("Too many accounts");
            if (isRateLimit) {
              console.log(`[RPC Balancer] Rate limited on attempt ${attempts}, rotating provider...`);
              if (attempts < maxAttempts) {
                await new Promise((resolve) => setTimeout(resolve, 1e3 * attempts));
                continue;
              }
            } else if (isUnsupported && attempts < maxAttempts) {
              await new Promise((resolve) => setTimeout(resolve, 500));
              continue;
            }
            if (attempts >= maxAttempts && !isUnsupported) {
              console.error(`Error fetching top holders after ${maxAttempts} attempts:`, error.message);
            }
            if (attempts >= maxAttempts) {
              return [];
            }
          }
        }
        return [];
      }
      async getTotalHolderCount(mintPubkey) {
        let attempts = 0;
        const maxAttempts = 3;
        while (attempts < maxAttempts) {
          try {
            const connection = this.getConnection();
            const TOKEN_PROGRAM_ID4 = new PublicKey3("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
            const accounts = await connection.getProgramAccounts(
              TOKEN_PROGRAM_ID4,
              {
                filters: [
                  { dataSize: 165 },
                  // Token account data size
                  {
                    memcmp: {
                      offset: 0,
                      bytes: mintPubkey.toBase58()
                    }
                  }
                ]
              }
            );
            const nonZeroAccounts = accounts.filter((account) => {
              const data = account.account.data;
              if (Buffer.isBuffer(data)) {
                const amount = data.readBigUInt64LE(64);
                return amount > BigInt(0);
              }
              return false;
            });
            return nonZeroAccounts.length;
          } catch (error) {
            attempts++;
            const isRateLimit = error.message?.includes("429") || error.message?.includes("Too Many Requests");
            const isUnsupported = error.code === -32600 || error.message?.includes("not supported") || error.message?.includes("Too many accounts");
            if (isRateLimit) {
              console.log(`[RPC Balancer] Rate limited on attempt ${attempts}, rotating provider...`);
              if (attempts < maxAttempts) {
                await new Promise((resolve) => setTimeout(resolve, 1e3 * attempts));
                continue;
              }
            } else if (isUnsupported && attempts < maxAttempts) {
              await new Promise((resolve) => setTimeout(resolve, 500));
              continue;
            }
            if (attempts >= maxAttempts && !isUnsupported) {
              console.error(`Error fetching total holder count after ${maxAttempts} attempts:`, error.message);
            }
            if (attempts >= maxAttempts) {
              return null;
            }
          }
        }
        return null;
      }
      analyzeLiquidity(topHolderConcentration) {
        return {
          exists: true,
          status: "UNKNOWN"
          // Don't set isBurned, isLocked, or burnPercentage here
          // They will be enriched with real data if available from Rugcheck/DexScreener
        };
      }
      buildMarketData(primaryPair, rugcheckData) {
        if (!primaryPair) {
          return void 0;
        }
        const parseNumeric = (value) => {
          if (value === null || value === void 0) return null;
          const num = typeof value === "string" ? parseFloat(value) : value;
          return isNaN(num) || !isFinite(num) ? null : num;
        };
        return {
          priceUsd: parseNumeric(primaryPair.priceUsd),
          priceNative: parseNumeric(primaryPair.priceNative),
          marketCap: parseNumeric(primaryPair.marketCap),
          fdv: parseNumeric(primaryPair.fdv),
          volume24h: parseNumeric(primaryPair.volume?.h24),
          priceChange24h: parseNumeric(primaryPair.priceChange?.h24),
          txns24h: primaryPair.txns?.h24 ? {
            buys: primaryPair.txns.h24.buys || 0,
            sells: primaryPair.txns.h24.sells || 0
          } : null,
          liquidityUsd: parseNumeric(primaryPair.liquidity?.usd),
          source: "dexscreener",
          pairAddress: primaryPair.pairAddress || null,
          dexId: primaryPair.dexId || null,
          updatedAt: Date.now()
        };
      }
      async enrichLiquidityWithMarketData(liquidityPool, rugcheckData, dexscreenerData, tokenAddress) {
        const lpAddresses = [];
        if (dexscreenerData?.pairs) {
          dexscreenerData.pairs.forEach((pair) => {
            if (pair.pairAddress) {
              lpAddresses.push(pair.pairAddress);
            }
          });
        }
        if (rugcheckData?.markets) {
          rugcheckData.markets.forEach((market) => {
            if (market.pubkey) lpAddresses.push(market.pubkey);
            if (market.liquidityA) lpAddresses.push(market.liquidityA);
            if (market.liquidityB) lpAddresses.push(market.liquidityB);
          });
        }
        const uniqueLpAddresses = Array.from(new Set(lpAddresses));
        const dexService = new DexScreenerService();
        const primaryPair = dexscreenerData ? dexService.getMostLiquidPair(dexscreenerData) : null;
        let totalLiquidity = primaryPair?.liquidity?.usd;
        const connection = this.getConnection();
        const lpChecker = new LPChecker(connection);
        let isBurned = false;
        let isLocked = false;
        let burnPercentage = 0;
        if (rugcheckData?.markets && rugcheckData.markets.length > 0) {
          const primaryMarket = rugcheckData.markets.reduce((prev, current) => {
            return (current.liquidity || 0) > (prev.liquidity || 0) ? current : prev;
          });
          if (!totalLiquidity) {
            totalLiquidity = primaryMarket.liquidity;
          }
          const isPumpFun = primaryMarket.marketType?.startsWith("pump_fun") || false;
          if (isPumpFun && primaryMarket.lp) {
            burnPercentage = primaryMarket.lp.lpLockedPct || 0;
            isLocked = burnPercentage >= 90;
            isBurned = false;
            if (!totalLiquidity && primaryMarket.lp.lpLockedUSD) {
              totalLiquidity = primaryMarket.lp.lpLockedUSD;
            }
          } else if (primaryPair?.pairAddress) {
            try {
              isBurned = await lpChecker.isLPBurned(primaryPair.pairAddress);
              burnPercentage = isBurned ? 100 : 0;
              isLocked = false;
            } catch (error) {
              console.error("[LP Check] Failed to check LP burn status:", error);
              isBurned = false;
              isLocked = false;
              burnPercentage = 0;
            }
          }
          const hasLiquidity = totalLiquidity && totalLiquidity > 1e3 || false;
          let status = liquidityPool.status;
          if ((isBurned || isLocked) && hasLiquidity) {
            status = "SAFE";
          } else if (hasLiquidity && !isBurned && !isLocked) {
            status = "RISKY";
          }
          return {
            ...liquidityPool,
            isBurned,
            isLocked,
            burnPercentage,
            totalLiquidity,
            lpAddresses: uniqueLpAddresses,
            status
          };
        }
        if (primaryPair?.liquidity?.usd) {
          return {
            ...liquidityPool,
            totalLiquidity: primaryPair.liquidity.usd,
            lpAddresses: uniqueLpAddresses,
            status: totalLiquidity && totalLiquidity > 1e3 ? "RISKY" : "UNKNOWN"
          };
        }
        if (uniqueLpAddresses.length > 0) {
          return {
            ...liquidityPool,
            lpAddresses: uniqueLpAddresses
          };
        }
        return liquidityPool;
      }
      async fetchRecentTransactions(mintPubkey) {
        try {
          const connection = this.getConnection();
          const signatures = await connection.getSignaturesForAddress(mintPubkey, { limit: 10 });
          return signatures.slice(0, 5).map((sig, index2) => ({
            signature: sig.signature,
            type: index2 % 3 === 0 ? "transfer" : index2 % 3 === 1 ? "swap" : "mint",
            timestamp: (sig.blockTime || 0) * 1e3,
            suspicious: false
          }));
        } catch (error) {
          console.error("Error fetching transactions:", error);
          return [];
        }
      }
      calculateRiskFlags(mintAuthority, freezeAuthority, liquidityPool, topHolderConcentration, holderCount) {
        const flags = [];
        if (mintAuthority.hasAuthority) {
          flags.push({
            type: "mint_authority",
            severity: "critical",
            title: "Mint Authority Not Revoked",
            description: "The mint authority has not been revoked. The developer can mint unlimited tokens, potentially diluting holders."
          });
        }
        if (freezeAuthority.hasAuthority) {
          flags.push({
            type: "freeze_authority",
            severity: "high",
            title: "Freeze Authority Active",
            description: "The freeze authority is active. The developer can freeze token accounts, preventing users from selling."
          });
        }
        if (topHolderConcentration > 70) {
          flags.push({
            type: "holder_concentration",
            severity: "critical",
            title: "Extreme Holder Concentration",
            description: `Top 10 holders control ${topHolderConcentration.toFixed(1)}% of supply. High risk of coordinated dumps.`
          });
        } else if (topHolderConcentration > 50) {
          flags.push({
            type: "holder_concentration",
            severity: "high",
            title: "High Holder Concentration",
            description: `Top 10 holders control ${topHolderConcentration.toFixed(1)}% of supply. Risk of price manipulation.`
          });
        }
        if (holderCount < 100) {
          flags.push({
            type: "holder_concentration",
            severity: "medium",
            title: "Low Holder Count",
            description: `Only ${holderCount} holders detected. Low distribution may indicate early-stage or low interest.`
          });
        }
        if (liquidityPool.status === "RISKY") {
          flags.push({
            type: "low_liquidity",
            severity: "critical",
            title: "Risky Liquidity Status",
            description: "Liquidity pool appears to be at risk. May not be locked or burned."
          });
        }
        return flags;
      }
      calculateRiskScore(redFlags) {
        let score = 100;
        for (const flag of redFlags) {
          switch (flag.severity) {
            case "critical":
              score -= 30;
              break;
            case "high":
              score -= 20;
              break;
            case "medium":
              score -= 10;
              break;
            case "low":
              score -= 5;
              break;
          }
        }
        return Math.max(0, score);
      }
      getRiskLevel(score) {
        if (score >= 70) return "LOW";
        if (score >= 40) return "MODERATE";
        if (score >= 20) return "HIGH";
        return "EXTREME";
      }
      calculateAIVerdict(analysis) {
        const score = analysis.riskScore;
        const mintRenounced = !analysis.mintAuthority.hasAuthority;
        const freezeDisabled = !analysis.freezeAuthority.hasAuthority;
        const lpBurned = analysis.liquidityPool.isBurned || analysis.liquidityPool.isLocked || false;
        const mcap = analysis.marketData?.marketCap || 0;
        if (score >= 75 && mintRenounced && freezeDisabled && lpBurned) {
          return {
            rating: "10/10",
            verdict: "\u{1F7E2} MOON SHOT - RICK BOT WOULD APE"
          };
        } else if (score >= 50 && mcap < 5e5) {
          return {
            rating: "7/10",
            verdict: "\u{1F7E1} HIGH RISK/HIGH REWARD - PHANES SAYS WATCH"
          };
        } else if (score >= 30) {
          return {
            rating: "5/10",
            verdict: "\u{1F7E0} PROCEED WITH CAUTION - SMALL BAG ONLY"
          };
        } else {
          return {
            rating: "3/10",
            verdict: "\u{1F534} RUG CITY - TROJAN WOULD BLOCK"
          };
        }
      }
    };
    tokenAnalyzer = new SolanaTokenAnalyzer();
  }
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
var pool, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    neonConfig.webSocketConstructor = ws;
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    db = drizzle({ client: pool, schema: schema_exports });
  }
});

// server/storage.ts
import { eq, and, inArray, desc, sql as sql2 } from "drizzle-orm";
var DatabaseStorage, storage;
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_schema();
    init_db();
    DatabaseStorage = class {
      // User operations
      async getUser(id) {
        const [user] = await db.select().from(users).where(eq(users.id, id));
        return user;
      }
      async upsertUser(userData) {
        const [user] = await db.insert(users).values(userData).onConflictDoUpdate({
          target: users.id,
          set: {
            ...userData,
            updatedAt: /* @__PURE__ */ new Date()
          }
        }).returning();
        return user;
      }
      async updateUserWhopInfo(userId, whopUserId) {
        const [user] = await db.update(users).set({
          whopUserId,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq(users.id, userId)).returning();
        return user;
      }
      // Subscription operations
      async getSubscription(userId) {
        const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId));
        return subscription;
      }
      async getSubscriptionByWhopId(whopMembershipId) {
        const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.whopMembershipId, whopMembershipId));
        return subscription;
      }
      async createSubscription(subscriptionData) {
        const [subscription] = await db.insert(subscriptions).values(subscriptionData).returning();
        return subscription;
      }
      async updateSubscription(id, data) {
        const [subscription] = await db.update(subscriptions).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptions.id, id)).returning();
        return subscription;
      }
      // Subscription code operations
      async getSubscriptionCode(code) {
        const [subscriptionCode] = await db.select().from(subscriptionCodes).where(eq(subscriptionCodes.code, code));
        return subscriptionCode;
      }
      async redeemCode(userId, code) {
        return await db.transaction(async (tx) => {
          const [codeRecord] = await tx.select().from(subscriptionCodes).where(eq(subscriptionCodes.code, code)).for("update");
          if (!codeRecord) {
            return { success: false, message: "Invalid code" };
          }
          if (!codeRecord.isActive) {
            return { success: false, message: "This code has been deactivated" };
          }
          if (codeRecord.expiresAt && codeRecord.expiresAt < /* @__PURE__ */ new Date()) {
            return { success: false, message: "This code has expired" };
          }
          if (codeRecord.maxUses && codeRecord.usedCount >= codeRecord.maxUses) {
            return { success: false, message: "This code has reached its maximum uses" };
          }
          const [existingRedemption] = await tx.select().from(codeRedemptions).where(and(
            eq(codeRedemptions.userId, userId),
            eq(codeRedemptions.code, code)
          ));
          if (existingRedemption) {
            return { success: false, message: "You have already redeemed this code" };
          }
          const [existingSubscription] = await tx.select().from(subscriptions).where(eq(subscriptions.userId, userId));
          let subscription;
          if (existingSubscription) {
            const [updated] = await tx.update(subscriptions).set({
              tier: codeRecord.tier,
              status: "valid",
              currentPeriodEnd: /* @__PURE__ */ new Date("2099-12-31"),
              updatedAt: /* @__PURE__ */ new Date()
            }).where(eq(subscriptions.id, existingSubscription.id)).returning();
            subscription = updated;
          } else {
            const [created] = await tx.insert(subscriptions).values({
              userId,
              tier: codeRecord.tier,
              status: "valid",
              currentPeriodEnd: /* @__PURE__ */ new Date("2099-12-31")
            }).returning();
            subscription = created;
          }
          await tx.insert(codeRedemptions).values({
            userId,
            codeId: codeRecord.id,
            code: codeRecord.code
          });
          await tx.update(subscriptionCodes).set({
            usedCount: sql2`${subscriptionCodes.usedCount} + 1`,
            updatedAt: /* @__PURE__ */ new Date()
          }).where(eq(subscriptionCodes.id, codeRecord.id));
          return {
            success: true,
            message: `Successfully activated ${codeRecord.tier} subscription!`,
            subscription
          };
        });
      }
      // Access control - checks subscription OR token holder status
      async hasActiveAccess(userId) {
        const now = /* @__PURE__ */ new Date();
        const subscription = await this.getSubscription(userId);
        if (subscription) {
          if (subscription.tier === "lifetime" && subscription.status === "valid") {
            return {
              hasAccess: true,
              reason: `Lifetime subscription (never expires)`,
              subscription
            };
          }
          const periodEnd = subscription.currentPeriodEnd || subscription.trialEndsAt;
          const activeStatuses = ["valid", "trialing", "past_due"];
          if (activeStatuses.includes(subscription.status) && periodEnd && periodEnd > now) {
            return {
              hasAccess: true,
              reason: `Active ${subscription.tier} subscription (${subscription.status}) until ${periodEnd.toISOString()}`,
              subscription
            };
          }
          if ((subscription.tier === "free_trial" || subscription.status === "trialing") && periodEnd && periodEnd <= now) {
            const updated = await this.updateSubscription(subscription.id, {
              status: "expired"
            });
            subscription.status = updated.status;
          }
        }
        const wallet = await this.getWalletConnection(userId);
        if (wallet?.isEligible) {
          const lastVerified = wallet.lastVerifiedAt ? new Date(wallet.lastVerifiedAt) : null;
          const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1e3);
          if (lastVerified && lastVerified > twentyFourHoursAgo) {
            return {
              hasAccess: true,
              reason: `Token holder with ${wallet.tokenBalance.toLocaleString()} tokens (verified ${lastVerified.toISOString()})`,
              wallet
            };
          } else {
            return {
              hasAccess: false,
              reason: "Token balance verification expired (older than 24 hours). Please reverify your wallet.",
              wallet
            };
          }
        }
        if (subscription?.tier === "free_trial") {
          return {
            hasAccess: false,
            reason: "Free trial expired. Please subscribe or connect a wallet with 10M+ tokens.",
            subscription
          };
        }
        return {
          hasAccess: false,
          reason: "No active subscription or token holder status. Please subscribe or connect a wallet with 10M+ tokens.",
          subscription,
          wallet
        };
      }
      // Wallet connection operations
      async getWalletConnection(userId) {
        const [wallet] = await db.select().from(walletConnections).where(eq(walletConnections.userId, userId));
        return wallet;
      }
      async getWalletByAddress(walletAddress) {
        const [wallet] = await db.select().from(walletConnections).where(eq(walletConnections.walletAddress, walletAddress));
        return wallet;
      }
      async createWalletConnection(walletData) {
        const [wallet] = await db.insert(walletConnections).values(walletData).returning();
        return wallet;
      }
      async updateWalletBalance(walletAddress, balance, isEligible) {
        const [wallet] = await db.update(walletConnections).set({
          tokenBalance: balance,
          isEligible,
          lastVerifiedAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq(walletConnections.walletAddress, walletAddress)).returning();
        return wallet;
      }
      // Wallet challenge operations (anti-replay)
      async createChallenge(userId) {
        const challenge = `verify-${userId}-${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
        const expiresAt = new Date(Date.now() + 5 * 60 * 1e3);
        const [created] = await db.insert(walletChallenges).values({
          userId,
          challenge,
          expiresAt
        }).returning();
        return created;
      }
      async getChallenge(challenge) {
        const [found] = await db.select().from(walletChallenges).where(eq(walletChallenges.challenge, challenge));
        return found;
      }
      async markChallengeUsed(challengeId) {
        const [updated] = await db.update(walletChallenges).set({
          usedAt: /* @__PURE__ */ new Date()
        }).where(eq(walletChallenges.id, challengeId)).returning();
        return updated;
      }
      // KOL wallet operations
      async isKolWallet(walletAddress) {
        const [kol] = await db.select({ id: kolWallets.id }).from(kolWallets).where(eq(kolWallets.walletAddress, walletAddress)).limit(1);
        return !!kol;
      }
      async getKolWallet(walletAddress) {
        const [kol] = await db.select().from(kolWallets).where(eq(kolWallets.walletAddress, walletAddress));
        return kol;
      }
      async getTopKolWallets(limit = 100) {
        return await db.select().from(kolWallets).where(eq(kolWallets.isVerified, true)).orderBy(desc(kolWallets.influenceScore), desc(kolWallets.rank)).limit(limit);
      }
      async getKolWalletsByAddresses(addresses) {
        if (addresses.length === 0) return [];
        return await db.select().from(kolWallets).where(inArray(kolWallets.walletAddress, addresses));
      }
      // Watchlist operations
      async addToWatchlist(entry) {
        const [watchlistEntry] = await db.insert(watchlistEntries).values(entry).returning();
        return watchlistEntry;
      }
      async removeFromWatchlist(userId, tokenAddress) {
        await db.delete(watchlistEntries).where(
          and(
            eq(watchlistEntries.userId, userId),
            eq(watchlistEntries.tokenAddress, tokenAddress)
          )
        );
      }
      async getWatchlist(userId) {
        return await db.select().from(watchlistEntries).where(eq(watchlistEntries.userId, userId)).orderBy(desc(watchlistEntries.createdAt));
      }
      // Portfolio operations
      async getPortfolioPositions(userId) {
        return await db.select().from(portfolioPositions).where(eq(portfolioPositions.userId, userId)).orderBy(desc(portfolioPositions.updatedAt));
      }
      async getPortfolioPosition(userId, tokenAddress) {
        const [position] = await db.select().from(portfolioPositions).where(
          and(
            eq(portfolioPositions.userId, userId),
            eq(portfolioPositions.tokenAddress, tokenAddress)
          )
        );
        return position;
      }
      async recordTransaction(userId, tx) {
        const Decimal = (await import("decimal.js")).default;
        const quantity = new Decimal(String(tx.quantity));
        if (quantity.isZero() || quantity.isNegative()) {
          throw new Error("Transaction quantity must be positive");
        }
        if (tx.txType === "buy" || tx.txType === "sell") {
          if (!tx.priceUsd || tx.priceUsd === "" || tx.priceUsd === null) {
            throw new Error(`priceUsd is required for ${tx.txType} transactions`);
          }
          const price = new Decimal(String(tx.priceUsd));
          if (price.isNegative()) {
            throw new Error("Price must be positive");
          }
        }
        const result = await db.transaction(async (trx) => {
          let [position] = await trx.select().from(portfolioPositions).where(
            and(
              eq(portfolioPositions.userId, userId),
              eq(portfolioPositions.tokenAddress, tx.tokenAddress)
            )
          ).for("update");
          if (!position) {
            [position] = await trx.insert(portfolioPositions).values({
              userId,
              tokenAddress: tx.tokenAddress,
              quantity: "0",
              avgCostUsd: null,
              realizedPnlUsd: "0",
              latestPriceUsd: null,
              unrealizedPnlUsd: null,
              pnlPct: null,
              lastRebalancedAt: null
            }).returning();
          }
          const oldQuantity = new Decimal(position.quantity || "0");
          const oldAvgCost = position.avgCostUsd ? new Decimal(position.avgCostUsd) : new Decimal(0);
          const oldRealizedPnl = new Decimal(position.realizedPnlUsd || "0");
          const txPrice = tx.priceUsd ? new Decimal(tx.priceUsd.toString()) : new Decimal(0);
          const txFee = tx.feeUsd ? new Decimal(tx.feeUsd.toString()) : new Decimal(0);
          let newQuantity;
          let newAvgCost;
          let newRealizedPnl;
          switch (tx.txType) {
            case "buy":
              newQuantity = oldQuantity.plus(quantity);
              const totalCost = oldQuantity.times(oldAvgCost).plus(quantity.times(txPrice)).plus(txFee);
              newAvgCost = totalCost.div(newQuantity);
              newRealizedPnl = oldRealizedPnl;
              break;
            case "sell":
              if (oldQuantity.lessThan(quantity)) {
                throw new Error(`Insufficient holdings: have ${oldQuantity.toFixed(4)}, trying to sell ${quantity.toFixed(4)}`);
              }
              const afterSellQuantity = oldQuantity.minus(quantity);
              if (afterSellQuantity.isNegative()) {
                throw new Error(`Sell would result in negative quantity`);
              }
              const proceeds = txPrice.times(quantity).minus(txFee);
              const costBasis = oldAvgCost.times(quantity);
              const realizedGain = proceeds.minus(costBasis);
              newQuantity = afterSellQuantity;
              newRealizedPnl = oldRealizedPnl.plus(realizedGain);
              newAvgCost = newQuantity.isZero() ? null : oldAvgCost;
              break;
            case "airdrop":
              newQuantity = oldQuantity.plus(quantity);
              newAvgCost = oldQuantity.isZero() ? new Decimal(0) : oldQuantity.times(oldAvgCost).div(newQuantity);
              newRealizedPnl = oldRealizedPnl;
              break;
            case "manual_adjust":
              const adjustment = quantity.times(tx.priceUsd ? new Decimal(tx.priceUsd.toString()) : new Decimal(0));
              if (adjustment.isNegative()) {
                if (oldQuantity.lessThan(quantity.abs())) {
                  throw new Error("Manual adjustment would result in negative quantity");
                }
                newQuantity = oldQuantity.minus(quantity.abs());
              } else {
                newQuantity = oldQuantity.plus(quantity);
              }
              newAvgCost = oldAvgCost;
              newRealizedPnl = oldRealizedPnl;
              break;
            default:
              throw new Error(`Unknown transaction type: ${tx.txType}`);
          }
          if (newQuantity.isNegative()) {
            throw new Error("Transaction would result in negative quantity");
          }
          const [transaction] = await trx.insert(portfolioTransactions).values({
            positionId: position.id,
            userId,
            txType: tx.txType,
            quantity: quantity.toFixed(12),
            priceUsd: tx.priceUsd ? txPrice.toFixed(8) : null,
            feeUsd: txFee.toFixed(8),
            note: tx.note || null,
            executedAt: tx.executedAt || /* @__PURE__ */ new Date()
          }).returning();
          const [updatedPosition] = await trx.update(portfolioPositions).set({
            quantity: newQuantity.toFixed(12),
            avgCostUsd: newAvgCost ? newAvgCost.toFixed(8) : null,
            realizedPnlUsd: newRealizedPnl.toFixed(8),
            updatedAt: /* @__PURE__ */ new Date()
          }).where(eq(portfolioPositions.id, position.id)).returning();
          return { transaction, position: updatedPosition };
        });
        return result;
      }
      async getTransactionHistory(userId, tokenAddress) {
        if (tokenAddress) {
          const position = await this.getPortfolioPosition(userId, tokenAddress);
          if (!position) return [];
          return await db.select().from(portfolioTransactions).where(eq(portfolioTransactions.positionId, position.id)).orderBy(desc(portfolioTransactions.executedAt));
        }
        return await db.select().from(portfolioTransactions).where(eq(portfolioTransactions.userId, userId)).orderBy(desc(portfolioTransactions.executedAt));
      }
      async deletePosition(userId, tokenAddress) {
        await db.delete(portfolioPositions).where(
          and(
            eq(portfolioPositions.userId, userId),
            eq(portfolioPositions.tokenAddress, tokenAddress)
          )
        );
      }
      // Price alerts operations
      async createPriceAlert(alert) {
        const [priceAlert] = await db.insert(priceAlerts).values(alert).returning();
        return priceAlert;
      }
      async getPriceAlerts(userId) {
        return await db.select().from(priceAlerts).where(eq(priceAlerts.userId, userId)).orderBy(desc(priceAlerts.createdAt));
      }
      async getActivePriceAlerts() {
        return await db.select().from(priceAlerts).where(eq(priceAlerts.isActive, true));
      }
      async updatePriceAlert(alertId, data) {
        const [updated] = await db.update(priceAlerts).set(data).where(eq(priceAlerts.id, alertId)).returning();
        return updated;
      }
      async deletePriceAlert(userId, alertId) {
        await db.delete(priceAlerts).where(
          and(
            eq(priceAlerts.id, alertId),
            eq(priceAlerts.userId, userId)
          )
        );
      }
      async triggerAlert(alertId, currentPrice) {
        const [updated] = await db.update(priceAlerts).set({
          isActive: false,
          triggeredAt: /* @__PURE__ */ new Date(),
          lastPrice: currentPrice.toString()
        }).where(eq(priceAlerts.id, alertId)).returning();
        return updated;
      }
      // Analytics operations
      async saveTokenSnapshot(snapshot) {
        const [saved] = await db.insert(tokenSnapshots).values(snapshot).returning();
        return saved;
      }
      async getHistoricalData(tokenAddress, days) {
        const cutoffDate = /* @__PURE__ */ new Date();
        cutoffDate.setDate(cutoffDate.getDate() - days);
        return await db.select().from(tokenSnapshots).where(
          and(
            eq(tokenSnapshots.tokenAddress, tokenAddress),
            sql2`${tokenSnapshots.capturedAt} >= ${cutoffDate}`
          )
        ).orderBy(tokenSnapshots.capturedAt);
      }
      async getTrendingTokens(limit = 50) {
        return await db.select().from(trendingTokens).orderBy(trendingTokens.rank).limit(limit);
      }
      async updateTrendingScores(tokens) {
        if (tokens.length === 0) return;
        await db.transaction(async (tx) => {
          for (const token of tokens) {
            await tx.insert(trendingTokens).values(token).onConflictDoUpdate({
              target: trendingTokens.tokenAddress,
              set: {
                score: token.score,
                scoreBreakdown: token.scoreBreakdown,
                rank: token.rank,
                volume24h: token.volume24h,
                velocity: token.velocity,
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
          }
        });
      }
      async getRiskStatistics(windowDays) {
        const windowStart = /* @__PURE__ */ new Date();
        windowStart.setDate(windowStart.getDate() - windowDays);
        const [stats] = await db.select().from(riskStatistics).where(sql2`${riskStatistics.windowStart} >= ${windowStart}`).orderBy(desc(riskStatistics.windowEnd)).limit(1);
        return stats;
      }
      async saveRiskStatistics(stats) {
        const [saved] = await db.insert(riskStatistics).values(stats).returning();
        return saved;
      }
      // Social features - User profiles
      async getUserProfile(userId) {
        const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
        return profile;
      }
      async createUserProfile(profile) {
        const [newProfile] = await db.insert(userProfiles).values(profile).returning();
        return newProfile;
      }
      async updateUserProfile(userId, data) {
        const [updated] = await db.update(userProfiles).set(data).where(eq(userProfiles.userId, userId)).returning();
        return updated;
      }
      async getTopUsers(limit = 10) {
        return await db.select().from(userProfiles).orderBy(desc(userProfiles.reputationScore)).limit(limit);
      }
      // Social features - Comments
      async createComment(comment) {
        const [newComment] = await db.insert(tokenComments).values(comment).returning();
        return newComment;
      }
      async getCommentsByToken(tokenAddress) {
        const comments = await db.select({
          id: tokenComments.id,
          tokenAddress: tokenComments.tokenAddress,
          userId: tokenComments.userId,
          commentText: tokenComments.commentText,
          rating: tokenComments.rating,
          upvoteCount: tokenComments.upvoteCount,
          downvoteCount: tokenComments.downvoteCount,
          flagged: tokenComments.flagged,
          createdAt: tokenComments.createdAt,
          author: users
        }).from(tokenComments).leftJoin(users, eq(tokenComments.userId, users.id)).where(eq(tokenComments.tokenAddress, tokenAddress)).orderBy(desc(tokenComments.createdAt));
        return comments;
      }
      async getComment(id) {
        const [comment] = await db.select().from(tokenComments).where(eq(tokenComments.id, id));
        return comment;
      }
      async getFlaggedComments() {
        const comments = await db.select({
          id: tokenComments.id,
          tokenAddress: tokenComments.tokenAddress,
          userId: tokenComments.userId,
          commentText: tokenComments.commentText,
          rating: tokenComments.rating,
          upvoteCount: tokenComments.upvoteCount,
          downvoteCount: tokenComments.downvoteCount,
          flagged: tokenComments.flagged,
          createdAt: tokenComments.createdAt,
          author: users
        }).from(tokenComments).leftJoin(users, eq(tokenComments.userId, users.id)).where(eq(tokenComments.flagged, true)).orderBy(desc(tokenComments.createdAt));
        return comments;
      }
      async deleteComment(id, userId) {
        await db.delete(tokenComments).where(
          and(
            eq(tokenComments.id, id),
            eq(tokenComments.userId, userId)
          )
        );
      }
      async flagComment(id) {
        const [flagged] = await db.update(tokenComments).set({ flagged: true }).where(eq(tokenComments.id, id)).returning();
        return flagged;
      }
      async updateCommentVoteCounts(commentId) {
        const votes = await db.select().from(commentVotes).where(eq(commentVotes.commentId, commentId));
        const upvotes = votes.filter((v) => v.voteType === "up").length;
        const downvotes = votes.filter((v) => v.voteType === "down").length;
        await db.update(tokenComments).set({ upvoteCount: upvotes, downvoteCount: downvotes }).where(eq(tokenComments.id, commentId));
      }
      // Social features - Comment votes
      async voteComment(vote) {
        const [newVote] = await db.insert(commentVotes).values(vote).onConflictDoUpdate({
          target: [commentVotes.userId, commentVotes.commentId],
          set: { voteType: vote.voteType }
        }).returning();
        await this.updateCommentVoteCounts(vote.commentId);
        return newVote;
      }
      async removeCommentVote(userId, commentId) {
        await db.delete(commentVotes).where(
          and(
            eq(commentVotes.userId, userId),
            eq(commentVotes.commentId, commentId)
          )
        );
        await this.updateCommentVoteCounts(commentId);
      }
      async getUserCommentVote(userId, commentId) {
        const [vote] = await db.select().from(commentVotes).where(
          and(
            eq(commentVotes.userId, userId),
            eq(commentVotes.commentId, commentId)
          )
        );
        return vote;
      }
      // Social features - Community votes
      async createCommunityVote(vote) {
        const [newVote] = await db.insert(communityVotes).values(vote).onConflictDoUpdate({
          target: [communityVotes.tokenAddress, communityVotes.userId],
          set: {
            voteType: vote.voteType,
            confidence: vote.confidence,
            reason: vote.reason,
            weight: vote.weight
          }
        }).returning();
        return newVote;
      }
      async updateCommunityVote(id, data) {
        const [updated] = await db.update(communityVotes).set(data).where(eq(communityVotes.id, id)).returning();
        return updated;
      }
      async deleteCommunityVote(id, userId) {
        await db.delete(communityVotes).where(
          and(
            eq(communityVotes.id, id),
            eq(communityVotes.userId, userId)
          )
        );
      }
      async getUserCommunityVote(tokenAddress, userId) {
        const [vote] = await db.select().from(communityVotes).where(
          and(
            eq(communityVotes.tokenAddress, tokenAddress),
            eq(communityVotes.userId, userId)
          )
        );
        return vote;
      }
      async getCommunityVoteSummary(tokenAddress) {
        const [summary] = await db.select().from(communityVoteSummaries).where(eq(communityVoteSummaries.tokenAddress, tokenAddress));
        return summary;
      }
      async upsertVoteSummary(summary) {
        const [upserted] = await db.insert(communityVoteSummaries).values(summary).onConflictDoUpdate({
          target: communityVoteSummaries.tokenAddress,
          set: {
            safeWeight: summary.safeWeight,
            riskyWeight: summary.riskyWeight,
            scamWeight: summary.scamWeight,
            totalVotes: summary.totalVotes,
            consensus: summary.consensus,
            updatedAt: /* @__PURE__ */ new Date()
          }
        }).returning();
        return upserted;
      }
      // Social features - Shared watchlists
      async createSharedWatchlist(watchlist) {
        const [newWatchlist] = await db.insert(sharedWatchlists).values(watchlist).returning();
        return newWatchlist;
      }
      async getSharedWatchlist(id) {
        const [watchlist] = await db.select().from(sharedWatchlists).where(eq(sharedWatchlists.id, id));
        return watchlist;
      }
      async getSharedWatchlistBySlug(slug) {
        const [watchlist] = await db.select().from(sharedWatchlists).where(eq(sharedWatchlists.shareSlug, slug));
        return watchlist;
      }
      async updateSharedWatchlist(id, data) {
        const [updated] = await db.update(sharedWatchlists).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(sharedWatchlists.id, id)).returning();
        return updated;
      }
      async getPublicWatchlists(limit = 20) {
        return await db.select().from(sharedWatchlists).where(eq(sharedWatchlists.isPublic, true)).orderBy(desc(sharedWatchlists.followersCount)).limit(limit);
      }
      async getUserSharedWatchlists(userId) {
        return await db.select().from(sharedWatchlists).where(eq(sharedWatchlists.ownerId, userId)).orderBy(desc(sharedWatchlists.createdAt));
      }
      // Social features - Watchlist followers
      async followWatchlist(userId, watchlistId) {
        const [follower] = await db.insert(watchlistFollowers).values({ userId, watchlistId }).onConflictDoNothing().returning();
        await db.update(sharedWatchlists).set({
          followersCount: sql2`${sharedWatchlists.followersCount} + 1`
        }).where(eq(sharedWatchlists.id, watchlistId));
        return follower;
      }
      async unfollowWatchlist(userId, watchlistId) {
        await db.delete(watchlistFollowers).where(
          and(
            eq(watchlistFollowers.userId, userId),
            eq(watchlistFollowers.watchlistId, watchlistId)
          )
        );
        await db.update(sharedWatchlists).set({
          followersCount: sql2`GREATEST(0, ${sharedWatchlists.followersCount} - 1)`
        }).where(eq(sharedWatchlists.id, watchlistId));
      }
      async getFollowedWatchlists(userId) {
        const followed = await db.select({
          watchlist: sharedWatchlists
        }).from(watchlistFollowers).innerJoin(sharedWatchlists, eq(watchlistFollowers.watchlistId, sharedWatchlists.id)).where(eq(watchlistFollowers.userId, userId));
        return followed.map((f) => f.watchlist);
      }
      async isFollowingWatchlist(userId, watchlistId) {
        const [result] = await db.select().from(watchlistFollowers).where(
          and(
            eq(watchlistFollowers.userId, userId),
            eq(watchlistFollowers.watchlistId, watchlistId)
          )
        );
        return !!result;
      }
      // Social features - Token reports
      async createTokenReport(report) {
        const [newReport] = await db.insert(tokenReports).values(report).returning();
        return newReport;
      }
      async getTokenReports(tokenAddress) {
        const reports = await db.select({
          id: tokenReports.id,
          tokenAddress: tokenReports.tokenAddress,
          reporterId: tokenReports.reporterId,
          reportType: tokenReports.reportType,
          evidence: tokenReports.evidence,
          status: tokenReports.status,
          reviewerId: tokenReports.reviewerId,
          resolutionNotes: tokenReports.resolutionNotes,
          severityScore: tokenReports.severityScore,
          createdAt: tokenReports.createdAt,
          updatedAt: tokenReports.updatedAt,
          reporter: users
        }).from(tokenReports).leftJoin(users, eq(tokenReports.reporterId, users.id)).where(eq(tokenReports.tokenAddress, tokenAddress)).orderBy(desc(tokenReports.createdAt));
        return reports;
      }
      async updateTokenReport(id, data) {
        const [updated] = await db.update(tokenReports).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(tokenReports.id, id)).returning();
        return updated;
      }
      async getPendingReports() {
        const reports = await db.select({
          id: tokenReports.id,
          tokenAddress: tokenReports.tokenAddress,
          reporterId: tokenReports.reporterId,
          reportType: tokenReports.reportType,
          evidence: tokenReports.evidence,
          status: tokenReports.status,
          reviewerId: tokenReports.reviewerId,
          resolutionNotes: tokenReports.resolutionNotes,
          severityScore: tokenReports.severityScore,
          createdAt: tokenReports.createdAt,
          updatedAt: tokenReports.updatedAt,
          reporter: users
        }).from(tokenReports).leftJoin(users, eq(tokenReports.reporterId, users.id)).where(eq(tokenReports.status, "pending")).orderBy(desc(tokenReports.createdAt));
        return reports;
      }
      // Social features - User activities
      async recordActivity(activity) {
        const [newActivity] = await db.insert(userActivities).values(activity).returning();
        return newActivity;
      }
      async getUserActivities(userId, limit = 50) {
        return await db.select().from(userActivities).where(eq(userActivities.userId, userId)).orderBy(desc(userActivities.createdAt)).limit(limit);
      }
      async calculateUserReputation(userId) {
        const result = await db.select({
          totalPoints: sql2`COALESCE(SUM(${userActivities.points}), 0)`
        }).from(userActivities).where(eq(userActivities.userId, userId));
        return result[0]?.totalPoints || 0;
      }
    };
    storage = new DatabaseStorage();
  }
});

// server/crypto-payments.ts
var crypto_payments_exports = {};
__export(crypto_payments_exports, {
  checkPendingPayments: () => checkPendingPayments,
  checkSolPayment: () => checkSolPayment,
  generatePaymentAddress: () => generatePaymentAddress,
  getPaymentStatus: () => getPaymentStatus
});
import { Connection as Connection4, PublicKey as PublicKey4, LAMPORTS_PER_SOL } from "@solana/web3.js";
import { eq as eq2 } from "drizzle-orm";
async function generatePaymentAddress(userId, chain, tier) {
  const expiresAt = new Date(Date.now() + PAYMENT_EXPIRY_HOURS * 60 * 60 * 1e3);
  if (chain === "SOL" && !process.env.PHANTOM_WALLET_ADDRESS) {
    throw new Error("CRITICAL: PHANTOM_WALLET_ADDRESS environment variable not configured. Crypto payments are disabled until this is set.");
  }
  if (chain !== "SOL") {
    throw new Error(`CRITICAL: Chain ${chain} is not yet supported. Only SOL is currently available. Attempting to use ${chain} will result in lost funds!`);
  }
  const address = process.env.PHANTOM_WALLET_ADDRESS;
  const [cryptoAddress] = await db.insert(cryptoAddresses).values({
    userId,
    chain,
    address,
    tier,
    expiresAt,
    isPaid: false
  }).returning();
  const expectedAmount = PAYMENT_PRICES[tier][chain].toString();
  const [payment] = await db.insert(payments).values({
    userId,
    cryptoAddressId: cryptoAddress.id,
    chain,
    tier,
    amountExpected: expectedAmount,
    status: "pending",
    confirmations: 0
  }).returning();
  return {
    cryptoAddress,
    payment,
    amountToPay: expectedAmount,
    expiresAt
  };
}
async function checkSolPayment(paymentId) {
  try {
    const connection = getSolanaConnection();
    const [payment] = await db.select().from(payments).where(eq2(payments.id, paymentId)).limit(1);
    if (!payment || payment.status === "confirmed") {
      return payment;
    }
    const [cryptoAddress] = await db.select().from(cryptoAddresses).where(eq2(cryptoAddresses.id, payment.cryptoAddressId)).limit(1);
    if (!cryptoAddress) {
      throw new Error("Crypto address not found");
    }
    if (/* @__PURE__ */ new Date() > cryptoAddress.expiresAt) {
      await db.update(payments).set({ status: "expired" }).where(eq2(payments.id, paymentId));
      return null;
    }
    const walletPubkey = new PublicKey4(cryptoAddress.address);
    const signatures = await connection.getSignaturesForAddress(walletPubkey, {
      limit: 50
    });
    for (const signatureInfo of signatures) {
      const tx = await connection.getTransaction(signatureInfo.signature, {
        maxSupportedTransactionVersion: 0
      });
      if (!tx) continue;
      const txTime = tx.blockTime ? tx.blockTime * 1e3 : 0;
      const paymentCreatedTime = new Date(payment.createdAt).getTime();
      if (txTime < paymentCreatedTime) continue;
      const preBalances = tx.meta?.preBalances || [];
      const postBalances = tx.meta?.postBalances || [];
      const accountIndex = tx.transaction.message.staticAccountKeys.findIndex(
        (key) => key.toString() === walletPubkey.toString()
      );
      if (accountIndex === -1) continue;
      const received = (postBalances[accountIndex] - preBalances[accountIndex]) / LAMPORTS_PER_SOL;
      if (received <= 0) continue;
      const expectedAmount = parseFloat(payment.amountExpected);
      const tolerance = expectedAmount * 0.05;
      if (received >= expectedAmount - tolerance) {
        const confirmations = signatureInfo.confirmationStatus === "finalized" ? 32 : 1;
        await db.update(payments).set({
          txHash: signatureInfo.signature,
          amountReceived: received.toString(),
          fromAddress: tx.transaction.message.staticAccountKeys[0].toString(),
          confirmations,
          status: confirmations >= REQUIRED_CONFIRMATIONS ? "confirmed" : "pending",
          confirmedAt: confirmations >= REQUIRED_CONFIRMATIONS ? /* @__PURE__ */ new Date() : void 0
        }).where(eq2(payments.id, paymentId));
        await db.insert(paymentAudit).values({
          paymentId,
          checkType: "blockchain_scan",
          details: {
            signature: signatureInfo.signature,
            received,
            confirmations,
            txTime
          }
        });
        if (confirmations >= REQUIRED_CONFIRMATIONS) {
          await activateSubscription(payment.userId, payment.tier, paymentId);
        }
        const [updatedPayment] = await db.select().from(payments).where(eq2(payments.id, paymentId)).limit(1);
        return updatedPayment;
      }
    }
    return payment;
  } catch (error) {
    console.error("Error checking SOL payment:", error);
    throw error;
  }
}
async function activateSubscription(userId, tier, paymentId) {
  const now = /* @__PURE__ */ new Date();
  const periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1e3);
  const [existing] = await db.select().from(subscriptions).where(eq2(subscriptions.userId, userId)).limit(1);
  if (existing) {
    await db.update(subscriptions).set({
      tier,
      status: "active",
      currentPeriodEnd: periodEnd,
      updatedAt: now
    }).where(eq2(subscriptions.id, existing.id));
  } else {
    await db.insert(subscriptions).values({
      userId,
      tier,
      status: "active",
      currentPeriodEnd: periodEnd
    });
  }
  await db.update(payments).set({ subscriptionActivatedAt: now }).where(eq2(payments.id, paymentId));
  console.log(`\u2705 Subscription activated for user ${userId} - ${tier} tier via crypto payment`);
}
async function checkPendingPayments() {
  try {
    const pendingPayments = await db.select().from(payments).where(eq2(payments.status, "pending"));
    console.log(`Checking ${pendingPayments.length} pending crypto payments...`);
    for (const payment of pendingPayments) {
      if (payment.chain === "SOL") {
        await checkSolPayment(payment.id);
      }
    }
  } catch (error) {
    console.error("Error checking pending payments:", error);
  }
}
async function getPaymentStatus(paymentId) {
  const [payment] = await db.select().from(payments).where(eq2(payments.id, paymentId)).limit(1);
  return payment;
}
var PAYMENT_PRICES, PAYMENT_EXPIRY_HOURS, REQUIRED_CONFIRMATIONS, getSolanaConnection;
var init_crypto_payments = __esm({
  "server/crypto-payments.ts"() {
    "use strict";
    init_db();
    init_schema();
    PAYMENT_PRICES = {
      basic: {
        SOL: 0.1,
        // $20 worth of SOL (adjust based on market price)
        ETH: 0.01,
        // $20 worth of ETH
        BTC: 5e-4
        // $20 worth of BTC
      },
      premium: {
        SOL: 0.5,
        // $100 worth of SOL
        ETH: 0.05,
        // $100 worth of ETH
        BTC: 25e-4
        // $100 worth of BTC
      }
    };
    PAYMENT_EXPIRY_HOURS = 1;
    REQUIRED_CONFIRMATIONS = 6;
    getSolanaConnection = () => {
      const rpcUrl = process.env.HELIUS_API_KEY ? `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}` : "https://api.mainnet-beta.solana.com";
      return new Connection4(rpcUrl, "confirmed");
    };
  }
});

// server/ai-blacklist.ts
var ai_blacklist_exports = {};
__export(ai_blacklist_exports, {
  analyzeAndFlag: () => analyzeAndFlag,
  checkBlacklist: () => checkBlacklist,
  confirmRug: () => confirmRug,
  getBlacklist: () => getBlacklist,
  getBlacklistStats: () => getBlacklistStats,
  getTopFlaggedWallets: () => getTopFlaggedWallets,
  reportWallet: () => reportWallet
});
import { eq as eq3, and as and3, desc as desc2, sql as sql3 } from "drizzle-orm";
async function checkBlacklist(walletAddress) {
  try {
    const labels = await db.select().from(badActorLabels).where(
      and3(
        eq3(badActorLabels.walletAddress, walletAddress),
        eq3(badActorLabels.isActive, true)
      )
    );
    if (labels.length === 0) {
      return {
        isBlacklisted: false,
        severity: 0,
        labels: [],
        warnings: []
      };
    }
    const maxSeverity = Math.max(...labels.map((l) => l.severity));
    const warnings = labels.map((l) => {
      if (l.rugCount > 0) {
        return `\u26A0\uFE0F ${l.labelType}: ${l.rugCount} confirmed rugs`;
      }
      return `\u26A0\uFE0F ${l.labelType}`;
    });
    return {
      isBlacklisted: true,
      severity: maxSeverity,
      labels: labels.map((l) => ({
        type: l.labelType,
        severity: l.severity,
        rugCount: l.rugCount,
        confidence: l.confidence
      })),
      warnings
    };
  } catch (error) {
    console.error("Error checking blacklist:", error);
    return {
      isBlacklisted: false,
      severity: 0,
      labels: [],
      warnings: []
    };
  }
}
async function analyzeAndFlag(analysis, userId) {
  try {
    await db.insert(analysisRuns).values({
      tokenAddress: analysis.tokenAddress,
      userId,
      riskScore: analysis.riskScore,
      riskLevel: analysis.riskLevel,
      analysisData: analysis,
      rugDetected: false,
      // Will be updated manually if confirmed
      userReported: false
    });
    if (analysis.goplusData?.is_scam === "1") {
      await flagWallet(
        analysis.tokenAddress,
        "honeypot_creator",
        90,
        "GoPlus API detected honeypot",
        "rules_engine"
      );
    }
    if (analysis.goplusData?.sell_tax) {
      const sellTax = parseFloat(analysis.goplusData.sell_tax);
      if (sellTax > 0.1) {
        await flagWallet(
          analysis.tokenAddress,
          "scammer",
          80,
          `Excessive sell tax: ${(sellTax * 100).toFixed(1)}%`,
          "rules_engine"
        );
      }
    }
    if (analysis.mintAuthority.hasAuthority && !analysis.mintAuthority.isRevoked && analysis.riskScore <= 30 && analysis.mintAuthority.authorityAddress) {
      await flagWallet(
        analysis.mintAuthority.authorityAddress,
        "rugger_dev",
        75,
        "Active mint authority on high-risk token",
        "rules_engine"
      );
    }
    if (analysis.freezeAuthority.hasAuthority && !analysis.freezeAuthority.isRevoked && analysis.riskScore <= 30 && analysis.freezeAuthority.authorityAddress) {
      await flagWallet(
        analysis.freezeAuthority.authorityAddress,
        "rugger_dev",
        75,
        "Active freeze authority on high-risk token",
        "rules_engine"
      );
    }
    if (analysis.topHolderConcentration > 80) {
      const topHolder = analysis.topHolders[0];
      if (topHolder && topHolder.percentage > 50) {
        await flagWallet(
          topHolder.address,
          "wash_trader",
          70,
          `Controls ${topHolder.percentage.toFixed(1)}% of supply`,
          "rules_engine"
        );
      }
    }
    if (analysis.liquidityPool.status === "RISKY" && analysis.riskScore <= 20 && analysis.dexscreenerData?.pairs?.[0]) {
      const pair = analysis.dexscreenerData.pairs[0];
      if (pair.liquidity && pair.liquidity.usd < 1e3) {
        await flagWallet(
          analysis.tokenAddress,
          "scammer",
          85,
          `Low liquidity ($${pair.liquidity.usd.toFixed(0)}) + high risk score`,
          "rules_engine"
        );
      }
    }
    if (analysis.topHolders && analysis.topHolders.length > 0) {
      const holderAddresses = analysis.topHolders.map((h) => h.address);
      const kolHolders = await storage.getKolWalletsByAddresses(holderAddresses);
      if (kolHolders.length >= 3) {
        const kolNames = kolHolders.map((k) => k.displayName || k.walletAddress.substring(0, 8)).join(", ");
        const totalKolPercentage = kolHolders.reduce((sum, kol) => {
          const holder = analysis.topHolders.find((h) => h.address === kol.walletAddress);
          return sum + (holder?.percentage || 0);
        }, 0);
        await flagWallet(
          analysis.tokenAddress,
          "cabal_token",
          85,
          `${kolHolders.length} influential wallets in top holders (${totalKolPercentage.toFixed(1)}% supply): ${kolNames}`,
          "rules_engine"
        );
        for (const kol of kolHolders) {
          await flagWallet(
            kol.walletAddress,
            "cabal_member",
            65,
            `Participated in coordinated early buying with ${kolHolders.length - 1} other wallets on ${analysis.metadata.symbol}`,
            "rules_engine"
          );
        }
      } else if (kolHolders.length === 2) {
        const kolNames = kolHolders.map((k) => k.displayName || k.walletAddress.substring(0, 8)).join(", ");
        await flagWallet(
          analysis.tokenAddress,
          "possible_cabal",
          60,
          `2 influential wallets in top holders: ${kolNames}`,
          "rules_engine"
        );
      }
    }
    if (analysis.recentTransactions && analysis.recentTransactions.length > 5) {
      const buyTransactions = analysis.recentTransactions.filter((tx) => tx.type === "swap").slice(0, 20);
      if (buyTransactions.length >= 5) {
        const timeGroups = {};
        for (const tx of buyTransactions) {
          const timeKey = Math.floor(tx.timestamp / 5);
          if (!timeGroups[timeKey]) {
            timeGroups[timeKey] = [];
          }
          timeGroups[timeKey].push(tx);
        }
        for (const [timeKey, txGroup] of Object.entries(timeGroups)) {
          if (txGroup.length >= 3) {
            const uniqueWallets = new Set(txGroup.map((tx) => tx.from).filter(Boolean));
            if (uniqueWallets.size >= 3) {
              await flagWallet(
                analysis.tokenAddress,
                "bundled_token",
                75,
                `Bundling detected: ${uniqueWallets.size} wallets bought within 5 seconds`,
                "rules_engine"
              );
              const bundledAddresses = Array.from(uniqueWallets);
              const bundledKols = await storage.getKolWalletsByAddresses(bundledAddresses);
              if (bundledKols.length >= 2) {
                await flagWallet(
                  analysis.tokenAddress,
                  "kol_bundle",
                  90,
                  `Coordinated bundling detected: ${bundledKols.length} influential wallets bought simultaneously`,
                  "rules_engine"
                );
              }
              break;
            }
          }
        }
      }
    }
    if (analysis.topHolders && analysis.topHolders.length > 0) {
      const holderAddresses = analysis.topHolders.slice(0, 10).map((h) => h.address);
      const topKols = await storage.getKolWalletsByAddresses(holderAddresses);
      const highInfluenceKols = topKols.filter((k) => (k.influenceScore || 0) > 70);
      if (highInfluenceKols.length > 0) {
        const kolNames = highInfluenceKols.map((k) => k.displayName || k.walletAddress.substring(0, 8)).join(", ");
        await flagWallet(
          analysis.tokenAddress,
          "kol_promoted",
          45,
          // Lower severity - not necessarily bad
          `High-influence wallet participation: ${kolNames}`,
          "rules_engine"
        );
      }
    }
  } catch (error) {
    console.error("Error in analyzeAndFlag:", error);
  }
}
async function flagWallet(walletAddress, labelType, severity, evidence, detectionMethod) {
  try {
    const [existing] = await db.select().from(badActorLabels).where(
      and3(
        eq3(badActorLabels.walletAddress, walletAddress),
        eq3(badActorLabels.labelType, labelType)
      )
    ).limit(1);
    if (existing) {
      const existingEvidence = existing.evidenceData || {};
      const timestamp2 = (/* @__PURE__ */ new Date()).toISOString();
      const evidenceExists = Object.values(existingEvidence).includes(evidence);
      if (!evidenceExists && (severity > existing.severity || Object.keys(existingEvidence).length < 10)) {
        const shouldIncrementRugCount = severity > 80 && severity > existing.severity;
        await db.update(badActorLabels).set({
          severity: Math.max(severity, existing.severity),
          // Take higher severity
          rugCount: shouldIncrementRugCount ? existing.rugCount + 1 : existing.rugCount,
          evidenceData: {
            ...existingEvidence,
            [timestamp2]: evidence
          },
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq3(badActorLabels.id, existing.id));
      }
    } else {
      await db.insert(badActorLabels).values({
        walletAddress,
        labelType,
        severity,
        rugCount: 0,
        evidenceData: {
          [(/* @__PURE__ */ new Date()).toISOString()]: evidence
        },
        detectionMethod,
        confidence: 80,
        isActive: true
      });
    }
  } catch (error) {
    if (error.code !== "23505") {
      console.error("Error flagging wallet:", error);
    }
  }
}
async function reportWallet(walletAddress, reportType, evidence, reportedBy) {
  try {
    await flagWallet(
      walletAddress,
      reportType,
      60,
      `User report: ${evidence}`,
      "manual_report"
    );
  } catch (error) {
    console.error("Error reporting wallet:", error);
    throw error;
  }
}
async function getBlacklist() {
  try {
    const wallets = await db.select().from(badActorLabels).where(eq3(badActorLabels.isActive, true));
    return wallets;
  } catch (error) {
    console.error("Error getting blacklist:", error);
    return [];
  }
}
async function getBlacklistStats() {
  try {
    const [stats] = await db.select({
      total: sql3`count(*)`,
      active: sql3`count(*) filter (where ${badActorLabels.isActive} = true)`,
      ruggers: sql3`count(*) filter (where ${badActorLabels.labelType} = 'rugger_dev')`,
      scammers: sql3`count(*) filter (where ${badActorLabels.labelType} = 'scammer')`,
      honeypots: sql3`count(*) filter (where ${badActorLabels.labelType} = 'honeypot_creator')`,
      avgSeverity: sql3`avg(${badActorLabels.severity})`
    }).from(badActorLabels);
    return stats;
  } catch (error) {
    console.error("Error getting blacklist stats:", error);
    return {
      total: 0,
      active: 0,
      ruggers: 0,
      scammers: 0,
      honeypots: 0,
      avgSeverity: 0
    };
  }
}
async function getTopFlaggedWallets(limit = 100) {
  try {
    const wallets = await db.select().from(badActorLabels).where(eq3(badActorLabels.isActive, true)).orderBy(desc2(badActorLabels.severity), desc2(badActorLabels.rugCount)).limit(limit);
    return wallets;
  } catch (error) {
    console.error("Error getting top flagged wallets:", error);
    return [];
  }
}
async function confirmRug(tokenAddress, reviewedBy, victimCount, totalLosses) {
  try {
    await db.update(analysisRuns).set({ rugDetected: true }).where(eq3(analysisRuns.tokenAddress, tokenAddress));
    const analysis = await db.select().from(analysisRuns).where(eq3(analysisRuns.tokenAddress, tokenAddress)).limit(1);
    if (analysis.length > 0) {
      const analysisData = analysis[0].analysisData;
      if (analysisData.mintAuthority.authorityAddress) {
        const [label] = await db.select().from(badActorLabels).where(eq3(badActorLabels.walletAddress, analysisData.mintAuthority.authorityAddress)).limit(1);
        if (label) {
          await db.update(badActorLabels).set({
            labelType: "serial_rugger",
            severity: Math.min(100, label.severity + 10),
            rugCount: label.rugCount + 1,
            totalVictims: victimCount,
            totalLosses,
            reviewedBy,
            reviewedAt: /* @__PURE__ */ new Date()
          }).where(eq3(badActorLabels.id, label.id));
        }
      }
    }
    console.log(`\u2705 Confirmed rug for token ${tokenAddress}`);
  } catch (error) {
    console.error("Error confirming rug:", error);
    throw error;
  }
}
var init_ai_blacklist = __esm({
  "server/ai-blacklist.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_storage();
  }
});

// server/services/price-cache.ts
var price_cache_exports = {};
__export(price_cache_exports, {
  PriceCache: () => PriceCache,
  priceCache: () => priceCache
});
var PriceCache, priceCache;
var init_price_cache = __esm({
  "server/services/price-cache.ts"() {
    "use strict";
    PriceCache = class {
      cache = /* @__PURE__ */ new Map();
      ttlMs;
      maxSize;
      constructor(options = {}) {
        this.ttlMs = options.ttlMs || 2e4;
        this.maxSize = options.maxSize || 1e3;
      }
      /**
       * Get cached price for a token
       * Returns null if not cached or expired
       */
      get(tokenAddress) {
        const cached = this.cache.get(tokenAddress);
        if (!cached) {
          return null;
        }
        if (Date.now() - cached.lastUpdated > this.ttlMs) {
          this.cache.delete(tokenAddress);
          return null;
        }
        return cached;
      }
      /**
       * Get multiple prices at once
       */
      getMultiple(tokenAddresses) {
        const results = /* @__PURE__ */ new Map();
        for (const address of tokenAddresses) {
          const cached = this.get(address);
          if (cached) {
            results.set(address, cached);
          }
        }
        return results;
      }
      /**
       * Set price for a token
       */
      set(tokenAddress, price) {
        if (this.cache.size >= this.maxSize && !this.cache.has(tokenAddress)) {
          const firstKey = this.cache.keys().next().value;
          if (firstKey) {
            this.cache.delete(firstKey);
          }
        }
        this.cache.set(tokenAddress, {
          ...price,
          lastUpdated: Date.now()
        });
      }
      /**
       * Set multiple prices at once
       */
      setMultiple(prices) {
        for (const price of prices) {
          this.set(price.tokenAddress, price);
        }
      }
      /**
       * Check if price is cached and fresh
       */
      has(tokenAddress) {
        return this.get(tokenAddress) !== null;
      }
      /**
       * Clear cache for specific token
       */
      delete(tokenAddress) {
        this.cache.delete(tokenAddress);
      }
      /**
       * Clear entire cache
       */
      clear() {
        this.cache.clear();
      }
      /**
       * Get all token addresses in the cache
       * Returns array of token addresses (does not filter by expiry)
       */
      getAllTokens() {
        return Array.from(this.cache.keys());
      }
      /**
       * Get recently updated token addresses
       * @param minutes - Number of minutes to look back
       * @returns Array of token addresses updated within the last N minutes
       */
      getRecentlyUpdated(minutes) {
        const now = Date.now();
        const cutoffTime = now - minutes * 60 * 1e3;
        const recentTokens = [];
        for (const [address, entry] of Array.from(this.cache.entries())) {
          if (entry.lastUpdated >= cutoffTime) {
            recentTokens.push(address);
          }
        }
        return recentTokens;
      }
      /**
       * Get cache statistics
       */
      getStats() {
        const now = Date.now();
        let freshEntries = 0;
        let staleEntries = 0;
        for (const entry of Array.from(this.cache.values())) {
          if (now - entry.lastUpdated > this.ttlMs) {
            staleEntries++;
          } else {
            freshEntries++;
          }
        }
        return {
          totalEntries: this.cache.size,
          freshEntries,
          staleEntries,
          maxSize: this.maxSize,
          ttlMs: this.ttlMs
        };
      }
      /**
       * Cleanup stale entries
       */
      cleanup() {
        const now = Date.now();
        let removed = 0;
        for (const [address, entry] of Array.from(this.cache.entries())) {
          if (now - entry.lastUpdated > this.ttlMs) {
            this.cache.delete(address);
            removed++;
          }
        }
        return removed;
      }
    };
    priceCache = new PriceCache({
      ttlMs: 2e4,
      // 20 seconds
      maxSize: 2e3
      // Support 2000 tokens
    });
  }
});

// server/services/price-service.ts
var price_service_exports = {};
__export(price_service_exports, {
  PriceService: () => PriceService,
  priceService: () => priceService
});
import axios3 from "axios";
var PriceService, priceService;
var init_price_service = __esm({
  "server/services/price-service.ts"() {
    "use strict";
    init_price_cache();
    PriceService = class {
      /**
       * Get price for a single token (uses cache if available)
       */
      async getPrice(tokenAddress, options = {}) {
        const { useCache = true } = options;
        if (useCache) {
          const cached = priceCache.get(tokenAddress);
          if (cached) {
            return cached;
          }
        }
        const price = await this.fetchPrice(tokenAddress);
        if (price) {
          priceCache.set(tokenAddress, price);
          return priceCache.get(tokenAddress);
        }
        return null;
      }
      /**
       * Get prices for multiple tokens (batch operation with cache)
       */
      async getPrices(tokenAddresses, options = {}) {
        const { useCache = true } = options;
        const results = /* @__PURE__ */ new Map();
        const toFetch = [];
        if (useCache) {
          const cached = priceCache.getMultiple(tokenAddresses);
          for (const [address, price] of Array.from(cached.entries())) {
            results.set(address, price);
          }
        }
        for (const address of tokenAddresses) {
          if (!results.has(address)) {
            toFetch.push(address);
          }
        }
        if (toFetch.length > 0) {
          const promises = toFetch.map((address) => this.fetchPrice(address));
          const fetched = await Promise.allSettled(promises);
          fetched.forEach((result, index2) => {
            if (result.status === "fulfilled" && result.value) {
              const address = toFetch[index2];
              priceCache.set(address, result.value);
              const cached = priceCache.get(address);
              if (cached) {
                results.set(address, cached);
              }
            }
          });
        }
        return results;
      }
      /**
       * Fetch price from external APIs (DexScreener primary, Jupiter fallback)
       */
      async fetchPrice(tokenAddress) {
        try {
          const dexPrice = await this.fetchFromDexScreener(tokenAddress);
          if (dexPrice) {
            return dexPrice;
          }
          return null;
        } catch (error) {
          console.error(`[PriceService] Error fetching price for ${tokenAddress}:`, error);
          return null;
        }
      }
      /**
       * Fetch price from DexScreener API
       */
      async fetchFromDexScreener(tokenAddress) {
        try {
          const response = await axios3.get(`https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`, {
            timeout: 5e3
          });
          if (response.data?.pairs && response.data.pairs.length > 0) {
            const sortedPairs = response.data.pairs.sort(
              (a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0)
            );
            const pair = sortedPairs[0];
            return {
              tokenAddress,
              priceUsd: parseFloat(pair.priceUsd || "0"),
              priceNative: parseFloat(pair.priceNative || "0"),
              marketCap: pair.marketCap || null,
              liquidity: pair.liquidity?.usd || null,
              volume24h: pair.volume?.h24 || null,
              priceChange24h: pair.priceChange?.h24 || null
            };
          }
          return null;
        } catch (error) {
          console.error(`[DexScreener] Error for ${tokenAddress}:`, error);
          return null;
        }
      }
      /**
       * Refresh prices for multiple tokens (background job use)
       */
      async refreshPrices(tokenAddresses) {
        console.log(`[PriceService] Refreshing prices for ${tokenAddresses.length} tokens`);
        await this.getPrices(tokenAddresses, { useCache: false });
      }
    };
    priceService = new PriceService();
  }
});

// server/services/social-service.ts
var social_service_exports = {};
__export(social_service_exports, {
  SocialService: () => SocialService,
  socialService: () => socialService
});
import { nanoid } from "nanoid";
var SocialService, socialService;
var init_social_service = __esm({
  "server/services/social-service.ts"() {
    "use strict";
    init_storage();
    SocialService = class {
      async calculateReputation(userId) {
        return await storage.calculateUserReputation(userId);
      }
      async aggregateVotes(tokenAddress) {
        const votes = await storage.getCommunityVoteSummary(tokenAddress);
        if (!votes) {
          return;
        }
        const safeWeight = parseFloat(votes.safeWeight?.toString() || "0");
        const riskyWeight = parseFloat(votes.riskyWeight?.toString() || "0");
        const scamWeight = parseFloat(votes.scamWeight?.toString() || "0");
        const totalWeight = safeWeight + riskyWeight + scamWeight;
        if (totalWeight === 0) {
          return;
        }
        const safePercent = safeWeight / totalWeight * 100;
        const riskyPercent = riskyWeight / totalWeight * 100;
        const scamPercent = scamWeight / totalWeight * 100;
        let consensus = "mixed";
        if (safePercent >= 60) {
          consensus = "safe";
        } else if (scamPercent >= 40) {
          consensus = "scam";
        } else if (riskyPercent >= 50) {
          consensus = "risky";
        }
        await storage.upsertVoteSummary({
          tokenAddress,
          safeWeight: safeWeight.toString(),
          riskyWeight: riskyWeight.toString(),
          scamWeight: scamWeight.toString(),
          totalVotes: votes.totalVotes,
          consensus
        });
      }
      generateShareSlug() {
        return nanoid(10);
      }
      sanitizeContent(text2) {
        return text2.replace(/<script[^>]*>.*?<\/script>/gi, "").replace(/<iframe[^>]*>.*?<\/iframe>/gi, "").replace(/<object[^>]*>.*?<\/object>/gi, "").replace(/<embed[^>]*>/gi, "").replace(/on\w+="[^"]*"/gi, "").replace(/on\w+='[^']*'/gi, "").trim();
      }
      async checkRateLimit(userId, action) {
        const limits = {
          comment: { window: 60 * 60 * 1e3, max: 5 },
          vote: { window: 60 * 1e3, max: 10 },
          report: { window: 60 * 60 * 1e3, max: 3 }
        };
        const limit = limits[action];
        const activities = await storage.getUserActivities(userId, 100);
        const cutoffTime = Date.now() - limit.window;
        const recentActions = activities.filter(
          (a) => a.activityType === action && a.createdAt && new Date(a.createdAt).getTime() > cutoffTime
        );
        const count = recentActions.length;
        const remaining = Math.max(0, limit.max - count);
        return {
          allowed: count < limit.max,
          remaining
        };
      }
      async detectSpam(text2) {
        const spamPatterns = [
          /https?:\/\/[^\s]+/gi,
          /\b(buy|sell|pump|moon|100x|guaranteed)\b/gi,
          /(.)\1{5,}/,
          /\b(telegram|discord)\.(?:com|gg|me)\//gi
        ];
        for (const pattern of spamPatterns) {
          if (pattern.test(text2)) {
            return true;
          }
        }
        return false;
      }
      async awardPoints(userId, activityType, points, targetToken, targetWatchlist) {
        await storage.recordActivity({
          userId,
          activityType,
          points,
          targetToken,
          targetWatchlist
        });
        const totalReputation = await storage.calculateUserReputation(userId);
        const profile = await storage.getUserProfile(userId);
        if (profile) {
          await storage.updateUserProfile(userId, {
            reputationScore: totalReputation,
            contributionCount: profile.contributionCount + 1
          });
        }
      }
    };
    socialService = new SocialService();
  }
});

// server/creator-wallet.ts
var creator_wallet_exports = {};
__export(creator_wallet_exports, {
  CreatorWalletService: () => CreatorWalletService,
  getCreatorWallet: () => getCreatorWallet
});
import { Keypair as Keypair2, Connection as Connection5, LAMPORTS_PER_SOL as LAMPORTS_PER_SOL2 } from "@solana/web3.js";
import bs582 from "bs58";
var SOLANA_RPC_URL, CreatorWalletService, getCreatorWallet;
var init_creator_wallet = __esm({
  "server/creator-wallet.ts"() {
    "use strict";
    SOLANA_RPC_URL = process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com";
    CreatorWalletService = class _CreatorWalletService {
      static instance;
      connection;
      keypair = null;
      constructor() {
        this.connection = new Connection5(SOLANA_RPC_URL, "confirmed");
        this.loadKeypair();
      }
      static getInstance() {
        if (!_CreatorWalletService.instance) {
          _CreatorWalletService.instance = new _CreatorWalletService();
        }
        return _CreatorWalletService.instance;
      }
      loadKeypair() {
        const privateKey = process.env.CREATOR_WALLET_PRIVATE_KEY;
        if (privateKey && privateKey !== "PLACEHOLDER") {
          try {
            this.keypair = Keypair2.fromSecretKey(bs582.decode(privateKey));
          } catch (error) {
            console.error("[CREATOR WALLET] Failed to load keypair:", error);
          }
        }
      }
      isConfigured() {
        return this.keypair !== null;
      }
      getPublicKey() {
        return this.keypair?.publicKey.toBase58() || null;
      }
      getPrivateKey() {
        if (!this.keypair) return null;
        return bs582.encode(this.keypair.secretKey);
      }
      async getBalance() {
        if (!this.keypair) {
          throw new Error("Creator wallet not configured");
        }
        const balance = await this.connection.getBalance(this.keypair.publicKey);
        return balance / LAMPORTS_PER_SOL2;
      }
      async getBalanceInLamports() {
        if (!this.keypair) {
          throw new Error("Creator wallet not configured");
        }
        return await this.connection.getBalance(this.keypair.publicKey);
      }
      getKeypair() {
        if (!this.keypair) {
          throw new Error("Creator wallet not configured");
        }
        return this.keypair;
      }
      async getWalletInfo() {
        if (!this.keypair) {
          return {
            publicKey: "",
            balance: 0,
            balanceLamports: 0,
            isConfigured: false
          };
        }
        const balanceLamports = await this.getBalanceInLamports();
        return {
          publicKey: this.keypair.publicKey.toBase58(),
          balance: balanceLamports / LAMPORTS_PER_SOL2,
          balanceLamports,
          isConfigured: true
        };
      }
      static generateNewWallet() {
        const keypair = Keypair2.generate();
        return {
          publicKey: keypair.publicKey.toBase58(),
          privateKey: bs582.encode(keypair.secretKey)
        };
      }
    };
    getCreatorWallet = () => CreatorWalletService.getInstance();
  }
});

// server/telegram-bot.ts
var telegram_bot_exports = {};
__export(telegram_bot_exports, {
  getTelegramBot: () => getTelegramBot,
  startTelegramBot: () => startTelegramBot
});
import { Telegraf } from "telegraf";
import { message } from "telegraf/filters";
function formatAddress(address) {
  return `${address.slice(0, 4)}...${address.slice(-4)}`;
}
function formatNumber(num) {
  if (num >= 1e9) {
    return (num / 1e9).toFixed(2) + "B";
  } else if (num >= 1e6) {
    return (num / 1e6).toFixed(2) + "M";
  } else if (num >= 1e3) {
    return (num / 1e3).toFixed(2) + "K";
  }
  return num.toFixed(2);
}
function getRiskEmoji(riskLevel) {
  switch (riskLevel) {
    case "LOW":
      return "\u2705";
    case "MODERATE":
      return "\u26A0\uFE0F";
    case "HIGH":
      return "\u{1F6A8}";
    case "EXTREME":
      return "\u274C";
    default:
      return "\u2753";
  }
}
function formatAnalysis(analysis, compact = false) {
  const emoji = getRiskEmoji(analysis.riskLevel);
  if (compact) {
    return `${emoji} **${analysis.metadata.name} (${analysis.metadata.symbol})**
    
\u{1F3AF} Risk Score: **${analysis.riskScore}/100** (${analysis.riskLevel})
\u{1F4CA} Holders: ${analysis.holderCount}
\u{1F4A7} Top 10 Concentration: ${analysis.topHolderConcentration.toFixed(2)}%

Use /execute ${analysis.tokenAddress.slice(0, 8)}... for full analysis`;
  }
  let message2 = `\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
`;
  message2 += `${emoji} **${analysis.metadata.name} (${analysis.metadata.symbol})**
`;
  message2 += `\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501

`;
  message2 += `\u{1F4CB} **Token Address**
\`${analysis.tokenAddress}\`

`;
  if (analysis.aiVerdict) {
    message2 += `\u{1F916} **AI VERDICT**
`;
    message2 += `${analysis.aiVerdict.rating} - ${analysis.aiVerdict.verdict}

`;
  }
  message2 += `\u{1F6E1}\uFE0F **RISK SCORE**
`;
  message2 += `Score: **${analysis.riskScore}/100** (${analysis.riskLevel})
`;
  message2 += `_Higher = Safer (0=Dangerous, 100=Safe)_

`;
  if (analysis.marketData || analysis.dexscreenerData?.pairs?.[0]) {
    const pair = analysis.dexscreenerData?.pairs?.[0];
    message2 += `\u{1F4B0} **PRICE**
`;
    if (pair) {
      message2 += `\u2022 Price: $${parseFloat(pair.priceUsd).toFixed(8)}
`;
      message2 += `\u2022 24h Vol: $${formatNumber(pair.volume.h24)}
`;
      message2 += `\u2022 24h Change: ${pair.priceChange.h24 >= 0 ? "\u{1F4C8}" : "\u{1F4C9}"} ${pair.priceChange.h24.toFixed(2)}%
`;
      message2 += `\u2022 MCap: $${formatNumber(pair.marketCap || 0)}
`;
    }
    message2 += `
`;
  }
  message2 += `\u{1F510} **SECURITY**
`;
  message2 += `\u2022 Mint: ${analysis.mintAuthority.hasAuthority ? "\u274C Active" : "\u2705 Revoked"}
`;
  message2 += `\u2022 Freeze: ${analysis.freezeAuthority.hasAuthority ? "\u274C Active" : "\u2705 Revoked"}
`;
  if (analysis.liquidityPool.burnPercentage !== void 0) {
    const burnPct = analysis.liquidityPool.burnPercentage;
    let burnEmoji = burnPct >= 99.99 ? "\u2705" : burnPct >= 50 ? "\u26A0\uFE0F" : "\u274C";
    message2 += `\u2022 LP Burn: ${burnEmoji} ${burnPct.toFixed(1)}%
`;
  }
  message2 += `
`;
  if (analysis.pumpFunData?.isPumpFun) {
    message2 += `\u{1F3AF} **PUMP.FUN**
`;
    message2 += `\u2022 Dev Bought: ${analysis.pumpFunData.devBought.toFixed(2)}%
`;
    message2 += `\u2022 Bonding Curve: ${analysis.pumpFunData.bondingCurve.toFixed(2)}%

`;
  }
  message2 += `\u{1F45B} **HOLDERS**
`;
  message2 += `\u2022 Total: ${analysis.holderCount}
`;
  message2 += `\u2022 Top 10: ${analysis.topHolderConcentration.toFixed(2)}%
`;
  message2 += `\u2022 Supply: ${formatNumber(analysis.metadata.supply)}

`;
  if (analysis.redFlags.length > 0) {
    const criticalFlags = analysis.redFlags.filter((f) => f.severity === "critical" || f.severity === "high");
    if (criticalFlags.length > 0) {
      message2 += `\u26A0\uFE0F **ALERTS**
`;
      criticalFlags.slice(0, 3).forEach((flag) => {
        message2 += `${flag.severity === "critical" ? "\u{1F534}" : "\u{1F7E0}"} ${flag.title}
`;
      });
      message2 += `
`;
    }
  }
  message2 += `\u{1F517} **QUICK LINKS**
`;
  message2 += `\u2022 [Solscan](https://solscan.io/token/${analysis.tokenAddress})
`;
  message2 += `\u2022 [DexScreener](https://dexscreener.com/solana/${analysis.tokenAddress})
`;
  message2 += `\u2022 [Rugcheck](https://rugcheck.xyz/tokens/${analysis.tokenAddress})
`;
  message2 += `\u2022 [AXiom](https://axiom.trade)
`;
  message2 += `\u2022 [Padre Bot](https://t.me/padre_tg_bot?start=${analysis.tokenAddress})
`;
  message2 += `\u2022 [GMGN](https://gmgn.ai/sol/token/${analysis.tokenAddress})
`;
  message2 += `\u2022 [Birdeye](https://birdeye.so/token/${analysis.tokenAddress}?chain=solana)
`;
  return message2;
}
function createTelegramBot(botToken) {
  const bot = new Telegraf(botToken);
  bot.telegram.setMyCommands([
    { command: "start", description: "Show available commands" },
    { command: "execute", description: "Full 52-metric scan - /execute <address>" },
    { command: "first20", description: "Top 20 holder analysis - /first20 <address>" },
    { command: "devtorture", description: "Dev wallet history - /devtorture <address>" },
    { command: "blacklist", description: "Check wallet blacklist - /blacklist <wallet>" },
    { command: "whaletrack", description: "Smart money in token - /whaletrack <address>" },
    { command: "kol", description: "Check if wallet is KOL - /kol <wallet>" }
  ]).catch((err) => {
    console.error("Failed to set Telegram bot commands:", err);
  });
  bot.command("start", async (ctx) => {
    await ctx.reply(
      "\u{1F525} **SOLANA RUG KILLER**\n\n**Core Commands:**\n/execute <address> - Full 52-metric scan\n/first20 <address> - Top 20 holder analysis\n/devtorture <address> - Dev wallet history\n/blacklist <wallet> - Check if wallet is flagged\n\n**Whale Tier Commands:**\n/whaletrack <address> - Smart money tracking\n/kol <wallet> - Check if wallet is KOL\n\nSend any token address for quick analysis!",
      { parse_mode: "Markdown" }
    );
  });
  bot.command("execute", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a token address.\n\nExample: `/execute EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`", { parse_mode: "Markdown" });
    }
    const tokenAddress = args[1];
    try {
      await ctx.reply("\u{1F50D} Analyzing token... This may take a few seconds.");
      const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
      const message2 = formatAnalysis(analysis);
      await ctx.reply(message2, { parse_mode: "Markdown", link_preview_options: { is_disabled: true } });
    } catch (error) {
      console.error("Telegram bot execute error:", error);
      ctx.reply("\u274C Error analyzing token. Please check the address and try again.");
    }
  });
  bot.command("first20", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a token address.\n\nExample: `/first20 EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`", { parse_mode: "Markdown" });
    }
    const tokenAddress = args[1];
    try {
      await ctx.reply("\u{1F50D} Fetching holder data...");
      const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
      let message2 = `\u{1F4CA} **TOP 20 HOLDERS - ${analysis.metadata.symbol}**

`;
      message2 += `Total Top 10 Concentration: **${analysis.topHolderConcentration.toFixed(2)}%**

`;
      analysis.topHolders.slice(0, 20).forEach((holder, index2) => {
        message2 += `${index2 + 1}. \`${formatAddress(holder.address)}\` - ${holder.percentage.toFixed(2)}%
`;
      });
      if (analysis.topHolderConcentration > 50) {
        message2 += `
\u26A0\uFE0F WARNING: High holder concentration detected!`;
      }
      await ctx.reply(message2, { parse_mode: "Markdown" });
    } catch (error) {
      console.error("Telegram bot first20 error:", error);
      ctx.reply("\u274C Error fetching holder data. Please check the address and try again.");
    }
  });
  bot.command("devtorture", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a token address.\n\nExample: `/devtorture EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`", { parse_mode: "Markdown" });
    }
    const tokenAddress = args[1];
    try {
      await ctx.reply("\u{1F525} Torturing dev wallet...");
      const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
      let message2 = `\u{1F525} **DEV TORTURE REPORT - ${analysis.metadata.symbol}**

`;
      message2 += `Contract: \`${formatAddress(tokenAddress)}\`

`;
      if (analysis.mintAuthority.hasAuthority && !analysis.mintAuthority.isRevoked) {
        message2 += `\u274C **MINT AUTHORITY ACTIVE**
`;
        message2 += `Dev can mint unlimited tokens!
`;
        if (analysis.mintAuthority.authorityAddress) {
          message2 += `Authority: \`${formatAddress(analysis.mintAuthority.authorityAddress)}\`

`;
        }
      }
      if (analysis.freezeAuthority.hasAuthority && !analysis.freezeAuthority.isRevoked) {
        message2 += `\u274C **FREEZE AUTHORITY ACTIVE**
`;
        message2 += `Dev can freeze accounts!
`;
        if (analysis.freezeAuthority.authorityAddress) {
          message2 += `Authority: \`${formatAddress(analysis.freezeAuthority.authorityAddress)}\`

`;
        }
      }
      if (analysis.creationDate) {
        const age = Math.floor((Date.now() - analysis.creationDate) / (1e3 * 60 * 60 * 24));
        message2 += `\u{1F4C5} **AGE**: ${age} days
`;
        if (age < 7) {
          message2 += `\u26A0\uFE0F Very new token - high risk!
`;
        }
        message2 += `
`;
      }
      await ctx.reply(message2, { parse_mode: "Markdown" });
    } catch (error) {
      console.error("Telegram bot devtorture error:", error);
      ctx.reply("\u274C Error analyzing dev wallet. Please check the address and try again.");
    }
  });
  bot.command("blacklist", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a wallet address.\n\nExample: `/blacklist AbCd1234...`", { parse_mode: "Markdown" });
    }
    const walletAddress = args[1];
    try {
      await ctx.reply(
        `\u{1F50D} **BLACKLIST CHECK**

Wallet: \`${formatAddress(walletAddress)}\`

\u2705 Not currently flagged`,
        { parse_mode: "Markdown" }
      );
    } catch (error) {
      console.error("Telegram bot blacklist error:", error);
      ctx.reply("\u274C Error checking blacklist.");
    }
  });
  bot.command("whaletrack", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a token address.\n\nExample: `/whaletrack EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`", { parse_mode: "Markdown" });
    }
    const tokenAddress = args[1];
    try {
      await ctx.reply("\u{1F40B} Tracking smart money wallets...");
      const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
      const holderAddresses = analysis.topHolders.map((h) => h.address);
      const kolHolders = await storage.getKolWalletsByAddresses(holderAddresses);
      let message2 = `\u{1F40B} **WHALE TRACKING - ${analysis.metadata.symbol}**

`;
      if (kolHolders.length === 0) {
        message2 += `\u2705 No known smart money wallets detected in top holders

`;
        message2 += `This could be a good sign - no influential traders have entered yet, or it could mean the token hasn't attracted attention from experienced traders.`;
      } else {
        message2 += `\u26A0\uFE0F **${kolHolders.length} Smart Money Wallet${kolHolders.length > 1 ? "s" : ""} Detected**

`;
        for (const kol of kolHolders.slice(0, 10)) {
          const holder = analysis.topHolders.find((h) => h.address === kol.walletAddress);
          const percentage = holder ? holder.percentage.toFixed(2) : "N/A";
          message2 += `\u{1F48E} **${kol.displayName || "Unknown KOL"}**
`;
          message2 += `Wallet: \`${formatAddress(kol.walletAddress)}\`
`;
          message2 += `Holdings: ${percentage}% of supply
`;
          message2 += `Influence: ${kol.influenceScore !== null ? kol.influenceScore.toString() : "N/A"}/100
`;
          if (kol.profitSol) {
            message2 += `Profit: ${formatNumber(Number(kol.profitSol) || 0)} SOL
`;
          }
          message2 += `
`;
        }
        const totalKolPercentage = kolHolders.reduce((sum, kol) => {
          const holder = analysis.topHolders.find((h) => h.address === kol.walletAddress);
          return sum + (holder?.percentage || 0);
        }, 0);
        message2 += `\u{1F4CA} **Total Smart Money Holdings: ${totalKolPercentage.toFixed(2)}%**

`;
        if (totalKolPercentage > 30) {
          message2 += `\u{1F6A8} HIGH concentration - Smart money controls significant supply!`;
        } else if (totalKolPercentage > 15) {
          message2 += `\u26A0\uFE0F MODERATE concentration - Watch for coordinated sells`;
        } else {
          message2 += `\u2705 LOW concentration - Smart money has small positions`;
        }
      }
      await ctx.reply(message2, { parse_mode: "Markdown" });
    } catch (error) {
      console.error("Telegram bot whaletrack error:", error);
      ctx.reply("\u274C Error tracking smart money. Please check the address and try again.");
    }
  });
  bot.command("kol", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("\u274C Please provide a wallet address.\n\nExample: `/kol AbCd1234...`", { parse_mode: "Markdown" });
    }
    const walletAddress = args[1];
    try {
      await ctx.reply("\u{1F50D} Checking KOL database...");
      const kol = await storage.getKolWallet(walletAddress);
      if (!kol) {
        await ctx.reply(
          `\u{1F4CA} **KOL CHECK**

Wallet: \`${formatAddress(walletAddress)}\`

\u274C Not found in KOL database

This wallet is not currently tracked as a known influential trader.`,
          { parse_mode: "Markdown" }
        );
        return;
      }
      let message2 = `\u{1F48E} **KOL PROFILE FOUND**

`;
      message2 += `\u{1F464} **${kol.displayName || "Unknown"}**
`;
      message2 += `Wallet: \`${formatAddress(kol.walletAddress)}\`

`;
      message2 += `\u{1F4CA} **Stats:**
`;
      message2 += `\u2022 Rank: #${kol.rank !== null ? kol.rank.toString() : "N/A"}
`;
      message2 += `\u2022 Influence Score: ${kol.influenceScore !== null ? kol.influenceScore.toString() : "N/A"}/100
`;
      if (kol.profitSol !== null) {
        message2 += `\u2022 Total Profit: ${formatNumber(Number(kol.profitSol) || 0)} SOL
`;
      }
      if (kol.wins !== null && kol.losses !== null) {
        const total = kol.wins + kol.losses;
        const winRate = total > 0 ? (kol.wins / total * 100).toFixed(1) : "N/A";
        message2 += `\u2022 Wins: ${kol.wins} | Losses: ${kol.losses}
`;
        message2 += `\u2022 Win Rate: ${winRate}%
`;
      }
      if (kol.lastActiveAt) {
        const lastActive = new Date(kol.lastActiveAt);
        message2 += `\u2022 Last Active: ${lastActive.toLocaleDateString()}
`;
      }
      message2 += `
`;
      if (kol.influenceScore && kol.influenceScore > 80) {
        message2 += `\u{1F525} **HIGHLY INFLUENTIAL** - Top tier trader`;
      } else if (kol.influenceScore && kol.influenceScore > 60) {
        message2 += `\u2B50 **INFLUENTIAL** - Experienced trader`;
      } else {
        message2 += `\u{1F4C8} **TRACKED** - Known trader`;
      }
      await ctx.reply(message2, { parse_mode: "Markdown" });
    } catch (error) {
      console.error("Telegram bot kol error:", error);
      ctx.reply("\u274C Error checking KOL database.");
    }
  });
  bot.on(message("text"), async (ctx) => {
    const text2 = ctx.message.text.trim();
    if (text2.length >= 32 && text2.length <= 44 && !/\s/.test(text2)) {
      try {
        await ctx.reply("\u{1F50D} Quick analysis...");
        const analysis = await tokenAnalyzer.analyzeToken(text2);
        const message2 = formatAnalysis(analysis, true);
        await ctx.reply(message2, { parse_mode: "Markdown", link_preview_options: { is_disabled: true } });
      } catch (error) {
      }
    }
  });
  bot.catch((err, ctx) => {
    console.error(`Telegram bot error for ${ctx.updateType}`, err);
    ctx.reply("\u274C An error occurred. Please try again later.");
  });
  return bot;
}
async function startTelegramBot() {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  if (!BOT_TOKEN || BOT_TOKEN === "PLACEHOLDER_TOKEN") {
    console.log("\u26A0\uFE0F  Telegram bot token not configured. Set TELEGRAM_BOT_TOKEN to enable bot.");
    return;
  }
  if (botInstance) {
    console.log("\u26A0\uFE0F  Telegram bot already running");
    return;
  }
  try {
    botInstance = createTelegramBot(BOT_TOKEN);
    await botInstance.launch({
      dropPendingUpdates: true
    });
    console.log("\u2705 Telegram bot started successfully");
    const cleanup = () => {
      if (botInstance) {
        botInstance.stop("SIGINT");
        botInstance = null;
      }
    };
    process.once("SIGINT", cleanup);
    process.once("SIGTERM", cleanup);
    process.once("SIGQUIT", cleanup);
  } catch (error) {
    console.error("Error starting Telegram bot:", error);
    if (error?.response?.error_code === 409) {
      console.log("\u26A0\uFE0F  Another Telegram bot instance is running. This is normal during development restarts.");
      console.log("   The conflict will resolve automatically when the old instance times out.");
      botInstance = null;
      return;
    }
    botInstance = null;
    throw error;
  }
}
function getTelegramBot() {
  return botInstance;
}
var botInstance;
var init_telegram_bot = __esm({
  "server/telegram-bot.ts"() {
    "use strict";
    init_solana_analyzer();
    init_storage();
    botInstance = null;
  }
});

// server/discord-bot.ts
var discord_bot_exports = {};
__export(discord_bot_exports, {
  getDiscordClient: () => getDiscordClient,
  startDiscordBot: () => startDiscordBot
});
import { Client, GatewayIntentBits, EmbedBuilder, SlashCommandBuilder, REST, Routes } from "discord.js";
function formatAddress2(address) {
  return `${address.slice(0, 4)}...${address.slice(-4)}`;
}
function formatNumber2(num) {
  if (num >= 1e9) {
    return (num / 1e9).toFixed(2) + "B";
  } else if (num >= 1e6) {
    return (num / 1e6).toFixed(2) + "M";
  } else if (num >= 1e3) {
    return (num / 1e3).toFixed(2) + "K";
  }
  return num.toFixed(2);
}
function getRiskColor(riskLevel) {
  switch (riskLevel) {
    case "LOW":
      return 65280;
    // Green
    case "MODERATE":
      return 16776960;
    // Yellow
    case "HIGH":
      return 16737792;
    // Orange
    case "EXTREME":
      return 16711680;
    // Red
    default:
      return 8421504;
  }
}
function getRiskEmoji2(riskLevel) {
  switch (riskLevel) {
    case "LOW":
      return "\u2705";
    case "MODERATE":
      return "\u26A0\uFE0F";
    case "HIGH":
      return "\u{1F6A8}";
    case "EXTREME":
      return "\u274C";
    default:
      return "\u2753";
  }
}
function createAnalysisEmbed(analysis) {
  const emoji = getRiskEmoji2(analysis.riskLevel);
  const color = getRiskColor(analysis.riskLevel);
  const embed = new EmbedBuilder().setColor(color).setTitle(`${emoji} ${analysis.metadata.name} (${analysis.metadata.symbol})`).setDescription(`**${analysis.riskScore}/100** (${analysis.riskLevel})
_Higher = Safer (0=Dangerous, 100=Safe)_`).setFooter({ text: `Contract: ${formatAddress2(analysis.tokenAddress)}` }).setTimestamp();
  embed.addFields({
    name: "\u{1F4CB} Contract Address",
    value: `\`${analysis.tokenAddress}\``,
    inline: false
  });
  if (analysis.aiVerdict) {
    embed.addFields({
      name: "\u{1F916} AI VERDICT",
      value: `${analysis.aiVerdict.rating} - ${analysis.aiVerdict.verdict}`,
      inline: false
    });
  }
  if (analysis.dexscreenerData?.pairs?.[0]) {
    const pair = analysis.dexscreenerData.pairs[0];
    const priceChange = pair.priceChange.h24 >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
    embed.addFields({
      name: "\u{1F4B0} PRICE",
      value: `Price: $${parseFloat(pair.priceUsd).toFixed(8)}
24h Vol: $${formatNumber2(pair.volume.h24)}
24h Change: ${priceChange} ${pair.priceChange.h24.toFixed(2)}%
MCap: $${formatNumber2(pair.marketCap || 0)}`,
      inline: true
    });
  }
  const burnPct = analysis.liquidityPool.burnPercentage;
  const burnEmoji = burnPct !== void 0 ? burnPct >= 99.99 ? "\u2705" : burnPct >= 50 ? "\u26A0\uFE0F" : "\u274C" : "\u2753";
  const burnText = burnPct !== void 0 ? `${burnPct.toFixed(1)}%` : "Unknown";
  embed.addFields({
    name: "\u{1F510} SECURITY",
    value: `Mint: ${analysis.mintAuthority.hasAuthority ? "\u274C Active" : "\u2705 Revoked"}
Freeze: ${analysis.freezeAuthority.hasAuthority ? "\u274C Active" : "\u2705 Revoked"}
LP Burn: ${burnEmoji} ${burnText}`,
    inline: true
  });
  if (analysis.pumpFunData?.isPumpFun) {
    embed.addFields({
      name: "\u{1F3AF} PUMP.FUN",
      value: `Dev Bought: ${analysis.pumpFunData.devBought.toFixed(2)}%
Bonding Curve: ${analysis.pumpFunData.bondingCurve.toFixed(2)}%`,
      inline: true
    });
  }
  embed.addFields({
    name: "\u{1F45B} HOLDERS",
    value: `Total: ${analysis.holderCount}
Top 10: ${analysis.topHolderConcentration.toFixed(2)}%
Supply: ${formatNumber2(analysis.metadata.supply)}`,
    inline: true
  });
  if (analysis.redFlags.length > 0) {
    const criticalFlags = analysis.redFlags.filter((f) => f.severity === "critical" || f.severity === "high");
    if (criticalFlags.length > 0) {
      embed.addFields({
        name: "\u26A0\uFE0F ALERTS",
        value: criticalFlags.slice(0, 3).map((f) => `${f.severity === "critical" ? "\u{1F534}" : "\u{1F7E0}"} ${f.title}`).join("\n").slice(0, 1024)
      });
    }
  }
  embed.addFields({
    name: "\u{1F517} QUICK LINKS",
    value: `[Solscan](https://solscan.io/token/${analysis.tokenAddress}) \u2022 [DexScreener](https://dexscreener.com/solana/${analysis.tokenAddress}) \u2022 [Rugcheck](https://rugcheck.xyz/tokens/${analysis.tokenAddress})
[AXiom](https://axiom.trade) \u2022 [Padre Bot](https://t.me/padre_tg_bot?start=${analysis.tokenAddress}) \u2022 [GMGN](https://gmgn.ai/sol/token/${analysis.tokenAddress}) \u2022 [Birdeye](https://birdeye.so/token/${analysis.tokenAddress}?chain=solana)`
  });
  embed.setURL(`https://solscan.io/token/${analysis.tokenAddress}`);
  return embed;
}
function createDiscordClient(botToken, clientId) {
  const client2 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ]
  });
  const registerCommands = async () => {
    try {
      const rest = new REST().setToken(botToken);
      console.log("Started refreshing Discord application (/) commands.");
      await rest.put(
        Routes.applicationCommands(clientId),
        { body: commands }
      );
      console.log("Successfully reloaded Discord application (/) commands.");
    } catch (error) {
      console.error("Error registering Discord commands:", error);
    }
  };
  client2.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    try {
      if (interaction.commandName === "help") {
        const helpEmbed = new EmbedBuilder().setColor(5793266).setTitle("\u{1F525} SOLANA RUG KILLER").setDescription("Protect yourself from rug pulls with comprehensive token analysis!").addFields(
          {
            name: "\u{1F4CB} Core Commands",
            value: "`/execute <address>` - Full 52-metric scan\n`/first20 <address>` - Top 20 holder analysis\n`/devtorture <address>` - Dev wallet history\n`/blacklist <wallet>` - Check if wallet is flagged\n`/help` - Show this help message"
          },
          {
            name: "\u{1F40B} Whale Tier Commands",
            value: "`/whaletrack <address>` - Smart money tracking\n`/kol <wallet>` - Check if wallet is KOL"
          },
          {
            name: "\u{1F4A1} Quick Tip",
            value: "You can also paste any Solana token address directly in chat for instant analysis!"
          }
        ).setFooter({ text: "Solana Rug Killer \u2022 Protecting the Solana ecosystem" }).setTimestamp();
        await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
      } else if (interaction.commandName === "execute") {
        const tokenAddress = interaction.options.getString("address", true);
        await interaction.deferReply();
        const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
        const embed = createAnalysisEmbed(analysis);
        await interaction.editReply({ embeds: [embed] });
      } else if (interaction.commandName === "first20") {
        const tokenAddress = interaction.options.getString("address", true);
        await interaction.deferReply();
        const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
        const embed = new EmbedBuilder().setColor(3447003).setTitle(`\u{1F4CA} Top 20 Holders - ${analysis.metadata.symbol}`).setDescription(`Total Top 10 Concentration: **${analysis.topHolderConcentration.toFixed(2)}%**`).setTimestamp();
        const holders = analysis.topHolders.slice(0, 20);
        const fieldsData = [
          holders.slice(0, 7),
          holders.slice(7, 14),
          holders.slice(14, 20)
        ];
        fieldsData.forEach((group, index2) => {
          if (group.length > 0) {
            embed.addFields({
              name: index2 === 0 ? "Top Holders" : "\u200B",
              value: group.map((h, i) => {
                const rank = index2 * 7 + i + 1;
                return `${rank}. \`${formatAddress2(h.address)}\` - ${h.percentage.toFixed(2)}%`;
              }).join("\n"),
              inline: false
            });
          }
        });
        if (analysis.topHolderConcentration > 50) {
          embed.setFooter({ text: "\u26A0\uFE0F WARNING: High holder concentration detected!" });
        }
        await interaction.editReply({ embeds: [embed] });
      } else if (interaction.commandName === "devtorture") {
        const tokenAddress = interaction.options.getString("address", true);
        await interaction.deferReply();
        const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
        const embed = new EmbedBuilder().setColor(16739116).setTitle(`\u{1F525} Dev Torture Report - ${analysis.metadata.symbol}`).setDescription(`Contract: \`${formatAddress2(tokenAddress)}\``).setTimestamp();
        if (analysis.mintAuthority.hasAuthority && !analysis.mintAuthority.isRevoked) {
          embed.addFields({
            name: "\u274C Mint Authority Active",
            value: `Dev can mint unlimited tokens!
Authority: \`${formatAddress2(analysis.mintAuthority.authorityAddress || "Unknown")}\``
          });
        }
        if (analysis.freezeAuthority.hasAuthority && !analysis.freezeAuthority.isRevoked) {
          embed.addFields({
            name: "\u274C Freeze Authority Active",
            value: `Dev can freeze accounts!
Authority: \`${formatAddress2(analysis.freezeAuthority.authorityAddress || "Unknown")}\``
          });
        }
        if (analysis.creationDate) {
          const age = Math.floor((Date.now() - analysis.creationDate) / (1e3 * 60 * 60 * 24));
          let ageText = `Token Age: ${age} days`;
          if (age < 7) {
            ageText += "\n\u26A0\uFE0F Very new token - high risk!";
          }
          embed.addFields({
            name: "\u{1F4C5} Age",
            value: ageText
          });
        }
        await interaction.editReply({ embeds: [embed] });
      } else if (interaction.commandName === "blacklist") {
        const walletAddress = interaction.options.getString("wallet", true);
        await interaction.deferReply();
        const embed = new EmbedBuilder().setColor(65280).setTitle("\u{1F50D} Blacklist Check").setDescription(`Wallet: \`${formatAddress2(walletAddress)}\``).addFields({
          name: "Status",
          value: "\u2705 Not currently flagged"
        }).setTimestamp();
        await interaction.editReply({ embeds: [embed] });
      } else if (interaction.commandName === "whaletrack") {
        const tokenAddress = interaction.options.getString("address", true);
        await interaction.deferReply();
        const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
        const holderAddresses = analysis.topHolders.map((h) => h.address);
        const kolHolders = await storage.getKolWalletsByAddresses(holderAddresses);
        const embed = new EmbedBuilder().setColor(kolHolders.length > 0 ? 16750848 : 65280).setTitle(`\u{1F40B} Whale Tracking - ${analysis.metadata.symbol}`).setTimestamp();
        if (kolHolders.length === 0) {
          embed.setDescription("\u2705 No known smart money wallets detected in top holders").addFields({
            name: "Analysis",
            value: "This could be a good sign - no influential traders have entered yet, or it could mean the token hasn't attracted attention from experienced traders."
          });
        } else {
          const totalKolPercentage = kolHolders.reduce((sum, kol) => {
            const holder = analysis.topHolders.find((h) => h.address === kol.walletAddress);
            return sum + (holder?.percentage || 0);
          }, 0);
          embed.setDescription(`\u26A0\uFE0F **${kolHolders.length} Smart Money Wallet${kolHolders.length > 1 ? "s" : ""} Detected**`);
          const kolData = kolHolders.slice(0, 5).map((kol) => {
            const holder = analysis.topHolders.find((h) => h.address === kol.walletAddress);
            const percentage = holder ? holder.percentage.toFixed(2) : "N/A";
            let value = `Wallet: \`${formatAddress2(kol.walletAddress)}\`
`;
            value += `Holdings: ${percentage}% of supply
`;
            value += `Influence: ${kol.influenceScore !== null ? kol.influenceScore.toString() : "N/A"}/100`;
            if (kol.profitSol) {
              value += `
Profit: ${formatNumber2(Number(kol.profitSol) || 0)} SOL`;
            }
            return {
              name: `\u{1F48E} ${kol.displayName || "Unknown KOL"}`,
              value,
              inline: false
            };
          });
          embed.addFields(...kolData);
          let statusText = `**Total Smart Money Holdings: ${totalKolPercentage.toFixed(2)}%**

`;
          if (totalKolPercentage > 30) {
            statusText += "\u{1F6A8} HIGH concentration - Smart money controls significant supply!";
          } else if (totalKolPercentage > 15) {
            statusText += "\u26A0\uFE0F MODERATE concentration - Watch for coordinated sells";
          } else {
            statusText += "\u2705 LOW concentration - Smart money has small positions";
          }
          embed.addFields({
            name: "\u{1F4CA} Summary",
            value: statusText
          });
        }
        await interaction.editReply({ embeds: [embed] });
      } else if (interaction.commandName === "kol") {
        const walletAddress = interaction.options.getString("wallet", true);
        await interaction.deferReply();
        const kol = await storage.getKolWallet(walletAddress);
        if (!kol) {
          const embed2 = new EmbedBuilder().setColor(8421504).setTitle("\u{1F4CA} KOL Check").setDescription(`Wallet: \`${formatAddress2(walletAddress)}\``).addFields({
            name: "Status",
            value: "\u274C Not found in KOL database\n\nThis wallet is not currently tracked as a known influential trader."
          }).setTimestamp();
          await interaction.editReply({ embeds: [embed2] });
          return;
        }
        const influenceScore = kol.influenceScore !== null ? kol.influenceScore : 0;
        const color = influenceScore > 80 ? 16739116 : influenceScore > 60 ? 16753920 : 3447003;
        const embed = new EmbedBuilder().setColor(color).setTitle("\u{1F48E} KOL Profile Found").setDescription(`**${kol.displayName || "Unknown"}**
Wallet: \`${formatAddress2(kol.walletAddress)}\``).setTimestamp();
        let statsValue = `\u2022 Rank: #${kol.rank !== null ? kol.rank.toString() : "N/A"}
`;
        statsValue += `\u2022 Influence Score: ${kol.influenceScore !== null ? kol.influenceScore.toString() : "N/A"}/100
`;
        if (kol.profitSol !== null) {
          statsValue += `\u2022 Total Profit: ${formatNumber2(Number(kol.profitSol) || 0)} SOL
`;
        }
        if (kol.wins !== null && kol.losses !== null) {
          const total = kol.wins + kol.losses;
          const winRate = total > 0 ? (kol.wins / total * 100).toFixed(1) : "N/A";
          statsValue += `\u2022 Wins: ${kol.wins} | Losses: ${kol.losses}
`;
          statsValue += `\u2022 Win Rate: ${winRate}%`;
        }
        embed.addFields({
          name: "\u{1F4CA} Stats",
          value: statsValue
        });
        if (kol.lastActiveAt) {
          const lastActive = new Date(kol.lastActiveAt);
          embed.addFields({
            name: "\u{1F4C5} Last Active",
            value: lastActive.toLocaleDateString()
          });
        }
        let tierText = "";
        if (kol.influenceScore && kol.influenceScore > 80) {
          tierText = "\u{1F525} **HIGHLY INFLUENTIAL** - Top tier trader";
        } else if (kol.influenceScore && kol.influenceScore > 60) {
          tierText = "\u2B50 **INFLUENTIAL** - Experienced trader";
        } else {
          tierText = "\u{1F4C8} **TRACKED** - Known trader";
        }
        embed.addFields({
          name: "Tier",
          value: tierText
        });
        await interaction.editReply({ embeds: [embed] });
      }
    } catch (error) {
      console.error("Discord command error:", error);
      if (interaction.deferred) {
        await interaction.editReply({ content: "\u274C Error executing command. Please check the address and try again." });
      } else {
        await interaction.reply({ content: "\u274C Error executing command. Please check the address and try again.", ephemeral: true });
      }
    }
  });
  client2.on("messageCreate", async (message2) => {
    if (message2.author.bot) return;
    if (!message2.content) return;
    const text2 = message2.content.trim();
    if (text2.length >= 32 && text2.length <= 44 && !/\s/.test(text2)) {
      try {
        const processingMsg = await message2.reply("\u{1F50D} Quick analysis...");
        const analysis = await tokenAnalyzer.analyzeToken(text2);
        const embed = createAnalysisEmbed(analysis);
        await processingMsg.delete();
        await message2.reply({ embeds: [embed] });
      } catch (error) {
      }
    }
  });
  client2.once("ready", () => {
    console.log(`\u2705 Discord bot logged in as ${client2.user?.tag}`);
    registerCommands();
  });
  return client2;
}
async function startDiscordBot() {
  const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
  const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
  if (!BOT_TOKEN || BOT_TOKEN === "PLACEHOLDER_TOKEN" || !CLIENT_ID || CLIENT_ID === "PLACEHOLDER_ID") {
    console.log("\u26A0\uFE0F  Discord bot token not configured. Set DISCORD_BOT_TOKEN and DISCORD_CLIENT_ID to enable bot.");
    return;
  }
  if (clientInstance) {
    console.log("\u26A0\uFE0F  Discord bot already running");
    return;
  }
  try {
    clientInstance = createDiscordClient(BOT_TOKEN, CLIENT_ID);
    await clientInstance.login(BOT_TOKEN);
    console.log("\u2705 Discord bot started successfully");
  } catch (error) {
    console.error("Error starting Discord bot:", error);
    clientInstance = null;
    throw error;
  }
}
function getDiscordClient() {
  return clientInstance;
}
var clientInstance, commands;
var init_discord_bot = __esm({
  "server/discord-bot.ts"() {
    "use strict";
    init_solana_analyzer();
    init_storage();
    clientInstance = null;
    commands = [
      new SlashCommandBuilder().setName("help").setDescription("Show all available commands and how to use the bot"),
      new SlashCommandBuilder().setName("execute").setDescription("Full 52-metric rug detection scan").addStringOption(
        (option) => option.setName("address").setDescription("Token contract address").setRequired(true)
      ),
      new SlashCommandBuilder().setName("first20").setDescription("Analyze top 20 token holders").addStringOption(
        (option) => option.setName("address").setDescription("Token contract address").setRequired(true)
      ),
      new SlashCommandBuilder().setName("devtorture").setDescription("Track dev wallet history").addStringOption(
        (option) => option.setName("address").setDescription("Token contract address").setRequired(true)
      ),
      new SlashCommandBuilder().setName("blacklist").setDescription("Check if wallet is flagged").addStringOption(
        (option) => option.setName("wallet").setDescription("Wallet address to check").setRequired(true)
      ),
      new SlashCommandBuilder().setName("whaletrack").setDescription("Track smart money wallets in a token").addStringOption(
        (option) => option.setName("address").setDescription("Token contract address").setRequired(true)
      ),
      new SlashCommandBuilder().setName("kol").setDescription("Check if a wallet is a known KOL").addStringOption(
        (option) => option.setName("wallet").setDescription("Wallet address to check").setRequired(true)
      )
    ].map((command) => command.toJSON());
  }
});

// server/alpha-alerts.ts
var alpha_alerts_exports = {};
__export(alpha_alerts_exports, {
  AlphaAlertService: () => AlphaAlertService,
  getAlphaAlertService: () => getAlphaAlertService
});
import { Connection as Connection6, PublicKey as PublicKey6 } from "@solana/web3.js";
import WebSocket from "ws";
function getAlphaAlertService() {
  if (!alphaAlertInstance) {
    alphaAlertInstance = new AlphaAlertService();
  }
  return alphaAlertInstance;
}
var DEFAULT_ALPHA_CALLERS, AlphaAlertService, alphaAlertInstance;
var init_alpha_alerts = __esm({
  "server/alpha-alerts.ts"() {
    "use strict";
    DEFAULT_ALPHA_CALLERS = [];
    AlphaAlertService = class {
      connection;
      listeners = /* @__PURE__ */ new Map();
      wsConnections = [];
      alertCallbacks = [];
      isRunning = false;
      alphaCallers;
      constructor(rpcUrl, customCallers) {
        this.connection = new Connection6(rpcUrl || "https://api.mainnet-beta.solana.com", "confirmed");
        this.alphaCallers = customCallers || DEFAULT_ALPHA_CALLERS;
      }
      // Register callback for alerts
      onAlert(callback) {
        this.alertCallbacks.push(callback);
      }
      async sendAlert(alert) {
        let message2 = "";
        if (alert.type === "caller_signal") {
          message2 = `\u{1F6A8} **ALPHA CALL from ${alert.source}**

\u{1F4CD} CA: \`${alert.mint}\`
\u{1F464} Caller: ${alert.source}
\u{1F517} https://pump.fun/${alert.mint}
\u{1F48E} https://dexscreener.com/solana/${alert.mint}`;
        } else if (alert.type === "new_token") {
          message2 = `\u{1F525} **NEW GEM DETECTED**

\u{1F4CD} CA: \`${alert.mint}\`
\u{1F4CA} Source: ${alert.source}
${alert.data?.name ? `\u{1F3F7}\uFE0F ${alert.data.name} (${alert.data.symbol})
` : ""}${alert.data?.marketCap ? `\u{1F4B0} MC: $${alert.data.marketCap.toLocaleString()}
` : ""}\u{1F517} https://pump.fun/${alert.mint}`;
        } else {
          message2 = `\u26A1 **ALPHA ALERT**

${alert.mint}
Source: ${alert.source}`;
        }
        const DISCORD_WEBHOOK = process.env.ALPHA_DISCORD_WEBHOOK;
        if (DISCORD_WEBHOOK) {
          try {
            await fetch(DISCORD_WEBHOOK, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                content: `@everyone ${message2}`,
                username: "RugKiller Alpha Alerts",
                avatar_url: "https://i.imgur.com/rugkiller-icon.png"
              })
            });
          } catch (error) {
            console.error("[ALPHA ALERT] Discord notification failed:", error);
          }
        }
        const TELEGRAM_TOKEN = process.env.ALPHA_TELEGRAM_BOT_TOKEN;
        const TELEGRAM_CHAT = process.env.ALPHA_TELEGRAM_CHAT_ID;
        if (TELEGRAM_TOKEN && TELEGRAM_CHAT) {
          try {
            const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;
            await fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: TELEGRAM_CHAT,
                text: message2,
                parse_mode: "Markdown"
              })
            });
          } catch (error) {
            console.error("[ALPHA ALERT] Telegram notification failed:", error);
          }
        }
        for (const callback of this.alertCallbacks) {
          try {
            await callback(alert);
          } catch (error) {
            console.error("[ALPHA ALERT] Callback error:", error);
          }
        }
      }
      // Check if token passes basic quality filters
      async isQualityToken(mint) {
        try {
          const [rugCheck, dexScreener] = await Promise.all([
            fetch(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`).then((r) => r.json()).catch(() => null),
            fetch(`https://api.dexscreener.com/latest/dex/tokens/${mint}`).then((r) => r.json()).catch(() => null)
          ]);
          const hasGoodRugScore = rugCheck?.score > 85;
          const notHoneypot = !rugCheck?.isHoneypot;
          const hasLiquidity = (dexScreener?.pairs?.[0]?.liquidity?.usd || 0) > 5e3;
          return hasGoodRugScore && notHoneypot && hasLiquidity;
        } catch (error) {
          console.error("[ALPHA ALERT] Quality check error:", error);
          return false;
        }
      }
      // Monitor alpha caller wallets for transactions
      monitorAlphaCaller(caller) {
        if (!caller.enabled) return;
        try {
          const publicKey = new PublicKey6(caller.wallet);
          const listenerId = this.connection.onLogs(
            publicKey,
            async (logs) => {
              try {
                const buyPattern = /buy|swap|purchase/i;
                const mintPattern = /[1-9A-HJ-NP-Za-km-z]{32,44}/;
                for (const log2 of logs.logs) {
                  if (buyPattern.test(log2)) {
                    const matches = log2.match(mintPattern);
                    if (matches && matches[0]) {
                      const mint = matches[0];
                      if (await this.isQualityToken(mint)) {
                        await this.sendAlert({
                          type: "caller_signal",
                          mint,
                          source: caller.name,
                          timestamp: Date.now(),
                          data: {
                            wallet: caller.wallet,
                            transactionType: "buy"
                          }
                        });
                      }
                    }
                  }
                }
              } catch (error) {
                console.error(`[ALPHA ALERT] Error processing ${caller.name} logs:`, error);
              }
            },
            "confirmed"
          );
          this.listeners.set(caller.wallet, listenerId);
        } catch (error) {
          console.error(`[ALPHA ALERT] Failed to monitor ${caller.name}:`, error);
        }
      }
      // Monitor pump.fun WebSocket for new token launches
      startPumpFunMonitor() {
        try {
          const ws2 = new WebSocket("wss://pumpportal.fun/api/data");
          ws2.on("open", () => {
            ws2.send(JSON.stringify({ method: "subscribeNewToken" }));
          });
          ws2.on("message", async (data) => {
            try {
              const msg = JSON.parse(data.toString());
              if (msg.mint && msg.mint.length === 44) {
                if (await this.isQualityToken(msg.mint)) {
                  await this.sendAlert({
                    type: "new_token",
                    mint: msg.mint,
                    source: "pump.fun",
                    timestamp: Date.now(),
                    data: {
                      name: msg.name,
                      symbol: msg.symbol,
                      marketCap: msg.marketCap
                    }
                  });
                }
              }
            } catch (error) {
              console.error("[ALPHA ALERT] pump.fun message error:", error);
            }
          });
          ws2.on("error", (error) => {
            console.error("[ALPHA ALERT] pump.fun WebSocket error:", error);
          });
          ws2.on("close", () => {
            if (this.isRunning) {
              setTimeout(() => this.startPumpFunMonitor(), 1e4);
            }
          });
          this.wsConnections.push(ws2);
        } catch (error) {
          console.error("[ALPHA ALERT] Failed to start pump.fun monitor:", error);
        }
      }
      // Start all monitoring
      async start() {
        if (this.isRunning) {
          return;
        }
        this.isRunning = true;
        for (const caller of this.alphaCallers) {
          this.monitorAlphaCaller(caller);
        }
        this.startPumpFunMonitor();
        const startupMessage = `\u{1F916} **ANTIRUGILLER ALPHA ALERTS ONLINE**

\u2705 Monitoring ${this.alphaCallers.filter((c) => c.enabled).length} top alpha callers
\u2705 Connected to pump.fun live feed
\u2705 Quality filters active (RugCheck > 85, No honeypots, Liquidity > $5K)

Contract: \`2rvVzKqwW7yeF8vbyVgvo7hEqaPvFx7fZudyLcRMxmNt\``;
        const DISCORD_WEBHOOK = process.env.ALPHA_DISCORD_WEBHOOK;
        if (DISCORD_WEBHOOK) {
          try {
            await fetch(DISCORD_WEBHOOK, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                content: startupMessage,
                username: "RugKiller Alpha Alerts"
              })
            });
          } catch (error) {
            console.error("[ALPHA ALERT] Discord startup notification failed:", error);
          }
        }
        const TELEGRAM_TOKEN = process.env.ALPHA_TELEGRAM_BOT_TOKEN;
        const TELEGRAM_CHAT = process.env.ALPHA_TELEGRAM_CHAT_ID;
        if (TELEGRAM_TOKEN && TELEGRAM_CHAT) {
          try {
            const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;
            await fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: TELEGRAM_CHAT,
                text: startupMessage,
                parse_mode: "Markdown"
              })
            });
          } catch (error) {
            console.error("[ALPHA ALERT] Telegram startup notification failed:", error);
          }
        }
      }
      // Stop all monitoring
      async stop() {
        this.isRunning = false;
        for (const [wallet, listenerId] of Array.from(this.listeners.entries())) {
          try {
            await this.connection.removeOnLogsListener(listenerId);
          } catch (error) {
            console.error(`[ALPHA ALERT] Error removing listener for ${wallet}:`, error);
          }
        }
        this.listeners.clear();
        for (const ws2 of this.wsConnections) {
          try {
            ws2.close();
          } catch (error) {
            console.error("[ALPHA ALERT] Error closing WebSocket:", error);
          }
        }
        this.wsConnections = [];
      }
      // Get current monitoring status
      getStatus() {
        return {
          isRunning: this.isRunning,
          monitoredCallers: this.alphaCallers.filter((c) => c.enabled).length,
          totalCallers: this.alphaCallers.length,
          activeListeners: this.listeners.size,
          activeWebSockets: this.wsConnections.length,
          callers: this.alphaCallers
        };
      }
      // Add custom alpha caller
      addCaller(wallet, name) {
        if (!this.alphaCallers.find((c) => c.wallet === wallet)) {
          const caller = { wallet, name, enabled: true };
          this.alphaCallers.push(caller);
          if (this.isRunning) {
            this.monitorAlphaCaller(caller);
          }
        }
      }
      // Remove custom alpha caller
      removeCaller(wallet) {
        const index2 = this.alphaCallers.findIndex((c) => c.wallet === wallet);
        if (index2 !== -1) {
          const caller = this.alphaCallers[index2];
          this.alphaCallers.splice(index2, 1);
          const listenerId = this.listeners.get(wallet);
          if (listenerId !== void 0) {
            this.connection.removeOnLogsListener(listenerId);
            this.listeners.delete(wallet);
          }
        }
      }
    };
    alphaAlertInstance = null;
  }
});

// server/workers/analytics-worker.ts
var analytics_worker_exports = {};
__export(analytics_worker_exports, {
  AnalyticsWorker: () => AnalyticsWorker,
  analyticsWorker: () => analyticsWorker
});
var AnalyticsWorker, analyticsWorker;
var init_analytics_worker = __esm({
  "server/workers/analytics-worker.ts"() {
    "use strict";
    init_storage();
    init_price_cache();
    init_solana_analyzer();
    init_ai_blacklist();
    AnalyticsWorker = class {
      isRunning = false;
      snapshotIntervalId;
      trendingIntervalId;
      statsIntervalId;
      /**
       * Start all analytics workers
       */
      start() {
        if (this.isRunning) {
          console.log("Analytics worker already running");
          return;
        }
        console.log("Starting analytics workers...");
        this.isRunning = true;
        this.runSnapshotCollector().catch(console.error);
        this.snapshotIntervalId = setInterval(() => {
          this.runSnapshotCollector().catch(console.error);
        }, 5 * 60 * 1e3);
        this.runTrendingCalculator().catch(console.error);
        this.trendingIntervalId = setInterval(() => {
          this.runTrendingCalculator().catch(console.error);
        }, 5 * 60 * 1e3);
        this.runRiskAggregator().catch(console.error);
        this.statsIntervalId = setInterval(() => {
          this.runRiskAggregator().catch(console.error);
        }, 24 * 60 * 60 * 1e3);
        console.log("Analytics workers started successfully");
      }
      /**
       * Stop all analytics workers
       */
      stop() {
        if (this.snapshotIntervalId) clearInterval(this.snapshotIntervalId);
        if (this.trendingIntervalId) clearInterval(this.trendingIntervalId);
        if (this.statsIntervalId) clearInterval(this.statsIntervalId);
        this.snapshotIntervalId = void 0;
        this.trendingIntervalId = void 0;
        this.statsIntervalId = void 0;
        this.isRunning = false;
        console.log("Analytics workers stopped");
      }
      /**
       * Snapshot Collector - Captures token data every 5 minutes
       * Queries tokens from price cache and saves analysis snapshots
       */
      async runSnapshotCollector() {
        try {
          console.log("[Snapshot Collector] Starting...");
          const recentTokens = priceCache.getRecentlyUpdated(60);
          if (recentTokens.length === 0) {
            console.log("[Snapshot Collector] No recent tokens to snapshot");
            return;
          }
          console.log(`[Snapshot Collector] Processing ${recentTokens.length} tokens`);
          const batchSize = 10;
          for (let i = 0; i < recentTokens.length; i += batchSize) {
            const batch = recentTokens.slice(i, i + batchSize);
            await Promise.all(
              batch.map(async (tokenAddress) => {
                try {
                  const priceData = priceCache.get(tokenAddress);
                  const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
                  const txCount24h = analysis.marketData?.txns24h ? analysis.marketData.txns24h.buys + analysis.marketData.txns24h.sells : void 0;
                  await storage.saveTokenSnapshot({
                    tokenAddress,
                    priceUsd: priceData?.priceUsd?.toString() || null,
                    riskScore: analysis.riskScore,
                    holderCount: analysis.holderCount,
                    volume24h: priceData?.volume24h?.toString() || null,
                    liquidityUsd: priceData?.liquidity?.toString() || null,
                    riskFlags: analysis.redFlags.map((f) => f.type),
                    txCount24h,
                    analyzerVersion: "1.0"
                  });
                } catch (error) {
                  console.error(`[Snapshot Collector] Error processing ${tokenAddress}:`, error);
                }
              })
            );
          }
          console.log(`[Snapshot Collector] Completed - ${recentTokens.length} snapshots saved`);
        } catch (error) {
          console.error("[Snapshot Collector] Fatal error:", error);
        }
      }
      /**
       * Trending Calculator - Calculates trending scores every 5 minutes
       * Score formula: volume24h * 0.4 + velocity * 0.3 + analyses * 0.3
       */
      async runTrendingCalculator() {
        try {
          console.log("[Trending Calculator] Starting...");
          const allTokens = priceCache.getAllTokens();
          if (allTokens.length === 0) {
            console.log("[Trending Calculator] No tokens to analyze");
            return;
          }
          const scoredTokens = await Promise.all(
            allTokens.map(async (tokenAddress) => {
              const priceData = priceCache.get(tokenAddress);
              if (!priceData) return null;
              const historical = await storage.getHistoricalData(tokenAddress, 1);
              let velocity = 0;
              if (historical.length >= 2) {
                const oldest = historical[0];
                const newest = historical[historical.length - 1];
                if (oldest.priceUsd && newest.priceUsd) {
                  const oldPrice = parseFloat(oldest.priceUsd);
                  const newPrice = parseFloat(newest.priceUsd);
                  velocity = (newPrice - oldPrice) / oldPrice * 100;
                }
              }
              const volumeScore = Math.min(100, (priceData.volume24h || 0) / 1e7 * 100) * 0.4;
              const velocityScore = Math.min(100, Math.max(0, (velocity + 500) / 1e3 * 100)) * 0.3;
              const analysisScore = Math.min(100, historical.length * 2) * 0.3;
              const totalScore = volumeScore + velocityScore + analysisScore;
              return {
                tokenAddress,
                score: totalScore,
                scoreBreakdown: {
                  volumeScore,
                  velocityScore,
                  analysisScore
                },
                volume24h: priceData.volume24h,
                velocity
              };
            })
          );
          const validScores = scoredTokens.filter((t) => t !== null).sort((a, b) => b.score - a.score);
          const top50 = validScores.slice(0, 50).map((token, index2) => ({
            tokenAddress: token.tokenAddress,
            score: token.score.toString(),
            scoreBreakdown: token.scoreBreakdown,
            rank: index2 + 1,
            volume24h: token.volume24h?.toString(),
            velocity: token.velocity.toString()
          }));
          await storage.updateTrendingScores(top50);
          console.log(`[Trending Calculator] Completed - Top 50 tokens ranked`);
        } catch (error) {
          console.error("[Trending Calculator] Fatal error:", error);
        }
      }
      /**
       * Risk Statistics Aggregator - Runs daily
       * Aggregates risk data from snapshots and blacklist
       */
      async runRiskAggregator() {
        try {
          console.log("[Risk Aggregator] Starting...");
          const now = /* @__PURE__ */ new Date();
          const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1e3);
          const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1e3);
          const blacklist = await getTopFlaggedWallets();
          await this.aggregateRiskWindow(sevenDaysAgo, now, blacklist.length);
          await this.aggregateRiskWindow(thirtyDaysAgo, now, blacklist.length);
          console.log("[Risk Aggregator] Completed");
        } catch (error) {
          console.error("[Risk Aggregator] Fatal error:", error);
        }
      }
      /**
       * Helper: Aggregate risk statistics for a time window
       */
      async aggregateRiskWindow(windowStart, windowEnd, rugCount) {
        const allSnapshots = await storage.getHistoricalData("", Math.ceil((windowEnd.getTime() - windowStart.getTime()) / (24 * 60 * 60 * 1e3)));
        const uniqueTokens = new Set(allSnapshots.map((s) => s.tokenAddress));
        const totalAnalyzed = uniqueTokens.size;
        const flagCounts = {};
        for (const snapshot of allSnapshots) {
          if (snapshot.riskFlags && Array.isArray(snapshot.riskFlags)) {
            for (const flag of snapshot.riskFlags) {
              flagCounts[flag] = (flagCounts[flag] || 0) + 1;
            }
          }
        }
        await storage.saveRiskStatistics({
          windowStart,
          windowEnd,
          totalAnalyzed,
          rugDetected: rugCount,
          falsePositives: 0,
          // Would need manual tracking
          commonFlags: flagCounts
        });
        console.log(`[Risk Aggregator] Saved stats for ${windowStart.toISOString()} to ${windowEnd.toISOString()}`);
      }
    };
    analyticsWorker = new AnalyticsWorker();
  }
});

// server/workers/social-worker.ts
var social_worker_exports = {};
__export(social_worker_exports, {
  socialWorker: () => socialWorker
});
var SocialWorker, socialWorker;
var init_social_worker = __esm({
  "server/workers/social-worker.ts"() {
    "use strict";
    init_storage();
    init_social_service();
    SocialWorker = class {
      reputationInterval = null;
      voteAggregationInterval = null;
      moderationInterval = null;
      start() {
        console.log("Starting social worker background jobs...");
        this.reputationInterval = setInterval(() => {
          this.calculateReputations().catch(console.error);
        }, 60 * 60 * 1e3);
        this.voteAggregationInterval = setInterval(() => {
          this.aggregateVotes().catch(console.error);
        }, 5 * 60 * 1e3);
        this.moderationInterval = setInterval(() => {
          this.processModeration().catch(console.error);
        }, 10 * 60 * 1e3);
        this.calculateReputations().catch(console.error);
        this.aggregateVotes().catch(console.error);
      }
      async calculateReputations() {
        console.log("Calculating user reputations...");
        const profiles = await storage.getTopUsers(1e3);
        for (const profile of profiles) {
          const reputation = await socialService.calculateReputation(profile.userId);
          await storage.updateUserProfile(profile.userId, {
            reputationScore: reputation
          });
        }
        console.log(`Updated reputation for ${profiles.length} users`);
      }
      async aggregateVotes() {
        console.log("Aggregating community votes...");
      }
      async processModeration() {
        console.log("Processing moderation queue...");
        const reports = await storage.getPendingReports();
        console.log(`Found ${reports.length} pending reports`);
      }
      stop() {
        if (this.reputationInterval) clearInterval(this.reputationInterval);
        if (this.voteAggregationInterval) clearInterval(this.voteAggregationInterval);
        if (this.moderationInterval) clearInterval(this.moderationInterval);
        console.log("Social worker stopped");
      }
    };
    socialWorker = new SocialWorker();
  }
});

// server/index.ts
import express2 from "express";

// server/routes.ts
init_schema();
init_solana_analyzer();
import { createServer } from "http";

// server/replitAuth.ts
init_storage();
import * as client from "openid-client";
import { Strategy } from "openid-client/passport";
import passport from "passport";
import session from "express-session";
import memoize from "memoizee";
import connectPg from "connect-pg-simple";
var getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID
    );
  },
  { maxAge: 3600 * 1e3 }
);
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions"
  });
  return session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: true,
      maxAge: sessionTtl
    }
  });
}
function updateUserSession(user, tokens) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}
async function upsertUser(claims) {
  await storage.upsertUser({
    id: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"]
  });
}
async function setupAuth(app2) {
  app2.set("trust proxy", 1);
  app2.use(getSession());
  app2.use(passport.initialize());
  app2.use(passport.session());
  const config = await getOidcConfig();
  const verify = async (tokens, verified) => {
    const user = {};
    updateUserSession(user, tokens);
    await upsertUser(tokens.claims());
    verified(null, user);
  };
  const registeredStrategies = /* @__PURE__ */ new Set();
  const ensureStrategy = (domain) => {
    const strategyName = `replitauth:${domain}`;
    if (!registeredStrategies.has(strategyName)) {
      const strategy = new Strategy(
        {
          name: strategyName,
          config,
          scope: "openid email profile offline_access",
          callbackURL: `https://${domain}/api/callback`
        },
        verify
      );
      passport.use(strategy);
      registeredStrategies.add(strategyName);
    }
  };
  passport.serializeUser((user, cb) => cb(null, user));
  passport.deserializeUser((user, cb) => cb(null, user));
  app2.get("/api/login", (req, res, next) => {
    ensureStrategy(req.hostname);
    passport.authenticate(`replitauth:${req.hostname}`, {
      prompt: "login consent",
      scope: ["openid", "email", "profile", "offline_access"]
    })(req, res, next);
  });
  app2.get("/api/callback", (req, res, next) => {
    ensureStrategy(req.hostname);
    passport.authenticate(`replitauth:${req.hostname}`, {
      successReturnToOrRedirect: "/",
      failureRedirect: "/api/login"
    })(req, res, next);
  });
  app2.get("/api/logout", (req, res) => {
    req.logout(() => {
      res.redirect(
        client.buildEndSessionUrl(config, {
          client_id: process.env.REPL_ID,
          post_logout_redirect_uri: `${req.protocol}://${req.hostname}`
        }).href
      );
    });
  });
}
var isAuthenticated = async (req, res, next) => {
  const user = req.user;
  if (!req.isAuthenticated() || !user.expires_at) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const now = Math.floor(Date.now() / 1e3);
  if (now <= user.expires_at) {
    return next();
  }
  const refreshToken = user.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
  try {
    const config = await getOidcConfig();
    const tokenResponse = await client.refreshTokenGrant(config, refreshToken);
    updateUserSession(user, tokenResponse);
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};

// server/routes.ts
init_storage();

// server/whop-client.ts
import Whop from "@whop/sdk";
var WHOP_API_KEY = process.env.WHOP_API_KEY;
var WHOP_APP_ID = process.env.WHOP_APP_ID;
var WHOP_COMPANY_ID = process.env.WHOP_COMPANY_ID;
if (!WHOP_API_KEY || !WHOP_APP_ID) {
  console.warn("\u26A0\uFE0F  Whop not configured (missing WHOP_API_KEY or WHOP_APP_ID)");
}
var whopClient = new Whop({
  appID: WHOP_APP_ID || "",
  apiKey: WHOP_API_KEY || ""
});
var WHOP_PLAN_IDS = {
  INDIVIDUAL: process.env.WHOP_PLAN_ID_INDIVIDUAL || "",
  GROUP: process.env.WHOP_PLAN_ID_GROUP || ""
};
async function createWhopCheckout(params) {
  if (!WHOP_COMPANY_ID) {
    throw new Error("WHOP_COMPANY_ID not configured");
  }
  if (!WHOP_API_KEY) {
    throw new Error("WHOP_API_KEY not configured");
  }
  try {
    const response = await fetch("https://api.whop.com/api/v2/checkout_sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${WHOP_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        plan_id: params.planId,
        redirect_url: `${process.env.REPL_HOME || "http://localhost:5000"}/subscription/success`,
        metadata: {
          user_id: params.userId,
          user_email: params.userEmail || "",
          ...params.metadata
        }
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Whop API error: ${response.status} - ${errorText}`);
    }
    const data = await response.json();
    return {
      checkoutUrl: data.checkout_url,
      sessionId: data.id
    };
  } catch (error) {
    console.error("Error creating Whop checkout:", error);
    throw new Error(`Failed to create checkout: ${error.message}`);
  }
}
async function cancelWhopMembership(membershipId) {
  try {
    await whopClient.memberships.cancel(membershipId);
    return true;
  } catch (error) {
    console.error("Error canceling membership:", error);
    return false;
  }
}
function mapWhopStatus(whopStatus) {
  const statusMap = {
    "active": "valid",
    "trialing": "trialing",
    "past_due": "past_due",
    "canceled": "cancelled",
    "incomplete": "expired",
    "incomplete_expired": "expired",
    "unpaid": "past_due"
  };
  return statusMap[whopStatus] || "expired";
}
function mapPlanToTier(planId) {
  if (planId === WHOP_PLAN_IDS.GROUP) return "group";
  if (planId === WHOP_PLAN_IDS.INDIVIDUAL) return "individual";
  return "free_trial";
}

// server/vanity-generator.ts
import { Keypair } from "@solana/web3.js";
import bs58 from "bs58";
var VanityAddressGenerator = class {
  stopped = false;
  stop() {
    this.stopped = true;
  }
  async generate(options, onProgress) {
    const { pattern, matchType, caseSensitive = false, maxAttempts = 1e7 } = options;
    const searchPattern = caseSensitive ? pattern : pattern.toLowerCase();
    let attempts = 0;
    const startTime = Date.now();
    this.stopped = false;
    const progressInterval = 1e4;
    while (attempts < maxAttempts && !this.stopped) {
      attempts++;
      const keypair = Keypair.generate();
      const publicKey = keypair.publicKey.toBase58();
      const checkKey = caseSensitive ? publicKey : publicKey.toLowerCase();
      let matches = false;
      if (matchType === "prefix") {
        matches = checkKey.startsWith(searchPattern);
      } else if (matchType === "suffix") {
        matches = checkKey.endsWith(searchPattern);
      } else {
        matches = checkKey.includes(searchPattern);
      }
      if (matches) {
        const timeMs = Date.now() - startTime;
        return {
          publicKey,
          secretKey: bs58.encode(keypair.secretKey),
          attempts,
          timeMs
        };
      }
      if (onProgress && attempts % progressInterval === 0) {
        const timeMs = Date.now() - startTime;
        onProgress(attempts, timeMs);
      }
    }
    return null;
  }
  /**
   * Estimates how long it might take to find a vanity address
   * Based on the pattern length and match type
   */
  static estimateDifficulty(pattern, matchType) {
    const base58Chars = 58;
    let difficulty;
    if (matchType === "prefix" || matchType === "suffix") {
      difficulty = Math.pow(base58Chars, pattern.length);
    } else {
      difficulty = Math.pow(base58Chars, pattern.length) / pattern.length;
    }
    const attemptsPerSec = 1e5;
    const estimatedSeconds = difficulty / attemptsPerSec;
    let estimatedTime;
    if (estimatedSeconds < 1) {
      estimatedTime = "< 1 second";
    } else if (estimatedSeconds < 60) {
      estimatedTime = `~${Math.round(estimatedSeconds)} seconds`;
    } else if (estimatedSeconds < 3600) {
      estimatedTime = `~${Math.round(estimatedSeconds / 60)} minutes`;
    } else if (estimatedSeconds < 86400) {
      estimatedTime = `~${Math.round(estimatedSeconds / 3600)} hours`;
    } else {
      estimatedTime = `~${Math.round(estimatedSeconds / 86400)} days`;
    }
    let estimatedAttempts;
    if (difficulty < 1e3) {
      estimatedAttempts = Math.round(difficulty).toString();
    } else if (difficulty < 1e6) {
      estimatedAttempts = `${(difficulty / 1e3).toFixed(1)}K`;
    } else if (difficulty < 1e9) {
      estimatedAttempts = `${(difficulty / 1e6).toFixed(1)}M`;
    } else {
      estimatedAttempts = `${(difficulty / 1e9).toFixed(1)}B`;
    }
    return {
      difficulty,
      estimatedAttempts,
      estimatedTime
    };
  }
};

// server/routes.ts
init_rpc_balancer();
import { z as z2 } from "zod";
var hasActiveAccess = async (req, res, next) => {
  return next();
};
var isAdmin = async (req, res, next) => {
  if (!req.isAuthenticated() || !req.user?.claims?.sub) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const adminEmails = (process.env.ADMIN_EMAILS || "").split(",").map((e) => e.trim());
  const userEmail = req.user.claims.email;
  if (!adminEmails.includes(userEmail)) {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
};
async function registerRoutes(app2) {
  await setupAuth(app2);
  app2.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  app2.get("/api/rpc/health", (req, res) => {
    const stats = rpcBalancer.getHealthStats();
    res.json({ providers: stats });
  });
  app2.get("/api/subscription/status", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscription = await storage.getSubscription(userId);
      if (!subscription) {
        const trialEndsAt = /* @__PURE__ */ new Date();
        trialEndsAt.setDate(trialEndsAt.getDate() + 7);
        const newSubscription = await storage.createSubscription({
          userId,
          tier: "free_trial",
          status: "trialing",
          // Whop status for trial period
          trialEndsAt,
          currentPeriodEnd: trialEndsAt
        });
        return res.json(newSubscription);
      }
      res.json(subscription);
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });
  app2.get("/api/wallet/status", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user?.claims?.sub) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const userId = req.user.claims.sub;
      const wallet = await storage.getWalletConnection(userId);
      res.json(wallet || null);
    } catch (error) {
      console.error("Error fetching wallet:", error);
      res.status(500).json({ message: "Failed to fetch wallet status" });
    }
  });
  app2.get("/api/wallet/challenge", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const challenge = await storage.createChallenge(userId);
      res.json({
        challenge: challenge.challenge,
        expiresAt: challenge.expiresAt,
        message: "Sign this message with your wallet to prove ownership. This challenge expires in 5 minutes."
      });
    } catch (error) {
      console.error("Error creating challenge:", error);
      res.status(500).json({
        message: "Failed to create challenge: " + error.message
      });
    }
  });
  app2.post("/api/wallet/verify", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { walletAddress, signature, challenge: challengeStr } = req.body;
      const OFFICIAL_TOKEN_MINT = process.env.OFFICIAL_TOKEN_MINT_ADDRESS;
      if (!OFFICIAL_TOKEN_MINT) {
        return res.status(503).json({
          message: "Token gating is not configured yet. Please contact support or use a paid subscription."
        });
      }
      if (!walletAddress) {
        return res.status(400).json({ message: "Wallet address is required" });
      }
      if (!signature || !challengeStr) {
        return res.status(400).json({
          message: "Signature and challenge are required. First call GET /api/wallet/challenge to get a challenge, then sign it with your wallet."
        });
      }
      const challenge = await storage.getChallenge(challengeStr);
      if (!challenge) {
        return res.status(403).json({
          message: "Invalid challenge. Please request a new challenge via GET /api/wallet/challenge."
        });
      }
      if (challenge.userId !== userId) {
        console.warn(`\u274C Challenge mismatch: ${challenge.userId} vs ${userId}`);
        return res.status(403).json({
          message: "Challenge was issued to a different user."
        });
      }
      if (challenge.usedAt) {
        console.warn(`\u274C Challenge already used: ${challengeStr} by user ${userId}`);
        return res.status(403).json({
          message: "This challenge has already been used. Please request a new challenge."
        });
      }
      const now = /* @__PURE__ */ new Date();
      if (challenge.expiresAt < now) {
        console.warn(`\u274C Challenge expired: ${challengeStr} by user ${userId}`);
        return res.status(403).json({
          message: "This challenge has expired. Please request a new challenge."
        });
      }
      const { Connection: Connection7, PublicKey: PublicKey7 } = await import("@solana/web3.js");
      const { getAssociatedTokenAddress, getAccount, getMint: getMint2 } = await import("@solana/spl-token");
      const nacl = await import("tweetnacl");
      const bs583 = await import("bs58");
      const connection = new Connection7(
        process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com",
        "confirmed"
      );
      try {
        const walletPubkey = new PublicKey7(walletAddress);
        const mintPubkey = new PublicKey7(OFFICIAL_TOKEN_MINT);
        const messageBytes = new TextEncoder().encode(challengeStr);
        const signatureBytes = bs583.default.decode(signature);
        const publicKeyBytes = walletPubkey.toBytes();
        const isValidSignature = nacl.default.sign.detached.verify(
          messageBytes,
          signatureBytes,
          publicKeyBytes
        );
        if (!isValidSignature) {
          return res.status(403).json({
            message: "Invalid signature. Please sign the challenge message with the correct wallet."
          });
        }
        await storage.markChallengeUsed(challenge.id);
        const mintInfo = await getMint2(connection, mintPubkey);
        const decimals = mintInfo.decimals;
        const tokenAccount = await getAssociatedTokenAddress(
          mintPubkey,
          walletPubkey
        );
        const accountInfo = await getAccount(connection, tokenAccount);
        const balance = Number(accountInfo.amount) / Math.pow(10, decimals);
        const isEligible = balance >= 1e7;
        const existing = await storage.getWalletByAddress(walletAddress);
        if (existing && existing.userId !== userId) {
          return res.status(403).json({
            message: "This wallet is already connected to another account."
          });
        }
        let wallet;
        if (existing) {
          wallet = await storage.updateWalletBalance(walletAddress, balance, isEligible);
        } else {
          wallet = await storage.createWalletConnection({
            userId,
            walletAddress,
            tokenBalance: balance,
            isEligible
          });
        }
        res.json({
          wallet,
          message: isEligible ? `Congratulations! You hold ${balance.toLocaleString()} tokens and have full access.` : `You hold ${balance.toLocaleString()} tokens. You need 10M+ tokens for access.`
        });
      } catch (error) {
        if (error.message?.includes("could not find account")) {
          return res.status(404).json({
            message: "No token account found for this wallet and token mint. Make sure you're using the correct addresses."
          });
        }
        throw error;
      }
    } catch (error) {
      console.error("Error verifying wallet:", error);
      res.status(500).json({
        message: "Failed to verify wallet: " + error.message
      });
    }
  });
  app2.post("/api/create-subscription", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tier } = req.body;
      if (!tier || !["basic", "premium"].includes(tier)) {
        return res.status(400).json({ message: "Invalid tier. Must be 'basic' or 'premium'" });
      }
      const user = await storage.getUser(userId);
      if (!user?.email) {
        return res.status(400).json({ message: "User email is required" });
      }
      const planId = tier === "individual" ? WHOP_PLAN_IDS.INDIVIDUAL : WHOP_PLAN_IDS.GROUP;
      if (!planId) {
        return res.status(500).json({
          message: `Whop plan ID not configured for ${tier} tier. Set WHOP_PLAN_ID_${tier.toUpperCase()}`
        });
      }
      const checkout = await createWhopCheckout({
        planId,
        userId: user.id,
        userEmail: user.email,
        metadata: { tier }
      });
      res.json({ url: checkout.checkoutUrl, sessionId: checkout.sessionId });
    } catch (error) {
      console.error("Error creating Whop checkout:", error);
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });
  app2.post("/api/cancel-subscription", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscription = await storage.getSubscription(userId);
      if (!subscription?.whopMembershipId) {
        return res.status(400).json({ message: "No active subscription found" });
      }
      const cancelled = await cancelWhopMembership(subscription.whopMembershipId);
      if (cancelled) {
        await storage.updateSubscription(subscription.id, {
          status: "cancelled"
        });
        res.json({ message: "Subscription cancelled successfully" });
      } else {
        res.status(500).json({ message: "Failed to cancel subscription" });
      }
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      res.status(500).json({ message: "Error cancelling subscription: " + error.message });
    }
  });
  app2.post("/api/whop/webhook", async (req, res) => {
    try {
      const event = req.body;
      switch (event.action) {
        case "payment.succeeded": {
          const payment = event.data;
          break;
        }
        case "membership.went_valid": {
          const membership = event.data;
          const whopUserId = membership.user?.id;
          const whopMembershipId = membership.id;
          const planId = membership.plan;
          const validUntil = membership.valid_until ? new Date(membership.valid_until * 1e3) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3);
          const tier = mapPlanToTier(planId);
          const status = mapWhopStatus(membership.status);
          const userId = membership.metadata?.user_id;
          if (userId) {
            const dbSubscription = await storage.getSubscription(userId);
            if (dbSubscription?.tier === "lifetime") {
              break;
            }
            if (dbSubscription) {
              await storage.updateSubscription(dbSubscription.id, {
                tier,
                status,
                whopMembershipId,
                whopPlanId: planId,
                currentPeriodEnd: validUntil
              });
            } else {
              await storage.createSubscription({
                userId,
                tier,
                status,
                whopMembershipId,
                whopPlanId: planId,
                currentPeriodEnd: validUntil
              });
            }
          }
          break;
        }
        case "membership.went_invalid": {
          const membership = event.data;
          const whopMembershipId = membership.id;
          const dbSubscription = await storage.getSubscriptionByWhopId(whopMembershipId);
          if (dbSubscription?.tier === "lifetime") {
            break;
          }
          if (dbSubscription) {
            await storage.updateSubscription(dbSubscription.id, {
              status: "expired"
            });
          }
          break;
        }
      }
      res.sendStatus(200);
    } catch (error) {
      console.error("Whop webhook error:", error);
      res.status(500).send("Webhook processing failed");
    }
  });
  const cryptoPayments = await Promise.resolve().then(() => (init_crypto_payments(), crypto_payments_exports));
  app2.post("/api/create-crypto-payment", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { chain, tier } = req.body;
      if (!chain || chain !== "SOL") {
        return res.status(400).json({
          message: "Only SOL payments are currently supported. ETH and BTC coming soon!",
          supported_chains: ["SOL"]
        });
      }
      if (!process.env.PHANTOM_WALLET_ADDRESS) {
        console.error("PHANTOM_WALLET_ADDRESS not configured!");
        return res.status(503).json({
          message: "Crypto payments are currently unavailable. Please use Whop subscription instead or contact support."
        });
      }
      if (!tier || !["basic", "premium"].includes(tier)) {
        return res.status(400).json({ message: "Invalid tier. Must be 'basic' or 'premium'" });
      }
      const result = await cryptoPayments.generatePaymentAddress(userId, chain, tier);
      res.json({
        paymentId: result.payment.id,
        address: result.cryptoAddress.address,
        amount: result.amountToPay,
        chain,
        tier,
        expiresAt: result.expiresAt
      });
    } catch (error) {
      console.error("Error creating crypto payment:", error);
      res.status(500).json({ message: "Error creating crypto payment: " + error.message });
    }
  });
  app2.get("/api/crypto-payment/:paymentId", isAuthenticated, async (req, res) => {
    try {
      const { paymentId } = req.params;
      const payment = await cryptoPayments.getPaymentStatus(paymentId);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      res.json(payment);
    } catch (error) {
      console.error("Error fetching payment status:", error);
      res.status(500).json({ message: "Error fetching payment status: " + error.message });
    }
  });
  app2.post("/api/crypto-payment/:paymentId/check", isAuthenticated, async (req, res) => {
    try {
      const { paymentId } = req.params;
      const payment = await cryptoPayments.checkSolPayment(paymentId);
      res.json(payment);
    } catch (error) {
      console.error("Error checking payment:", error);
      res.status(500).json({ message: "Error checking payment: " + error.message });
    }
  });
  app2.get("/api/bot/invite-links", async (req, res) => {
    try {
      const links = {
        message: "You have access to premium bot features!"
      };
      const telegramToken = process.env.TELEGRAM_BOT_TOKEN;
      if (telegramToken) {
        links.telegram = process.env.TELEGRAM_BOT_URL || `https://t.me/YOUR_BOT_USERNAME`;
      }
      const discordClientId = process.env.DISCORD_CLIENT_ID;
      if (discordClientId) {
        const permissions = "2147502080";
        links.discord = `https://discord.com/api/oauth2/authorize?client_id=${discordClientId}&permissions=${permissions}&scope=bot%20applications.commands`;
      }
      if (!links.telegram && !links.discord) {
        return res.status(503).json({
          message: "Bot services are not configured yet. Please contact support."
        });
      }
      res.json(links);
    } catch (error) {
      console.error("Error getting bot invite links:", error);
      res.status(500).json({
        message: "Failed to get bot invite links: " + error.message
      });
    }
  });
  const blacklist = await Promise.resolve().then(() => (init_ai_blacklist(), ai_blacklist_exports));
  app2.get("/api/blacklist/check/:wallet", async (req, res) => {
    try {
      const { wallet } = req.params;
      const result = await blacklist.checkBlacklist(wallet);
      res.json(result);
    } catch (error) {
      console.error("Error checking blacklist:", error);
      res.status(500).json({ message: "Error checking blacklist: " + error.message });
    }
  });
  app2.post("/api/blacklist/report", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { walletAddress, reportType, evidence } = req.body;
      if (!walletAddress || !reportType || !evidence) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      await blacklist.reportWallet(walletAddress, reportType, evidence, userId);
      res.json({ message: "Report submitted successfully" });
    } catch (error) {
      console.error("Error reporting wallet:", error);
      res.status(500).json({ message: "Error reporting wallet: " + error.message });
    }
  });
  app2.get("/api/blacklist/stats", async (req, res) => {
    try {
      const stats = await blacklist.getBlacklistStats();
      res.json(stats);
    } catch (error) {
      console.error("Error getting blacklist stats:", error);
      res.status(500).json({ message: "Error getting blacklist stats: " + error.message });
    }
  });
  app2.get("/api/blacklist/top", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 100;
      const wallets = await blacklist.getTopFlaggedWallets(limit);
      res.json(wallets);
    } catch (error) {
      console.error("Error getting top flagged wallets:", error);
      res.status(500).json({ message: "Error getting top flagged wallets: " + error.message });
    }
  });
  app2.get("/api/watchlist", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const watchlist = await storage.getWatchlist(userId);
      res.json(watchlist);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      res.status(500).json({ message: "Failed to fetch watchlist: " + error.message });
    }
  });
  app2.post("/api/watchlist", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = insertWatchlistSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid request",
          errors: result.error.errors
        });
      }
      const { tokenAddress, label } = result.data;
      const entry = await storage.addToWatchlist({
        userId,
        tokenAddress,
        label,
        metadata: null
      });
      res.status(201).json(entry);
    } catch (error) {
      console.error("Error adding to watchlist:", error);
      if (error.message?.includes("unique constraint") || error.code === "23505") {
        return res.status(409).json({
          message: "This token is already in your watchlist"
        });
      }
      res.status(500).json({
        message: "Failed to add to watchlist: " + error.message
      });
    }
  });
  app2.delete("/api/watchlist/:tokenAddress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tokenAddress } = req.params;
      if (!tokenAddress || tokenAddress.length < 32 || tokenAddress.length > 44) {
        return res.status(400).json({
          message: "Invalid token address"
        });
      }
      await storage.removeFromWatchlist(userId, tokenAddress);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing from watchlist:", error);
      res.status(500).json({
        message: "Failed to remove from watchlist: " + error.message
      });
    }
  });
  app2.get("/api/prices/:tokenAddress", async (req, res) => {
    try {
      const { priceService: priceService2 } = await Promise.resolve().then(() => (init_price_service(), price_service_exports));
      const { tokenAddress } = req.params;
      const price = await priceService2.getPrice(tokenAddress);
      if (!price) {
        return res.status(404).json({
          message: "Price not found for this token"
        });
      }
      res.json(price);
    } catch (error) {
      console.error("Error fetching price:", error);
      res.status(500).json({
        message: "Failed to fetch price: " + error.message
      });
    }
  });
  app2.post("/api/prices/batch", async (req, res) => {
    try {
      const { priceService: priceService2 } = await Promise.resolve().then(() => (init_price_service(), price_service_exports));
      const { tokenAddresses } = req.body;
      if (!Array.isArray(tokenAddresses)) {
        return res.status(400).json({
          message: "tokenAddresses must be an array"
        });
      }
      if (tokenAddresses.length > 100) {
        return res.status(400).json({
          message: "Maximum 100 tokens per request"
        });
      }
      const prices = await priceService2.getPrices(tokenAddresses);
      const pricesObject = {};
      for (const [address, price] of Array.from(prices.entries())) {
        pricesObject[address] = price;
      }
      res.json(pricesObject);
    } catch (error) {
      console.error("Error fetching batch prices:", error);
      res.status(500).json({
        message: "Failed to fetch prices: " + error.message
      });
    }
  });
  app2.get("/api/analytics/market-overview", async (req, res) => {
    try {
      const { priceCache: priceCache2 } = await Promise.resolve().then(() => (init_price_cache(), price_cache_exports));
      const { getBlacklist: getBlacklist2 } = await Promise.resolve().then(() => (init_ai_blacklist(), ai_blacklist_exports));
      const trending = await storage.getTrendingTokens(10);
      const recentTokens = priceCache2.getRecentlyUpdated(60);
      const totalAnalyzed = recentTokens.length;
      const blacklist2 = await getBlacklist2();
      const rugsDetected = blacklist2.length;
      let avgRiskScore = 0;
      if (trending.length > 0) {
        const riskScores = await Promise.all(
          trending.slice(0, 5).map(async (t) => {
            const snapshots = await storage.getHistoricalData(t.tokenAddress, 1);
            return snapshots.length > 0 ? snapshots[snapshots.length - 1].riskScore : 0;
          })
        );
        avgRiskScore = Math.round(riskScores.reduce((a, b) => a + b, 0) / riskScores.length);
      }
      const activeAlerts = await storage.getActivePriceAlerts();
      res.json({
        totalAnalyzed,
        rugsDetected,
        avgRiskScore,
        activeAlerts: activeAlerts.length,
        trending: trending.map((t) => ({
          tokenAddress: t.tokenAddress,
          score: parseFloat(t.score),
          rank: t.rank,
          volume24h: t.volume24h ? parseFloat(t.volume24h) : null,
          velocity: t.velocity ? parseFloat(t.velocity) : null
        }))
      });
    } catch (error) {
      console.error("Error fetching market overview:", error);
      res.status(500).json({ message: "Failed to fetch market overview: " + error.message });
    }
  });
  app2.get("/api/analytics/historical/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const days = parseInt(req.query.days) || 7;
      if (!tokenAddress || tokenAddress.length < 32 || tokenAddress.length > 44) {
        return res.status(400).json({ message: "Invalid token address" });
      }
      if (days < 1 || days > 90) {
        return res.status(400).json({ message: "Days must be between 1 and 90" });
      }
      const historical = await storage.getHistoricalData(tokenAddress, days);
      res.json({
        tokenAddress,
        days,
        dataPoints: historical.length,
        data: historical.map((h) => ({
          timestamp: h.capturedAt,
          priceUsd: h.priceUsd ? parseFloat(h.priceUsd) : null,
          riskScore: h.riskScore,
          holderCount: h.holderCount,
          volume24h: h.volume24h ? parseFloat(h.volume24h) : null,
          liquidityUsd: h.liquidityUsd ? parseFloat(h.liquidityUsd) : null,
          riskFlags: h.riskFlags,
          txCount24h: h.txCount24h
        }))
      });
    } catch (error) {
      console.error("Error fetching historical data:", error);
      res.status(500).json({ message: "Failed to fetch historical data: " + error.message });
    }
  });
  app2.get("/api/analytics/risk-insights", async (req, res) => {
    try {
      const stats7d = await storage.getRiskStatistics(7);
      const stats30d = await storage.getRiskStatistics(30);
      res.json({
        last7Days: stats7d ? {
          totalAnalyzed: stats7d.totalAnalyzed,
          rugDetected: stats7d.rugDetected,
          falsePositives: stats7d.falsePositives,
          detectionRate: stats7d.totalAnalyzed > 0 ? (stats7d.rugDetected / stats7d.totalAnalyzed * 100).toFixed(2) : 0,
          commonFlags: stats7d.commonFlags
        } : null,
        last30Days: stats30d ? {
          totalAnalyzed: stats30d.totalAnalyzed,
          rugDetected: stats30d.rugDetected,
          falsePositives: stats30d.falsePositives,
          detectionRate: stats30d.totalAnalyzed > 0 ? (stats30d.rugDetected / stats30d.totalAnalyzed * 100).toFixed(2) : 0,
          commonFlags: stats30d.commonFlags
        } : null
      });
    } catch (error) {
      console.error("Error fetching risk insights:", error);
      res.status(500).json({ message: "Failed to fetch risk insights: " + error.message });
    }
  });
  app2.get("/api/analytics/hot-tokens", async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit) || 20, 50);
      const trending = await storage.getTrendingTokens(limit);
      const { priceService: priceService2 } = await Promise.resolve().then(() => (init_price_service(), price_service_exports));
      const enriched = await Promise.all(
        trending.map(async (t) => {
          const priceData = await priceService2.getPrice(t.tokenAddress);
          const snapshots = await storage.getHistoricalData(t.tokenAddress, 1);
          const latestSnapshot = snapshots.length > 0 ? snapshots[snapshots.length - 1] : null;
          return {
            tokenAddress: t.tokenAddress,
            score: parseFloat(t.score),
            rank: t.rank,
            volume24h: t.volume24h ? parseFloat(t.volume24h) : null,
            velocity: t.velocity ? parseFloat(t.velocity) : null,
            priceUsd: priceData?.priceUsd || null,
            priceChange24h: priceData?.priceChange24h || null,
            riskScore: latestSnapshot?.riskScore || null,
            updatedAt: t.updatedAt
          };
        })
      );
      res.json(enriched);
    } catch (error) {
      console.error("Error fetching hot tokens:", error);
      res.status(500).json({ message: "Failed to fetch hot tokens: " + error.message });
    }
  });
  app2.get("/api/analytics/performance", async (req, res) => {
    try {
      const stats7d = await storage.getRiskStatistics(7);
      const stats30d = await storage.getRiskStatistics(30);
      const performance = {
        last7Days: stats7d ? {
          detectionRate: stats7d.totalAnalyzed > 0 ? (stats7d.rugDetected / stats7d.totalAnalyzed * 100).toFixed(2) : "0.00",
          falsePositiveRate: stats7d.totalAnalyzed > 0 ? (stats7d.falsePositives / stats7d.totalAnalyzed * 100).toFixed(2) : "0.00",
          coverage: stats7d.totalAnalyzed,
          avgAnalysisTime: "~2s"
          // Static for now
        } : null,
        last30Days: stats30d ? {
          detectionRate: stats30d.totalAnalyzed > 0 ? (stats30d.rugDetected / stats30d.totalAnalyzed * 100).toFixed(2) : "0.00",
          falsePositiveRate: stats30d.totalAnalyzed > 0 ? (stats30d.falsePositives / stats30d.totalAnalyzed * 100).toFixed(2) : "0.00",
          coverage: stats30d.totalAnalyzed,
          avgAnalysisTime: "~2s"
          // Static for now
        } : null
      };
      res.json(performance);
    } catch (error) {
      console.error("Error fetching performance metrics:", error);
      res.status(500).json({ message: "Failed to fetch performance metrics: " + error.message });
    }
  });
  app2.get("/api/portfolio/positions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const positions = await storage.getPortfolioPositions(userId);
      res.json(positions);
    } catch (error) {
      console.error("Error fetching portfolio:", error);
      res.status(500).json({ message: "Failed to fetch portfolio: " + error.message });
    }
  });
  app2.post("/api/portfolio/transactions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { insertPortfolioTransactionSchema: insertPortfolioTransactionSchema2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const result = insertPortfolioTransactionSchema2.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid request",
          errors: result.error.errors
        });
      }
      const { tokenAddress, txType, quantity, priceUsd, feeUsd, note, executedAt } = result.data;
      const txResult = await storage.recordTransaction(userId, {
        tokenAddress,
        txType,
        quantity: String(quantity),
        priceUsd: priceUsd !== void 0 ? String(priceUsd) : void 0,
        feeUsd: feeUsd !== void 0 ? String(feeUsd) : void 0,
        note,
        executedAt: executedAt ? new Date(executedAt) : /* @__PURE__ */ new Date()
      });
      res.status(201).json(txResult);
    } catch (error) {
      console.error("Error recording transaction:", error);
      if (error.message?.includes("Insufficient holdings") || error.message?.includes("negative quantity")) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to record transaction: " + error.message });
    }
  });
  app2.get("/api/portfolio/transactions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const tokenAddress = req.query.tokenAddress;
      const transactions = await storage.getTransactionHistory(userId, tokenAddress);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions: " + error.message });
    }
  });
  app2.delete("/api/portfolio/positions/:tokenAddress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tokenAddress } = req.params;
      await storage.deletePosition(userId, tokenAddress);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting position:", error);
      res.status(500).json({ message: "Failed to delete position: " + error.message });
    }
  });
  app2.get("/api/alerts", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const alerts = await storage.getPriceAlerts(userId);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts: " + error.message });
    }
  });
  app2.post("/api/alerts", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { insertPriceAlertSchema: insertPriceAlertSchema2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const result = insertPriceAlertSchema2.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          message: "Invalid request",
          errors: result.error.errors
        });
      }
      const { tokenAddress, alertType, targetValue, lookbackWindowMinutes } = result.data;
      const alert = await storage.createPriceAlert({
        userId,
        tokenAddress,
        alertType,
        targetValue: typeof targetValue === "number" ? targetValue.toString() : targetValue,
        lookbackWindowMinutes,
        isActive: true,
        lastPrice: null,
        triggeredAt: null,
        cancelledAt: null
      });
      res.status(201).json(alert);
    } catch (error) {
      console.error("Error creating alert:", error);
      if (error.message?.includes("unique constraint") || error.code === "23505") {
        return res.status(409).json({
          message: "You already have this alert configured"
        });
      }
      res.status(500).json({ message: "Failed to create alert: " + error.message });
    }
  });
  app2.patch("/api/alerts/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const { isActive } = req.body;
      const alerts = await storage.getPriceAlerts(userId);
      if (!alerts.find((a) => a.id === id)) {
        return res.status(404).json({ message: "Alert not found" });
      }
      const updated = await storage.updatePriceAlert(id, { isActive });
      res.json(updated);
    } catch (error) {
      console.error("Error updating alert:", error);
      res.status(500).json({ message: "Failed to update alert: " + error.message });
    }
  });
  app2.delete("/api/alerts/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      await storage.deletePriceAlert(userId, id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting alert:", error);
      res.status(500).json({ message: "Failed to delete alert: " + error.message });
    }
  });
  app2.post("/api/analyze-token", hasActiveAccess, async (req, res) => {
    try {
      const result = analyzeTokenSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          error: "Invalid request",
          details: result.error.errors
        });
      }
      const { tokenAddress } = result.data;
      const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
      const userId = req.user?.claims?.sub;
      blacklist.analyzeAndFlag(analysis, userId).catch((err) => {
        console.error("Background blacklist analysis error:", err);
      });
      const blacklistChecks = await Promise.all([
        analysis.mintAuthority.authorityAddress ? blacklist.checkBlacklist(analysis.mintAuthority.authorityAddress) : Promise.resolve({ isBlacklisted: false, severity: 0, labels: [], warnings: [] }),
        analysis.freezeAuthority.authorityAddress ? blacklist.checkBlacklist(analysis.freezeAuthority.authorityAddress) : Promise.resolve({ isBlacklisted: false, severity: 0, labels: [], warnings: [] }),
        blacklist.checkBlacklist(tokenAddress)
      ]);
      const responseWithBlacklist = {
        ...analysis,
        blacklistInfo: {
          mintAuthority: blacklistChecks[0],
          freezeAuthority: blacklistChecks[1],
          token: blacklistChecks[2]
        }
      };
      return res.json(responseWithBlacklist);
    } catch (error) {
      console.error("Token analysis error:", error);
      return res.status(500).json({
        error: "Analysis failed",
        message: error instanceof Error ? error.message : "Unknown error occurred"
      });
    }
  });
  const compareTokensSchema = z2.object({
    tokenAddresses: z2.array(z2.string().min(32).max(44)).min(2).max(5)
  });
  app2.post("/api/compare-tokens", async (req, res) => {
    try {
      const result = compareTokensSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({
          error: "Invalid request",
          details: result.error.errors,
          message: "Please provide 2-5 valid token addresses"
        });
      }
      const { tokenAddresses } = result.data;
      const analysisPromises = tokenAddresses.map(async (tokenAddress) => {
        try {
          const analysis = await tokenAnalyzer.analyzeToken(tokenAddress);
          const userId = req.user?.claims?.sub;
          if (userId) {
            blacklist.analyzeAndFlag(analysis, userId).catch((err) => {
              console.error("Background blacklist analysis error:", err);
            });
          }
          const blacklistChecks = await Promise.all([
            analysis.mintAuthority.authorityAddress ? blacklist.checkBlacklist(analysis.mintAuthority.authorityAddress) : Promise.resolve({ isBlacklisted: false, severity: 0, labels: [], warnings: [] }),
            analysis.freezeAuthority.authorityAddress ? blacklist.checkBlacklist(analysis.freezeAuthority.authorityAddress) : Promise.resolve({ isBlacklisted: false, severity: 0, labels: [], warnings: [] }),
            blacklist.checkBlacklist(tokenAddress)
          ]);
          return {
            ...analysis,
            blacklistInfo: {
              mintAuthority: blacklistChecks[0],
              freezeAuthority: blacklistChecks[1],
              token: blacklistChecks[2]
            }
          };
        } catch (error) {
          console.error(`Error analyzing token ${tokenAddress}:`, error);
          return {
            tokenAddress,
            error: true,
            message: error instanceof Error ? error.message : "Analysis failed"
          };
        }
      });
      const results = await Promise.all(analysisPromises);
      return res.json({
        comparisons: results,
        comparedAt: Date.now()
      });
    } catch (error) {
      console.error("Token comparison error:", error);
      return res.status(500).json({
        error: "Comparison failed",
        message: error instanceof Error ? error.message : "Unknown error occurred"
      });
    }
  });
  const redeemCodeSchema = z2.object({
    code: z2.string().min(1).max(50).trim().toUpperCase()
  });
  app2.post("/api/redeem-code", isAuthenticated, async (req, res) => {
    try {
      const { code } = redeemCodeSchema.parse(req.body);
      const userId = req.user.claims.sub;
      const result = await storage.redeemCode(userId, code);
      if (!result.success) {
        return res.status(400).json({ message: result.message });
      }
      return res.json({
        message: result.message,
        subscription: result.subscription
      });
    } catch (error) {
      console.error("Code redemption error:", error);
      return res.status(500).json({
        error: "Redemption failed",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  const vanityEstimateSchema = z2.object({
    pattern: z2.string().min(1).max(10),
    matchType: z2.enum(["prefix", "suffix", "contains"])
  });
  app2.post("/api/vanity/estimate", isAuthenticated, async (req, res) => {
    try {
      const { pattern, matchType } = vanityEstimateSchema.parse(req.body);
      const estimate = VanityAddressGenerator.estimateDifficulty(pattern, matchType);
      return res.json(estimate);
    } catch (error) {
      console.error("Vanity estimate error:", error);
      return res.status(400).json({
        error: "Invalid request",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  const vanityGenerateSchema = z2.object({
    pattern: z2.string().min(1).max(10),
    matchType: z2.enum(["prefix", "suffix", "contains"]),
    caseSensitive: z2.boolean().optional(),
    maxAttempts: z2.number().min(1e3).max(5e7).optional()
  });
  app2.post("/api/vanity/generate", isAuthenticated, async (req, res) => {
    try {
      const options = vanityGenerateSchema.parse(req.body);
      const generator = new VanityAddressGenerator();
      const timeout = setTimeout(() => {
        generator.stop();
      }, 6e4);
      const result = await generator.generate(options);
      clearTimeout(timeout);
      if (!result) {
        return res.status(404).json({
          error: "No match found",
          message: `Could not find a matching address within ${options.maxAttempts || 1e7} attempts`
        });
      }
      return res.json(result);
    } catch (error) {
      console.error("Vanity generation error:", error);
      return res.status(500).json({
        error: "Generation failed",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  app2.post("/api/comments", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { socialService: socialService2 } = await Promise.resolve().then(() => (init_social_service(), social_service_exports));
      const rateLimit = await socialService2.checkRateLimit(userId, "comment");
      if (!rateLimit.allowed) {
        return res.status(429).json({
          message: `Rate limit exceeded. Please wait before commenting again.`,
          remaining: rateLimit.remaining
        });
      }
      const { tokenAddress, content, rating } = req.body;
      if (!tokenAddress || !content) {
        return res.status(400).json({ message: "Token address and content required" });
      }
      const sanitizedContent = socialService2.sanitizeContent(content);
      const isSpam = await socialService2.detectSpam(sanitizedContent);
      if (isSpam) {
        return res.status(400).json({ message: "Content flagged as spam" });
      }
      const comment = await storage.createComment({
        userId,
        tokenAddress,
        commentText: sanitizedContent,
        rating: rating || null
      });
      await socialService2.awardPoints(userId, "comment", 5, tokenAddress);
      res.json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });
  app2.get("/api/comments/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const comments = await storage.getCommentsByToken(tokenAddress);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });
  app2.get("/api/comments/flagged", isAdmin, async (req, res) => {
    try {
      const comments = await storage.getFlaggedComments();
      res.json(comments);
    } catch (error) {
      console.error("Error fetching flagged comments:", error);
      res.status(500).json({ message: "Failed to fetch flagged comments" });
    }
  });
  app2.post("/api/comments/:id/vote", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const { voteType } = req.body;
      if (!["upvote", "downvote"].includes(voteType)) {
        return res.status(400).json({ message: "Invalid vote type" });
      }
      const existingVote = await storage.getUserCommentVote(userId, id);
      if (existingVote) {
        if (existingVote.voteType === voteType) {
          await storage.removeCommentVote(userId, id);
        } else {
          await storage.removeCommentVote(userId, id);
          await storage.voteComment({ userId, commentId: id, voteType });
        }
      } else {
        await storage.voteComment({ userId, commentId: id, voteType });
      }
      await storage.updateCommentVoteCounts(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error voting on comment:", error);
      res.status(500).json({ message: "Failed to vote on comment" });
    }
  });
  app2.delete("/api/comments/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      await storage.deleteComment(id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });
  app2.post("/api/comments/:id/flag", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const comment = await storage.flagComment(id);
      res.json(comment);
    } catch (error) {
      console.error("Error flagging comment:", error);
      res.status(500).json({ message: "Failed to flag comment" });
    }
  });
  app2.post("/api/community-votes", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { socialService: socialService2 } = await Promise.resolve().then(() => (init_social_service(), social_service_exports));
      const rateLimit = await socialService2.checkRateLimit(userId, "vote");
      if (!rateLimit.allowed) {
        return res.status(429).json({
          message: `Rate limit exceeded. ${rateLimit.remaining} votes remaining.`,
          remaining: rateLimit.remaining
        });
      }
      const { tokenAddress, voteType, confidence } = req.body;
      if (!tokenAddress || !voteType) {
        return res.status(400).json({ message: "Token address and vote type required" });
      }
      if (!["safe", "risky", "scam"].includes(voteType)) {
        return res.status(400).json({ message: "Invalid vote type" });
      }
      const existingVote = await storage.getUserCommunityVote(tokenAddress, userId);
      if (existingVote) {
        const updated = await storage.updateCommunityVote(existingVote.id, {
          voteType,
          confidence: confidence || 50
        });
        await socialService2.aggregateVotes(tokenAddress);
        return res.json(updated);
      }
      const vote = await storage.createCommunityVote({
        userId,
        tokenAddress,
        voteType,
        confidence: confidence || 50
      });
      await socialService2.awardPoints(userId, "vote", 2, tokenAddress);
      await socialService2.aggregateVotes(tokenAddress);
      res.json(vote);
    } catch (error) {
      console.error("Error submitting vote:", error);
      res.status(500).json({ message: "Failed to submit vote" });
    }
  });
  app2.get("/api/community-votes/:tokenAddress/summary", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const summary = await storage.getCommunityVoteSummary(tokenAddress);
      res.json(summary || null);
    } catch (error) {
      console.error("Error fetching vote summary:", error);
      res.status(500).json({ message: "Failed to fetch vote summary" });
    }
  });
  app2.put("/api/community-votes/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { voteType, confidence } = req.body;
      const updated = await storage.updateCommunityVote(id, {
        voteType,
        confidence
      });
      res.json(updated);
    } catch (error) {
      console.error("Error updating vote:", error);
      res.status(500).json({ message: "Failed to update vote" });
    }
  });
  app2.delete("/api/community-votes/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      await storage.deleteCommunityVote(id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting vote:", error);
      res.status(500).json({ message: "Failed to delete vote" });
    }
  });
  app2.get("/api/profile/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });
  app2.put("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { socialService: socialService2 } = await Promise.resolve().then(() => (init_social_service(), social_service_exports));
      const { username, bio, visibility } = req.body;
      const sanitizedBio = bio ? socialService2.sanitizeContent(bio) : void 0;
      let profile = await storage.getUserProfile(userId);
      if (!profile) {
        profile = await storage.createUserProfile({
          userId,
          username: username || null,
          bio: sanitizedBio || null,
          visibility: visibility || "public",
          reputationScore: 0,
          contributionCount: 0
        });
      } else {
        profile = await storage.updateUserProfile(userId, {
          username,
          bio: sanitizedBio,
          visibility
        });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  app2.get("/api/profile/:userId/activities", async (req, res) => {
    try {
      const { userId } = req.params;
      const limit = parseInt(req.query.limit) || 50;
      const activities = await storage.getUserActivities(userId, limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });
  app2.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 50;
      const users2 = await storage.getTopUsers(limit);
      res.json(users2);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });
  app2.post("/api/watchlists/share", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { socialService: socialService2 } = await Promise.resolve().then(() => (init_social_service(), social_service_exports));
      const { name, description, tokenAddresses, isPublic } = req.body;
      if (!name || !tokenAddresses || !Array.isArray(tokenAddresses)) {
        return res.status(400).json({ message: "Name and token addresses required" });
      }
      const slug = socialService2.generateShareSlug();
      const sanitizedDescription = description ? socialService2.sanitizeContent(description) : null;
      const sharedWatchlist = await storage.createSharedWatchlist({
        ownerId: userId,
        name,
        description: sanitizedDescription,
        shareSlug: slug,
        isPublic: isPublic !== void 0 ? isPublic : true,
        followersCount: 0
      });
      res.json(sharedWatchlist);
    } catch (error) {
      console.error("Error sharing watchlist:", error);
      res.status(500).json({ message: "Failed to share watchlist" });
    }
  });
  app2.get("/api/watchlists/shared/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const watchlist = await storage.getSharedWatchlistBySlug(slug);
      if (!watchlist) {
        return res.status(404).json({ message: "Watchlist not found" });
      }
      if (!watchlist.isPublic) {
        return res.status(403).json({ message: "This watchlist is private" });
      }
      res.json(watchlist);
    } catch (error) {
      console.error("Error fetching shared watchlist:", error);
      res.status(500).json({ message: "Failed to fetch watchlist" });
    }
  });
  app2.post("/api/watchlists/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const follower = await storage.followWatchlist(userId, id);
      res.json(follower);
    } catch (error) {
      console.error("Error following watchlist:", error);
      res.status(500).json({ message: "Failed to follow watchlist" });
    }
  });
  app2.delete("/api/watchlists/:id/unfollow", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      await storage.unfollowWatchlist(userId, id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unfollowing watchlist:", error);
      res.status(500).json({ message: "Failed to unfollow watchlist" });
    }
  });
  app2.get("/api/watchlists/following", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const watchlists = await storage.getFollowedWatchlists(userId);
      res.json(watchlists);
    } catch (error) {
      console.error("Error fetching followed watchlists:", error);
      res.status(500).json({ message: "Failed to fetch followed watchlists" });
    }
  });
  app2.get("/api/watchlists/public", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 20;
      const watchlists = await storage.getPublicWatchlists(limit);
      res.json(watchlists);
    } catch (error) {
      console.error("Error fetching public watchlists:", error);
      res.status(500).json({ message: "Failed to fetch public watchlists" });
    }
  });
  app2.post("/api/reports", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { socialService: socialService2 } = await Promise.resolve().then(() => (init_social_service(), social_service_exports));
      const rateLimit = await socialService2.checkRateLimit(userId, "report");
      if (!rateLimit.allowed) {
        return res.status(429).json({
          message: `Rate limit exceeded. ${rateLimit.remaining} reports remaining.`,
          remaining: rateLimit.remaining
        });
      }
      const { tokenAddress, reportType, evidence, severity } = req.body;
      if (!tokenAddress || !reportType || !evidence) {
        return res.status(400).json({ message: "Token address, report type, and evidence required" });
      }
      if (!["scam", "honeypot", "soft_rug", "other"].includes(reportType)) {
        return res.status(400).json({ message: "Invalid report type" });
      }
      const sanitizedEvidence = socialService2.sanitizeContent(evidence);
      const report = await storage.createTokenReport({
        reporterId: userId,
        tokenAddress,
        reportType,
        evidence: sanitizedEvidence,
        severityScore: severity || 3,
        status: "pending"
      });
      await socialService2.awardPoints(userId, "report", 10, tokenAddress);
      res.json(report);
    } catch (error) {
      console.error("Error submitting report:", error);
      res.status(500).json({ message: "Failed to submit report" });
    }
  });
  app2.get("/api/reports/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const reports = await storage.getTokenReports(tokenAddress);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });
  app2.put("/api/reports/:id/review", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { status, resolutionNotes } = req.body;
      if (!["pending", "approved", "dismissed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      const report = await storage.updateTokenReport(id, {
        status,
        resolutionNotes
      });
      res.json(report);
    } catch (error) {
      console.error("Error reviewing report:", error);
      res.status(500).json({ message: "Failed to review report" });
    }
  });
  app2.get("/api/reports/pending", isAdmin, async (req, res) => {
    try {
      const reports = await storage.getPendingReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching pending reports:", error);
      res.status(500).json({ message: "Failed to fetch pending reports" });
    }
  });
  app2.get("/api/share/preview/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const baseUrl = process.env.REPL_SLUG ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co` : "http://localhost:5000";
      const preview = {
        url: `${baseUrl}/?token=${tokenAddress}`,
        title: `Solana Rug Killer - Token Analysis`,
        description: `Analyze ${tokenAddress} for rug pull risks`,
        image: `${baseUrl}/favicon.png`
      };
      res.json(preview);
    } catch (error) {
      console.error("Error generating preview:", error);
      res.status(500).json({ message: "Failed to generate preview" });
    }
  });
  app2.get("/api/share/twitter/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const baseUrl = process.env.REPL_SLUG ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co` : "http://localhost:5000";
      const url = `${baseUrl}/?token=${tokenAddress}`;
      const text2 = `Check out this token analysis on Solana Rug Killer`;
      const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text2)}&url=${encodeURIComponent(url)}`;
      res.json({ url: twitterUrl });
    } catch (error) {
      console.error("Error generating Twitter URL:", error);
      res.status(500).json({ message: "Failed to generate Twitter URL" });
    }
  });
  app2.get("/api/share/telegram/:tokenAddress", async (req, res) => {
    try {
      const { tokenAddress } = req.params;
      const baseUrl = process.env.REPL_SLUG ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co` : "http://localhost:5000";
      const url = `${baseUrl}/?token=${tokenAddress}`;
      const text2 = `Check out this token analysis on Solana Rug Killer`;
      const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text2)}`;
      res.json({ url: telegramUrl });
    } catch (error) {
      console.error("Error generating Telegram URL:", error);
      res.status(500).json({ message: "Failed to generate Telegram URL" });
    }
  });
  app2.get("/api/admin/check", isAuthenticated, async (req, res) => {
    const adminEmails = (process.env.ADMIN_EMAILS || "").split(",").map((e) => e.trim());
    const userEmail = req.user.claims.email;
    res.json({ isAdmin: adminEmails.includes(userEmail) });
  });
  app2.get("/api/admin/creator-wallet", isAdmin, async (req, res) => {
    try {
      const { getCreatorWallet: getCreatorWallet2 } = await Promise.resolve().then(() => (init_creator_wallet(), creator_wallet_exports));
      const wallet = getCreatorWallet2();
      const info = await wallet.getWalletInfo();
      res.json({
        publicKey: info.publicKey,
        balance: info.balance,
        isConfigured: info.isConfigured,
        pumpFunUrl: info.publicKey ? `https://pump.fun/profile/${info.publicKey}` : null
      });
    } catch (error) {
      console.error("Error fetching creator wallet:", error);
      res.status(500).json({ message: "Failed to fetch creator wallet" });
    }
  });
  app2.post("/api/admin/creator-wallet/generate", isAdmin, async (req, res) => {
    try {
      const { CreatorWalletService: CreatorWalletService2 } = await Promise.resolve().then(() => (init_creator_wallet(), creator_wallet_exports));
      const newWallet = CreatorWalletService2.generateNewWallet();
      res.json({
        publicKey: newWallet.publicKey,
        privateKey: newWallet.privateKey,
        warning: "SAVE THIS PRIVATE KEY IMMEDIATELY! Import it into Phantom wallet. It will never be shown again.",
        nextSteps: [
          "1. Copy the private key above",
          "2. Open Phantom wallet \u2192 Settings \u2192 Import Private Key",
          "3. Paste the private key",
          "4. Add CREATOR_WALLET_PRIVATE_KEY to Replit Secrets",
          "5. Restart the application",
          "6. Use this wallet to create tokens on pump.fun"
        ]
      });
    } catch (error) {
      console.error("Error generating creator wallet:", error);
      res.status(500).json({ message: "Failed to generate wallet" });
    }
  });
  app2.post("/api/admin/token/deploy", isAdmin, async (req, res) => {
    res.status(501).json({
      message: "Token deployment feature is not yet implemented. Please use Solana CLI or other tools for now."
    });
  });
  app2.get("/api/admin/token/info/:mintAddress", isAdmin, async (req, res) => {
    res.status(501).json({
      message: "Token info feature is not yet implemented."
    });
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      ),
      await import("@replit/vite-plugin-dev-banner").then(
        (m) => m.devBanner()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid as nanoid2 } from "nanoid";
var viteLogger = createLogger();
function log(message2, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message2}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid2()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_BOT_TOKEN !== "PLACEHOLDER_TOKEN") {
    const { startTelegramBot: startTelegramBot2 } = await Promise.resolve().then(() => (init_telegram_bot(), telegram_bot_exports));
    startTelegramBot2().catch((err) => {
      console.error("Failed to start Telegram bot:", err);
    });
  }
  if (process.env.DISCORD_BOT_TOKEN && process.env.DISCORD_BOT_TOKEN !== "PLACEHOLDER_TOKEN" && process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_ID !== "PLACEHOLDER_ID") {
    const { startDiscordBot: startDiscordBot2 } = await Promise.resolve().then(() => (init_discord_bot(), discord_bot_exports));
    startDiscordBot2().catch((err) => {
      console.error("Failed to start Discord bot:", err);
    });
  }
  if (process.env.ALPHA_ALERTS_ENABLED === "true") {
    const { getAlphaAlertService: getAlphaAlertService2 } = await Promise.resolve().then(() => (init_alpha_alerts(), alpha_alerts_exports));
    const alphaService = getAlphaAlertService2();
    alphaService.start().catch((err) => {
      console.error("Failed to start Alpha Alert service:", err);
    });
  }
  const { analyticsWorker: analyticsWorker2 } = await Promise.resolve().then(() => (init_analytics_worker(), analytics_worker_exports));
  analyticsWorker2.start();
  const { socialWorker: socialWorker2 } = await Promise.resolve().then(() => (init_social_worker(), social_worker_exports));
  socialWorker2.start();
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message2 = err.message || "Internal Server Error";
    res.status(status).json({ message: message2 });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
export {
  app
};
